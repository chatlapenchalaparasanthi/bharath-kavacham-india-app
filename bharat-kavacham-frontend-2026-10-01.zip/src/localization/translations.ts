/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LanguageCode } from '../types';

export interface Translations {
  appName: string;
  appSubtitle: string;
  appTagline: string;
  systemOnline: string;
  demoSimulation: string;
  modelResultNotice: string;
  navHome: string;
  navDesign: string;
  navSimulation: string;
  navMonitor: string;
  navMore: string;
  thermalComfort: string;
  energyDemand: string;
  heatLoss: string;
  solarContribution: string;
  fuelSaving: string;
  offlineStatus: string;
  ready: string;
  comfortable: string;
  outdoorTemp: string;
  windSpeed: string;
  solarRadiation: string;
  changeLocation: string;
  quickActions: string;
  runSimulation: string;
  climateData: string;
  designShelter: string;
  materialDb: string;
  solarStorage: string;
  fieldMonitor: string;
  digitalTwin: string;
  reports: string;
  arPreview: string;
  voiceMitra: string;
  commandCenter: string;
  fuelCalculator: string;
  qrIdentity: string;
  securityPrototype: string;
  postMap: string;
  presentationMode: string;
  settings: string;
}

export const translations: Record<LanguageCode, Translations> = {
  en: {
    appName: 'BHARAT KAVACHAM',
    appSubtitle: 'Area-Specific Thermal Shelter Intelligence Platform',
    appTagline: 'Thermal Comfort • Energy Optimization • Smart Monitoring',
    systemOnline: 'SYSTEM ONLINE',
    demoSimulation: 'Demo Simulation',
    modelResultNotice: 'Model Result — Requires Field Validation',
    navHome: 'Home',
    navDesign: 'Design',
    navSimulation: 'Simulation',
    navMonitor: 'Monitor',
    navMore: 'More',
    thermalComfort: 'Thermal Comfort',
    energyDemand: 'Energy Demand',
    heatLoss: 'Heat Loss Breakdown',
    solarContribution: 'Solar Contribution',
    fuelSaving: 'Fuel Saving',
    offlineStatus: 'Offline Status',
    ready: 'READY',
    comfortable: 'COMFORTABLE',
    outdoorTemp: 'Outdoor Temperature',
    windSpeed: 'Wind Speed',
    solarRadiation: 'Solar Radiation',
    changeLocation: 'Change Location',
    quickActions: 'Mission Quick Actions',
    runSimulation: 'Run Simulation',
    climateData: 'Climate Intelligence',
    designShelter: 'Design Shelter',
    materialDb: 'Material Database',
    solarStorage: 'Solar / PCM Storage',
    fieldMonitor: 'Field Telemetry',
    digitalTwin: 'Digital Twin 3D',
    reports: 'Technical Report',
    arPreview: 'AR Spatial Preview',
    voiceMitra: 'Jawan Mitra Voice',
    commandCenter: 'Command Center',
    fuelCalculator: 'Fuel & Eco Calculator',
    qrIdentity: 'QR Shelter Passport',
    securityPrototype: 'Security Research',
    postMap: 'Post Radar Map',
    presentationMode: 'Presentation Mode',
    settings: 'System Settings',
  },
  hi: {
    appName: 'भारत कवचम्',
    appSubtitle: 'क्षेत्र-विशिष्ट तापीय आश्रय आसूचना मंच',
    appTagline: 'तापीय आराम • ऊर्जा अनुकूलन • स्मार्ट निगरानी',
    systemOnline: 'प्रणाली सक्रिय',
    demoSimulation: 'डेमो सिमुलेशन',
    modelResultNotice: 'मॉडल परिणाम — क्षेत्रीय सत्यापन आवश्यक',
    navHome: 'होम',
    navDesign: 'डिज़ाइन',
    navSimulation: 'सिमुलेशन',
    navMonitor: 'निगरानी',
    navMore: 'अधिक',
    thermalComfort: 'तापीय सुख-सुविधा',
    energyDemand: 'ऊर्जा मांग',
    heatLoss: 'ऊष्मा ह्रास विवरण',
    solarContribution: 'सौर योगदान',
    fuelSaving: 'ईंधन बचत',
    offlineStatus: 'ऑफ़लाइन स्थिति',
    ready: 'तैयार',
    comfortable: 'अनुकूल',
    outdoorTemp: 'बाहरी तापमान',
    windSpeed: 'पवन गति',
    solarRadiation: 'सौर विकिरण',
    changeLocation: 'स्थान बदलें',
    quickActions: 'त्वरित कार्रवाई',
    runSimulation: 'सिमुलेशन चलाएं',
    climateData: 'जलवायु आसूचना',
    designShelter: 'आश्रय डिज़ाइन',
    materialDb: 'सामग्री डेटाबेस',
    solarStorage: 'सौर / पीसीएम संचयन',
    fieldMonitor: 'क्षेत्र टेलीमेट्री',
    digitalTwin: 'डिजिटल ट्विन',
    reports: 'तकनीकी रिपोर्ट',
    arPreview: 'एआर स्थानिक पूर्वावलोकन',
    voiceMitra: 'जवान मित्र आवाज़',
    commandCenter: 'कमांड सेंटर',
    fuelCalculator: 'ईंधन व पर्यावरण गणक',
    qrIdentity: 'क्यूआर पासपोर्ट',
    securityPrototype: 'सुरक्षा प्रोटोटाइप',
    postMap: 'पोस्ट रडार मानचित्र',
    presentationMode: 'प्रस्तुति मोड',
    settings: 'सेटिंग्स',
  },
  lad: {
    appName: 'བྷཱ་རཏ་ ཀ་ཝ་ཅམ། (BHARAT KAVACHAM)',
    appSubtitle: 'ལ་དྭགས་དང་གངས་རིའི་གནམ་གཤིས་བསྟུན་པའི་གནས་མཁར།',
    appTagline: 'དྲོད་ཁོལ་སྲུང་སྐྱོབ། • ནུས་ཤུགས་གྲོན་ཆུང་། • རིག་ནུས་ལྟ་ཞིབ།',
    systemOnline: 'མ་ལག་གྲ་སྒྲིག',
    demoSimulation: 'དཔེ་གཟུགས་ཚོད་ལྟ།',
    modelResultNotice: 'ཚོད་རྩིས་འབྲས་བུ། — ས་གནས་བདེན་དཔང་དགོས།',
    navHome: 'ཁྱིམ།',
    navDesign: 'བཟོ་བཀོད།',
    navSimulation: 'དྲོད་ཚད་ཚོད་ལྟ།',
    navMonitor: 'ལྟ་ཞིབ།',
    navMore: 'གཞན་དག',
    thermalComfort: 'ནང་གི་དྲོད་ཚད།',
    energyDemand: 'ནུས་ཤུགས་དགོས་མཁོ།',
    heatLoss: 'དྲོད་ཤོར་བགོ་བཤའ།',
    solarContribution: 'ཉི་འོད་ནུས་པ།',
    fuelSaving: 'སྣུམ་གྲོན་ཆུང་།',
    offlineStatus: 'དྲ་མེད་གནས་སྟངས།',
    ready: 'གྲ་སྒྲིག',
    comfortable: 'བདེ་མོ།',
    outdoorTemp: 'ཕྱི་རོལ་དྲོད་ཚད།',
    windSpeed: 'རླུང་གི་མགྱོགས་ཚད།',
    solarRadiation: 'ཉི་འོད་ཚ་ཤུགས།',
    changeLocation: 'ས་གནས་བརྗེ་བ།',
    quickActions: 'མྱུར་མགྱོགས་ལས་དོན།',
    runSimulation: 'ཚོད་ལྟ་འགོ་འཛུགས།',
    climateData: 'གནམ་གཤིས་གནས་ཚུལ།',
    designShelter: 'གནས་མཁར་བཟོ་བཀོད།',
    materialDb: 'རྒྱུ་ཆའི་མཛོད།',
    solarStorage: 'ཉི་འོད་དྲོད་གསོག',
    fieldMonitor: 'ས་གནས་བརྟག་ཞིབ།',
    digitalTwin: 'གནས་མཁར་གཟུགས་བརྙན།',
    reports: 'ལས་སྡོམ་སྙན་ཞུ།',
    arPreview: 'ཨེ་ཨར་མིག་མཐོང་།',
    voiceMitra: 'དམག་མིའི་གྲོགས་པོ།',
    commandCenter: 'བཀོད་འདོམས་ལྟེ་གནས།',
    fuelCalculator: 'སྣུམ་རྩིས་ཆེན་མོ།',
    qrIdentity: 'ཀིའུ་ཨར་ལག་ཁྱེར།',
    securityPrototype: 'སྲུང་སྐྱོབ་ཞིབ་འཇུག',
    postMap: 'ས་ཁྲ་རྡོ་རིང་།',
    presentationMode: 'སྟོན་མོའི་ལམ་ལུགས།',
    settings: 'སྒྲིག་བཀོད།',
  },
};
