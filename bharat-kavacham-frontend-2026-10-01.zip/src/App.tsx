/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LanguageCode, ScreenId } from './types';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { NavigationRail } from './components/common/NavigationRail';
import { DrawerMenu } from './components/common/DrawerMenu';
import { DemoBanner } from './components/common/DemoBanner';
import { FlutterFrame } from './components/common/FlutterFrame';

// Screens
import { SplashScreen } from './components/screens/SplashScreen';
import { OnboardingScreen } from './components/screens/OnboardingScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { LocationSelectScreen } from './components/screens/LocationSelectScreen';
import { ClimateScreen } from './components/screens/ClimateScreen';
import { ShelterDesignScreen } from './components/screens/ShelterDesignScreen';
import { MaterialDatabaseScreen } from './components/screens/MaterialDatabaseScreen';
import { AssemblyBuilderScreen } from './components/screens/AssemblyBuilderScreen';
import { ThermalSimulationScreen } from './components/screens/ThermalSimulationScreen';
import { HeatFlowScreen } from './components/screens/HeatFlowScreen';
import { DesignSpaceScreen } from './components/screens/DesignSpaceScreen';
import { ComparisonScreen } from './components/screens/ComparisonScreen';
import { SolarPcmScreen } from './components/screens/SolarPcmScreen';
import { OfflineCenterScreen } from './components/screens/OfflineCenterScreen';
import { FieldMonitorScreen } from './components/screens/FieldMonitorScreen';
import { DigitalTwinScreen } from './components/screens/DigitalTwinScreen';
import { PredictiveHealthScreen } from './components/screens/PredictiveHealthScreen';
import { ThermalMemoryScreen } from './components/screens/ThermalMemoryScreen';
import { ArPreviewScreen } from './components/screens/ArPreviewScreen';
import { VoiceAssistantScreen } from './components/screens/VoiceAssistantScreen';
import { SecurityScreen } from './components/screens/SecurityScreen';
import { PostMapScreen } from './components/screens/PostMapScreen';
import { OfflineSosScreen } from './components/screens/OfflineSosScreen';
import { CommandCenterScreen } from './components/screens/CommandCenterScreen';
import { QrIdentityScreen } from './components/screens/QrIdentityScreen';
import { EnvironmentalImpactScreen } from './components/screens/EnvironmentalImpactScreen';
import { ReportGeneratorScreen } from './components/screens/ReportGeneratorScreen';
import { ValidationCenterScreen } from './components/screens/ValidationCenterScreen';
import { LiveBoxDemoScreen } from './components/screens/LiveBoxDemoScreen';
import { PresentationModeScreen } from './components/screens/PresentationModeScreen';
import { DifferentiatorsScreen } from './components/screens/DifferentiatorsScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('splash');
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [viewMode, setViewMode] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);

  const navigate = (screen: ScreenId) => {
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Full-bleed views (Splash, Onboarding, Presentation)
  if (currentScreen === 'splash') {
    return (
      <SplashScreen
        onFinish={() => navigate('onboarding')}
        onNavigate={navigate}
      />
    );
  }

  if (currentScreen === 'onboarding') {
    return (
      <OnboardingScreen
        onComplete={() => navigate('home')}
        onNavigate={navigate}
      />
    );
  }

  if (currentScreen === 'presentation') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
        <PresentationModeScreen
          onNavigate={navigate}
          onExit={() => navigate('home')}
        />
      </div>
    );
  }

  // Active Screen Selector
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            onNavigate={navigate}
            language={language}
            onOpenDrawer={() => setIsDrawerOpen(true)}
          />
        );
      case 'location_select':
        return <LocationSelectScreen onNavigate={navigate} />;
      case 'climate':
        return <ClimateScreen onNavigate={navigate} />;
      case 'shelter_design':
        return <ShelterDesignScreen onNavigate={navigate} />;
      case 'materials':
        return <MaterialDatabaseScreen onNavigate={navigate} />;
      case 'assemblies':
        return <AssemblyBuilderScreen onNavigate={navigate} />;
      case 'simulation':
        return <ThermalSimulationScreen onNavigate={navigate} />;
      case 'heat_flow':
        return <HeatFlowScreen onNavigate={navigate} />;
      case 'design_space':
        return <DesignSpaceScreen onNavigate={navigate} />;
      case 'comparison':
        return <ComparisonScreen onNavigate={navigate} />;
      case 'solar_pcm':
        return <SolarPcmScreen onNavigate={navigate} />;
      case 'offline_center':
        return <OfflineCenterScreen onNavigate={navigate} />;
      case 'field_monitor':
        return <FieldMonitorScreen onNavigate={navigate} />;
      case 'digital_twin':
        return <DigitalTwinScreen onNavigate={navigate} />;
      case 'predictive_health':
        return <PredictiveHealthScreen onNavigate={navigate} />;
      case 'thermal_memory':
        return <ThermalMemoryScreen onNavigate={navigate} />;
      case 'ar_preview':
        return <ArPreviewScreen onNavigate={navigate} />;
      case 'voice_assistant':
        return (
          <VoiceAssistantScreen
            onNavigate={navigate}
            language={language}
            onLanguageChange={setLanguage}
          />
        );
      case 'security':
        return <SecurityScreen onNavigate={navigate} />;
      case 'post_map':
        return <PostMapScreen onNavigate={navigate} />;
      case 'offline_sos':
        return <OfflineSosScreen onNavigate={navigate} />;
      case 'command_center':
        return <CommandCenterScreen onNavigate={navigate} />;
      case 'qr_identity':
        return <QrIdentityScreen onNavigate={navigate} />;
      case 'environmental':
        return <EnvironmentalImpactScreen onNavigate={navigate} />;
      case 'reports':
        return <ReportGeneratorScreen onNavigate={navigate} />;
      case 'validation':
        return <ValidationCenterScreen onNavigate={navigate} />;
      case 'live_box_demo':
        return <LiveBoxDemoScreen onNavigate={navigate} />;
      case 'differentiators':
        return <DifferentiatorsScreen onNavigate={navigate} />;
      case 'settings':
        return (
          <SettingsScreen
            onNavigate={navigate}
            language={language}
            onLanguageChange={setLanguage}
            isDemoMode={isDemoMode}
            onToggleDemoMode={() => setIsDemoMode(!isDemoMode)}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
          />
        );
      default:
        return (
          <HomeScreen
            onNavigate={navigate}
            language={language}
            onOpenDrawer={() => setIsDrawerOpen(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500/20 selection:text-sky-200">
      {/* Top Tactical Command Header */}
      <Header
        currentScreen={currentScreen}
        onNavigate={navigate}
        language={language}
        onLanguageChange={setLanguage}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        isDemoMode={isDemoMode}
        onToggleDemoMode={() => setIsDemoMode(!isDemoMode)}
        onOpenDrawer={() => setIsDrawerOpen(true)}
      />

      {/* Demo / Validation Disclaimer Watermark Banner */}
      <DemoBanner isDemoMode={isDemoMode} />

      {/* Layout Shell */}
      <div className="flex-1 flex min-h-0 w-full">
        {/* Navigation Rail for Desktop and Tablet modes */}
        {viewMode !== 'mobile' && (
          <NavigationRail
            currentScreen={currentScreen}
            onNavigate={navigate}
            language={language}
          />
        )}

        {/* Main Content Area (Wrapped in Flutter frame if mobile mode selected) */}
        <FlutterFrame viewMode={viewMode}>
          <main className="flex-1 flex flex-col min-h-0">
            {renderScreen()}
          </main>

          {/* Bottom Nav if inside Flutter Mobile View */}
          {viewMode === 'mobile' && (
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={navigate}
              language={language}
              onOpenMore={() => setIsDrawerOpen(true)}
            />
          )}
        </FlutterFrame>
      </div>

      {/* Global 32-Module Slide-Out Drawer Menu */}
      <DrawerMenu
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        currentScreen={currentScreen}
        onNavigate={navigate}
        language={language}
      />
    </div>
  );
}
