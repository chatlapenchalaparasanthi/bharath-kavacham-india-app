/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ScreenId =
  | 'splash'
  | 'onboarding'
  | 'home'
  | 'location_select'
  | 'climate'
  | 'shelter_design'
  | 'materials'
  | 'assemblies'
  | 'simulation'
  | 'heat_flow'
  | 'design_space'
  | 'comparison'
  | 'solar_pcm'
  | 'offline_center'
  | 'field_monitor'
  | 'digital_twin'
  | 'predictive_health'
  | 'thermal_memory'
  | 'ar_preview'
  | 'voice_assistant'
  | 'security'
  | 'post_map'
  | 'offline_sos'
  | 'command_center'
  | 'qr_identity'
  | 'environmental'
  | 'reports'
  | 'validation'
  | 'live_box_demo'
  | 'presentation'
  | 'differentiators'
  | 'settings';

export type LanguageCode = 'en' | 'hi' | 'lad';

export interface LocationModel {
  id: string;
  name: string;
  region: string;
  latitude: number;
  longitude: number;
  altitudeMeters: number;
  designWinterTemp: number; // °C
  avgWindKmh: number;
  dailySolarGhiKwh: number; // kWh/m²/day
  isCustom?: boolean;
}

export interface ClimateHourlyPoint {
  hour: number; // 0 to 23
  temperature: number; // °C
  solarGhi: number; // W/m²
  solarDni: number; // W/m²
  windSpeed: number; // km/h
  humidity: number; // %
}

export interface ClimateDataModel {
  locationId: string;
  date: string;
  source: 'NASA POWER' | 'CACHED' | 'DEMO';
  avgTemp: number;
  minTemp: number;
  maxTemp: number;
  avgGhi: number;
  avgWind: number;
  hourly: ClimateHourlyPoint[];
  syncTimestamp: string;
}

export interface MaterialModel {
  id: string;
  name: string;
  category: 'insulation' | 'masonry' | 'timber' | 'composite' | 'advanced';
  kValue: number; // Thermal conductivity (W/m·K)
  density: number; // kg/m³
  specificHeat: number; // J/kg·K
  standardThicknessMm: number;
  costPerM3Inr: number;
  embodiedCarbonKg: number;
  localAvailability: 'High (Himalayan)' | 'Medium (Leh Stock)' | 'Special Order';
  description: string;
  features: string[];
}

export interface AssemblyLayer {
  id: string;
  materialId: string;
  thicknessMm: number;
  name: string;
  kValue: number;
}

export interface AssemblyModel {
  id: string;
  type: 'wall' | 'roof' | 'floor';
  name: string;
  layers: AssemblyLayer[];
}

export interface ShelterGeometryModel {
  lengthM: number;
  widthM: number;
  heightM: number;
  orientationDeg: number; // 0=North, 90=East, 180=South
  roofType: 'flat' | 'sloped' | 'dome' | 'custom';
  occupancy: number;
  ventilationAch: number; // Air changes per hour
  windowToWallRatio: number; // 0.05 to 0.35
  trombeWallAreaM2: number;
  pcmStorageCapacityKwh: number;
}

export interface SimulationInput {
  durationHours: 6 | 12 | 24 | 48 | 168; // 168 = 7 days
  outdoorTempBase: number;
  initialIndoorTemp: number;
  heatingPowerKw: number;
  timeStepSeconds: number;
  useTrombeWall: boolean;
  usePcm: boolean;
}

export interface SimulationHourlyResult {
  hour: number;
  outdoorTemp: number;
  indoorTemp: number;
  trombeTemp: number;
  pcmStoredKwh: number;
  heatingPowerUsedKw: number;
  solarGainKw: number;
}

export interface SimulationResult {
  durationHours: number;
  minIndoorTemp: number;
  maxIndoorTemp: number;
  avgIndoorTemp: number;
  comfortHours: number;
  totalComfortHours: number;
  dailyHeatingDemandKwh: number;
  baselineDemandKwh: number;
  solarContributionPct: number;
  fuelSavingPct: number;
  hourly: SimulationHourlyResult[];
  label: string; // e.g. "Demo Simulation" or "Model Result — Requires Field Validation"
}

export interface HeatFlowComponent {
  id: string;
  name: string;
  percentage: number;
  heatLossWatts: number;
  areaM2: number;
  uValue: number;
  tempDiffC: number;
  insulationThicknessMm: number;
  recommendedAction: string;
}

export interface OptimizationDesignPoint {
  id: string;
  name: string;
  wallInsulationMm: number;
  roofInsulationMm: number;
  glazingType: string;
  trombeWall: boolean;
  pcmStorage: boolean;
  costInr: number;
  dailyEnergyKwh: number;
  comfortScorePct: number;
  tag: 'cost' | 'energy' | 'comfort' | 'balanced' | 'baseline';
  heatLossPctWall: number;
}

export interface SensorModel {
  id: string;
  name: string;
  type: 'temperature' | 'humidity' | 'pressure' | 'heat_flux' | 'door' | 'damper_motor';
  location: string;
  value: string;
  unit: string;
  numericValue: number;
  status: 'ONLINE' | 'STANDBY' | 'CALIBRATING' | 'OFFLINE';
  healthScorePct: number;
  lastUpdate: string;
}

export interface MaintenanceAlert {
  id: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  title: string;
  component: string;
  message: string;
  recommendation: string;
  timestamp: string;
}

export interface ShelterHealthModel {
  overallScorePct: number;
  wallScorePct: number;
  roofScorePct: number;
  heatingScorePct: number;
  sensorsScorePct: number;
  motorScorePct: number;
  alerts: MaintenanceAlert[];
}
