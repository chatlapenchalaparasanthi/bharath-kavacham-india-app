/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

interface FlutterFrameProps {
  viewMode: 'mobile' | 'tablet' | 'desktop';
  children: React.ReactNode;
}

export const FlutterFrame: React.FC<FlutterFrameProps> = ({ viewMode, children }) => {
  if (viewMode !== 'mobile') {
    return <div className="flex-1 flex flex-col min-h-0 w-full">{children}</div>;
  }

  return (
    <div className="flex-1 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 overflow-y-auto">
      <div className="relative w-full max-w-[420px] h-[860px] max-h-[92vh] bg-slate-900 border-4 border-slate-700/80 rounded-[40px] shadow-2xl shadow-sky-950/40 flex flex-col overflow-hidden ring-1 ring-slate-800">
        {/* Flutter Mobile Top Status Bar */}
        <div className="h-7 bg-slate-950 px-6 flex items-center justify-between text-[11px] text-slate-400 font-mono select-none shrink-0 z-20">
          <span>14:20</span>
          {/* Speaker / Camera Notch */}
          <div className="w-20 h-4 bg-slate-900 rounded-full flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-800"></div>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3 text-sky-400" />
            <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>

        {/* Content Container */}
        <div className="flex-1 flex flex-col min-h-0 overflow-y-auto bg-slate-900 text-slate-100 relative">
          {children}
        </div>

        {/* Flutter Bottom Gesture Pill */}
        <div className="h-4 bg-slate-950 flex items-center justify-center shrink-0 z-20">
          <div className="w-32 h-1 bg-slate-600 rounded-full opacity-60"></div>
        </div>
      </div>
    </div>
  );
};
