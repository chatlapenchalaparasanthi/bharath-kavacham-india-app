/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, Compass, Cpu, Activity, LayoutGrid } from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { translations } from '../../localization/translations';

interface BottomNavProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
  onOpenMore: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
  language,
  onOpenMore,
}) => {
  const t = translations[language];

  const items = [
    {
      id: 'home' as ScreenId,
      label: t.navHome,
      icon: Home,
      isActive: currentScreen === 'home',
      onClick: () => onNavigate('home'),
    },
    {
      id: 'shelter_design' as ScreenId,
      label: t.navDesign,
      icon: Compass,
      isActive: ['shelter_design', 'materials', 'assemblies'].includes(currentScreen),
      onClick: () => onNavigate('shelter_design'),
    },
    {
      id: 'simulation' as ScreenId,
      label: t.navSimulation,
      icon: Cpu,
      isActive: ['simulation', 'heat_flow', 'design_space', 'solar_pcm'].includes(currentScreen),
      onClick: () => onNavigate('simulation'),
    },
    {
      id: 'field_monitor' as ScreenId,
      label: t.navMonitor,
      icon: Activity,
      isActive: ['field_monitor', 'digital_twin', 'predictive_health', 'thermal_memory'].includes(currentScreen),
      onClick: () => onNavigate('field_monitor'),
    },
    {
      id: 'more' as ScreenId,
      label: t.navMore,
      icon: LayoutGrid,
      isActive: false,
      onClick: onOpenMore,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/98 backdrop-blur-lg border-t border-slate-800 pb-safe">
      <div className="max-w-md mx-auto flex items-center justify-around h-16 px-1">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={item.onClick}
              aria-label={item.label}
              className="flex-1 min-h-[48px] flex flex-col items-center justify-center gap-1 group transition-transform active:scale-95"
            >
              <div
                className={`px-4 py-1 rounded-full transition-all duration-200 flex items-center justify-center ${
                  item.isActive
                    ? 'bg-sky-500/20 text-sky-400 shadow-sm shadow-sky-500/20'
                    : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 ${item.isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight ${
                  item.isActive ? 'text-sky-300 font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
