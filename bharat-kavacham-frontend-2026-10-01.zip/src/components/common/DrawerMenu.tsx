/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Search,
  Home,
  CloudSun,
  Compass,
  Boxes,
  Layers,
  Cpu,
  PieChart,
  GitCompare,
  SunMedium,
  HardDriveDownload,
  Activity,
  Box,
  HeartPulse,
  History,
  Camera,
  Mic,
  ShieldAlert,
  MapPin,
  Radio,
  Building2,
  QrCode,
  Leaf,
  Fuel,
  FileSpreadsheet,
  CheckCircle,
  FlaskConical,
  Flame,
  Award,
  Settings as SettingsIcon,
  Download,
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { exportZipService } from '../../services/exportZipService';

interface DrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
}

export const DrawerMenu: React.FC<DrawerMenuProps> = ({
  isOpen,
  onClose,
  currentScreen,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const categories = [
    {
      title: 'CORE PLATFORM',
      items: [
        { id: 'home' as ScreenId, name: 'Command Dashboard', icon: Home, desc: 'Central tactical status, KPI cards, quick actions' },
        { id: 'location_select' as ScreenId, name: 'Location Selection', icon: MapPin, desc: 'Siachen, Leh, Dras, Kargil, Nyoma, Custom coordinates' },
        { id: 'climate' as ScreenId, name: 'NASA POWER Climate Intelligence', icon: CloudSun, desc: 'Diurnal solar radiation, wind, sub-zero ambient curves' },
      ],
    },
    {
      title: 'SHELTER ARCHITECTURE & MATERIALS',
      items: [
        { id: 'shelter_design' as ScreenId, name: 'Shelter Design Workspace', icon: Compass, desc: 'Parametric dimensions, orientation, sloped/dome roofs' },
        { id: 'materials' as ScreenId, name: 'Himalayan Material Database', icon: Boxes, desc: 'PUF, AAC, Adobe Mud, Aerogel, Stone properties' },
        { id: 'assemblies' as ScreenId, name: 'Wall, Roof & Floor Assemblies', icon: Layers, desc: 'Multi-layer composite stack, U-values, thermal resistance' },
      ],
    },
    {
      title: 'PHYSICS SIMULATION & OPTIMIZATION',
      items: [
        { id: 'simulation' as ScreenId, name: '1D Transient Thermal Solver', icon: Cpu, desc: 'Implicit Backward Euler finite difference solver' },
        { id: 'heat_flow' as ScreenId, name: 'Heat Flow Decomposition', icon: PieChart, desc: 'Component loss: Wall, Roof, Floor, Door, Infiltration' },
        { id: 'design_space' as ScreenId, name: 'Design Space Explorer (324 Designs)', icon: GitCompare, desc: 'Pareto frontier trade-off: Cost vs Thermal Demand' },
        { id: 'comparison' as ScreenId, name: 'Side-by-Side Design Compare', icon: GitCompare, desc: 'Standard field shelter vs BHARAT KAVACHAM composite' },
        { id: 'solar_pcm' as ScreenId, name: 'Solar Trombe Wall & PCM Bank', icon: SunMedium, desc: 'Phase change thermal storage, day/night heat cycle' },
        { id: 'live_box_demo' as ScreenId, name: 'Live Chamber Demo (-16°C to 17°C)', icon: FlaskConical, desc: 'Sub-zero box thermal test simulation' },
      ],
    },
    {
      title: 'FIELD IOT, DIGITAL TWIN & AI',
      items: [
        { id: 'field_monitor' as ScreenId, name: 'Field Telemetry & Sensor Mesh', icon: Activity, desc: '6 live telemetry sensors, calibration status' },
        { id: 'digital_twin' as ScreenId, name: 'Interactive Digital Twin 3D', icon: Box, desc: 'Cutaway view with interactive surface temperature nodes' },
        { id: 'predictive_health' as ScreenId, name: 'Predictive Health & Diagnostics', icon: HeartPulse, desc: 'Shelter health 87%, component wear, early warnings' },
        { id: 'thermal_memory' as ScreenId, name: 'Thermal Memory AI (Winter History)', icon: History, desc: 'Historical sub-zero winter datasets & predictive tuning' },
        { id: 'ar_preview' as ScreenId, name: 'AR Spatial Preview', icon: Camera, desc: 'Forward terrain camera overlay with shelter footprint' },
        { id: 'voice_assistant' as ScreenId, name: 'Jawan Mitra Trilingual Voice', icon: Mic, desc: 'English, Hindi, Ladakhi interactive voice assistant' },
        { id: 'offline_center' as ScreenId, name: 'Offline Data Center', icon: HardDriveDownload, desc: 'Local cached datasets, voice packs & sync manager' },
        { id: 'offline_sos' as ScreenId, name: 'Offline SOS / LoRa Mesh Prototype', icon: Radio, desc: 'Sub-GHz local emergency mesh packet simulation' },
      ],
    },
    {
      title: 'TACTICAL INTELLIGENCE & SECURITY',
      items: [
        { id: 'command_center' as ScreenId, name: 'Regional Command Center', icon: Building2, desc: 'Fleet-wide shelter monitoring across high-altitude posts' },
        { id: 'post_map' as ScreenId, name: 'Forward Post Radar Map', icon: MapPin, desc: 'Geospatial thermal status of deployed shelters' },
        { id: 'qr_identity' as ScreenId, name: 'QR Shelter Passport (PK-2026-26051)', icon: QrCode, desc: 'Unique scanned passport, maintenance history, U-value specs' },
        { id: 'security' as ScreenId, name: 'Security Integration Research Prototype', icon: ShieldAlert, desc: 'Conceptual perimeter radar zone & thermal surveillance' },
      ],
    },
    {
      title: 'IMPACT, REPORTS & VALIDATION',
      items: [
        { id: 'environmental' as ScreenId, name: 'Environmental Impact & Carbon', icon: Leaf, desc: 'Avoided CO2 emissions, diesel displacement analysis' },
        { id: 'reports' as ScreenId, name: 'Technical Report Generator (16 Sections)', icon: FileSpreadsheet, desc: 'Complete engineering documentation & PDF export' },
        { id: 'validation' as ScreenId, name: 'Model Validation Center', icon: CheckCircle, desc: 'Energy balance, boundary convergence, stability checks' },
        { id: 'presentation' as ScreenId, name: 'Defence Presentation Mode', icon: Flame, desc: 'Executive high-impact demonstration view' },
        { id: 'differentiators' as ScreenId, name: 'Key Innovation Differentiators', icon: Award, desc: 'What sets BHARAT KAVACHAM apart from legacy structures' },
        { id: 'settings' as ScreenId, name: 'System Settings & Export', icon: SettingsIcon, desc: 'Language, themes, units, full source ZIP download' },
      ],
    },
  ];

  const filteredCategories = categories
    .map((cat) => ({
      ...cat,
      items: cat.items.filter(
        (i) =>
          i.name.toLowerCase().includes(query.toLowerCase()) ||
          i.desc.toLowerCase().includes(query.toLowerCase())
      ),
    }))
    .filter((cat) => cat.items.length > 0);

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Content */}
      <div className="relative w-full max-w-md bg-slate-900 border-r border-slate-800 text-slate-100 flex flex-col h-full z-10 shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="font-['Chakra_Petch'] font-bold text-lg text-white">
              MISSION MODULES
            </h2>
            <p className="text-xs text-sky-400 font-mono">BHARAT KAVACHAM · 32 Modules</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search module (e.g., Trombe, Solver, LoRa, AR)..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700/80 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>
        </div>

        {/* Quick Export ZIP Banner */}
        <div className="px-4 py-2 bg-sky-950/40 border-b border-sky-800/40 flex items-center justify-between">
          <span className="text-xs text-sky-300 font-medium">Export Complete Source Code</span>
          <button
            onClick={() => exportZipService.generateAndDownloadZip()}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-[11px] shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            Download ZIP
          </button>
        </div>

        {/* Modules List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {filteredCategories.map((cat, idx) => (
            <div key={idx} className="space-y-1.5">
              <h3 className="text-[11px] font-mono font-semibold text-slate-400 px-2 tracking-wider">
                {cat.title}
              </h3>
              <div className="space-y-1">
                {cat.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onNavigate(item.id);
                        onClose();
                      }}
                      className={`w-full text-left p-2.5 rounded-xl flex items-start gap-3 transition-colors ${
                        isActive
                          ? 'bg-sky-500/20 border border-sky-500/40 text-white'
                          : 'hover:bg-slate-800/80 text-slate-300 border border-transparent'
                      }`}
                    >
                      <div
                        className={`p-2 rounded-lg mt-0.5 ${
                          isActive ? 'bg-sky-500 text-white' : 'bg-slate-800 text-sky-400'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold text-slate-100 truncate">
                          {item.name}
                        </div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">
                          {item.desc}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
