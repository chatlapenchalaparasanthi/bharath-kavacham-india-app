/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';

interface DemoBannerProps {
  isDemoMode: boolean;
}

export const DemoBanner: React.FC<DemoBannerProps> = ({ isDemoMode }) => {
  return (
    <div className="bg-amber-950/80 border-b border-amber-800/60 px-4 py-2 text-xs text-amber-200 flex items-center justify-between gap-3">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
        <span>
          <strong className="font-semibold text-amber-300">
            {isDemoMode ? 'DEMO MODE ACTIVE' : 'MODEL NOTICE'}:
          </strong>{' '}
          All simulation metrics (e.g., 88% fuel saving, 178 → 21 kWh/day, 12 kWh PCM) are{' '}
          <em>Demo Simulation / Model Results — Requires Field Validation</em>.
        </span>
      </div>
      <div className="hidden sm:flex items-center gap-1 text-[11px] font-mono text-amber-400/80 shrink-0">
        <Info className="w-3.5 h-3.5" />
        <span>DIHAR / DRDO Research Ready</span>
      </div>
    </div>
  );
};
