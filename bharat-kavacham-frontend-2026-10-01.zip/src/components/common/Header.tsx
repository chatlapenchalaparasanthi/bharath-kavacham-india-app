/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  Menu,
  Shield,
  Smartphone,
  Tablet,
  Monitor,
  Flame,
  Globe2,
  Sliders,
  CheckCircle2,
  ChevronDown
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { translations } from '../../localization/translations';
import { climateService } from '../../services/climateService';
import { exportZipService } from '../../services/exportZipService';

interface HeaderProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  viewMode: 'mobile' | 'tablet' | 'desktop';
  onViewModeChange: (mode: 'mobile' | 'tablet' | 'desktop') => void;
  isDemoMode: boolean;
  onToggleDemoMode: () => void;
  onOpenDrawer: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  onNavigate,
  language,
  onLanguageChange,
  viewMode,
  onViewModeChange,
  isDemoMode,
  onToggleDemoMode,
  onOpenDrawer,
}) => {
  const t = translations[language];
  const activeLocation = climateService.getActiveLocation();
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState<string | null>(null);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const handleExportZip = async () => {
    setIsExporting(true);
    setExportStatus('Preparing ZIP...');
    try {
      await exportZipService.generateAndDownloadZip((_, msg) => {
        setExportStatus(msg);
      });
      setTimeout(() => {
        setIsExporting(false);
        setExportStatus(null);
      }, 1500);
    } catch {
      setIsExporting(false);
      setExportStatus('Export complete');
      setTimeout(() => setExportStatus(null), 2000);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-slate-100 select-none">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Left: Drawer Toggle & Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenDrawer}
            aria-label="Open Navigation Menu"
            className="w-11 h-11 flex items-center justify-center rounded-lg bg-slate-800/80 hover:bg-slate-700 active:scale-95 transition-all text-slate-200 border border-slate-700/60"
          >
            <Menu className="w-5 h-5 text-sky-400" />
          </button>

          <div
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-sky-500 to-blue-700 flex items-center justify-center shadow-lg shadow-sky-500/20 text-white font-bold">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Chakra_Petch'] font-bold text-base sm:text-lg tracking-wider text-white group-hover:text-sky-300 transition-colors">
                  {t.appName}
                </span>
                <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  {t.systemOnline}
                </span>
              </div>
              <p className="hidden sm:block text-[11px] text-slate-400 font-medium truncate max-w-[280px]">
                {activeLocation.name} · {activeLocation.altitudeMeters}m
              </p>
            </div>
          </div>
        </div>

        {/* Center: Location Quick Trigger */}
        <div className="hidden lg:flex items-center gap-2">
          <button
            onClick={() => onNavigate('location_select')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors"
          >
            <span className="text-slate-400">Sector:</span>
            <span className="text-sky-300 font-semibold">{activeLocation.name}</span>
            <span className="text-amber-400 font-mono">({activeLocation.designWinterTemp}°C)</span>
          </button>

          <button
            onClick={() => onNavigate('presentation')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-xs font-semibold text-amber-300 border border-amber-500/30 transition-colors"
          >
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            Presentation Mode
          </button>
        </div>

        {/* Right: Actions, Language, Device View, Zip Download */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Demo Toggle */}
          <button
            onClick={onToggleDemoMode}
            title={isDemoMode ? 'Demo Mode Active' : 'Switch to Demo Mode'}
            className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors ${
              isDemoMode
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden md:inline">DEMO</span>
          </button>

          {/* Device Frame Switcher */}
          <div className="hidden sm:flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
            <button
              onClick={() => onViewModeChange('mobile')}
              title="Flutter Mobile Device Frame"
              className={`p-1.5 rounded-md text-xs transition-colors ${
                viewMode === 'mobile' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('tablet')}
              title="Tablet NavigationRail View"
              className={`p-1.5 rounded-md text-xs transition-colors ${
                viewMode === 'tablet' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('desktop')}
              title="Full Tactical Command View"
              className={`p-1.5 rounded-md text-xs transition-colors ${
                viewMode === 'desktop' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-4 h-4" />
            </button>
          </div>

          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700"
            >
              <Globe2 className="w-3.5 h-3.5 text-sky-400" />
              <span className="uppercase">{language}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-2 w-36 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl py-1 z-50">
                <button
                  onClick={() => {
                    onLanguageChange('en');
                    setShowLangMenu(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-800 ${
                    language === 'en' ? 'text-sky-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  English
                  {language === 'en' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => {
                    onLanguageChange('hi');
                    setShowLangMenu(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-800 ${
                    language === 'hi' ? 'text-sky-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  हिंदी (Hindi)
                  {language === 'hi' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => {
                    onLanguageChange('lad');
                    setShowLangMenu(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-800 ${
                    language === 'lad' ? 'text-sky-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  ལ་དྭགས་སྐད (Ladakhi)
                  {language === 'lad' && <CheckCircle2 className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>

          {/* Download Complete Frontend ZIP Button */}
          <button
            onClick={handleExportZip}
            disabled={isExporting}
            title="Download Complete Frontend ZIP package"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-xs shadow-md shadow-sky-500/25 active:scale-95 transition-all disabled:opacity-60"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export ZIP</span>
          </button>
        </div>
      </div>

      {exportStatus && (
        <div className="bg-sky-950/90 border-t border-sky-800 px-4 py-1 text-center text-xs text-sky-300 font-mono animate-pulse">
          {exportStatus}
        </div>
      )}
    </header>
  );
};
