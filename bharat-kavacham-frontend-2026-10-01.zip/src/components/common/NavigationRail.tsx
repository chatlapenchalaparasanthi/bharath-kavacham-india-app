/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Home,
  CloudSun,
  Compass,
  Boxes,
  Layers,
  Cpu,
  PieChart,
  GitCompare,
  SunMedium,
  Activity,
  Box,
  HeartPulse,
  History,
  Camera,
  Mic,
  ShieldAlert,
  MapPin,
  Radio,
  Building2,
  QrCode,
  FileSpreadsheet,
  Settings as SettingsIcon,
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';

interface NavigationRailProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
}

export const NavigationRail: React.FC<NavigationRailProps> = ({
  currentScreen,
  onNavigate,
}) => {
  const sections = [
    { id: 'home' as ScreenId, label: 'Home', icon: Home },
    { id: 'climate' as ScreenId, label: 'Climate', icon: CloudSun },
    { id: 'shelter_design' as ScreenId, label: 'Design', icon: Compass },
    { id: 'materials' as ScreenId, label: 'Materials', icon: Boxes },
    { id: 'assemblies' as ScreenId, label: 'Assembly', icon: Layers },
    { id: 'simulation' as ScreenId, label: 'Solver', icon: Cpu },
    { id: 'heat_flow' as ScreenId, label: 'Heat Flow', icon: PieChart },
    { id: 'solar_pcm' as ScreenId, label: 'Solar/PCM', icon: SunMedium },
    { id: 'field_monitor' as ScreenId, label: 'Monitor', icon: Activity },
    { id: 'digital_twin' as ScreenId, label: 'Twin 3D', icon: Box },
    { id: 'predictive_health' as ScreenId, label: 'Health', icon: HeartPulse },
    { id: 'thermal_memory' as ScreenId, label: 'Memory AI', icon: History },
    { id: 'ar_preview' as ScreenId, label: 'AR Field', icon: Camera },
    { id: 'voice_assistant' as ScreenId, label: 'Voice', icon: Mic },
    { id: 'post_map' as ScreenId, label: 'Post Map', icon: MapPin },
    { id: 'offline_sos' as ScreenId, label: 'LoRa Mesh', icon: Radio },
    { id: 'command_center' as ScreenId, label: 'Command', icon: Building2 },
    { id: 'qr_identity' as ScreenId, label: 'QR Pass', icon: QrCode },
    { id: 'reports' as ScreenId, label: 'Reports', icon: FileSpreadsheet },
    { id: 'security' as ScreenId, label: 'Security', icon: ShieldAlert },
    { id: 'settings' as ScreenId, label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <aside className="w-16 lg:w-20 bg-slate-900 border-r border-slate-800 flex flex-col items-center py-3 gap-1 shrink-0 overflow-y-auto select-none">
      {sections.map((sec) => {
        const Icon = sec.icon;
        const isActive = currentScreen === sec.id;
        return (
          <button
            key={sec.id}
            onClick={() => onNavigate(sec.id)}
            title={sec.label}
            className={`w-12 lg:w-16 py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition-all ${
              isActive
                ? 'bg-sky-500/20 text-sky-400 font-semibold shadow-inner'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.6]'}`} />
            <span className="text-[10px] truncate max-w-full text-center tracking-tight">
              {sec.label}
            </span>
          </button>
        );
      })}
    </aside>
  );
};
