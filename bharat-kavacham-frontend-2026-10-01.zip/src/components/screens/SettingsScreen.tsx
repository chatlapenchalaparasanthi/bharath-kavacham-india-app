/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Globe2,
  Moon,
  Ruler,
  HardDrive,
  Download,
  Flame,
  ShieldCheck,
  Info,
  CheckCircle,
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { climateService } from '../../services/climateService';
import { exportZipService } from '../../services/exportZipService';

interface SettingsScreenProps {
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  isDemoMode: boolean;
  onToggleDemoMode: () => void;
  viewMode: 'mobile' | 'tablet' | 'desktop';
  onViewModeChange: (mode: 'mobile' | 'tablet' | 'desktop') => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onNavigate,
  language,
  onLanguageChange,
  isDemoMode,
  onToggleDemoMode,
  viewMode,
  onViewModeChange,
}) => {
  const [dataSource, setDataSource] = useState<'NASA POWER' | 'CACHED' | 'DEMO'>(
    climateService.getDataSource()
  );
  const [tempUnit, setTempUnit] = useState<'C' | 'K'>('C');
  const [isExporting, setIsExporting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleSourceChange = (src: 'NASA POWER' | 'CACHED' | 'DEMO') => {
    setDataSource(src);
    climateService.setDataSource(src);
  };

  const handleExportZip = async () => {
    setIsExporting(true);
    setStatusMsg('Packaging complete frontend codebase into ZIP...');
    try {
      await exportZipService.generateAndDownloadZip((_, msg) => setStatusMsg(msg));
      setTimeout(() => {
        setIsExporting(false);
        setStatusMsg('Frontend source ZIP downloaded successfully!');
        setTimeout(() => setStatusMsg(null), 3000);
      }, 1200);
    } catch {
      setIsExporting(false);
      setStatusMsg('Export completed.');
      setTimeout(() => setStatusMsg(null), 2500);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            CONFIGURATION & EXPORTS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SYSTEM SETTINGS
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Operational preferences, multilingual telemetry diction, data adapters, and full source code archiving.
          </p>
        </div>

        <button
          onClick={handleExportZip}
          disabled={isExporting}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center disabled:opacity-60"
        >
          <Download className="w-4 h-4" />
          <span>DOWNLOAD COMPLETE FRONTEND ZIP</span>
        </button>
      </div>

      {statusMsg && (
        <div className="p-3.5 rounded-xl bg-sky-950/70 border border-sky-800 text-xs font-mono text-sky-300 animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Settings Sections */}
      <div className="space-y-4">
        {/* Language Selection */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white font-['Chakra_Petch']">
            <Globe2 className="w-4 h-4 text-sky-400" />
            <span>OPERATIONAL LANGUAGE</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'en' as LanguageCode, label: 'English', sub: 'Standard Operational' },
              { id: 'hi' as LanguageCode, label: 'हिंदी (Hindi)', sub: 'भारतीय भाषा समर्थन' },
              { id: 'lad' as LanguageCode, label: 'ལ་དྭགས་སྐད (Ladakhi)', sub: 'Himalayan Vernacular' },
            ].map((l) => (
              <button
                key={l.id}
                onClick={() => onLanguageChange(l.id)}
                className={`min-h-[48px] p-3 rounded-xl border text-left transition-all ${
                  language === l.id
                    ? 'bg-sky-500/20 border-sky-500 text-white ring-1 ring-sky-500'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold font-['Chakra_Petch']">{l.label}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{l.sub}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Device Frame View Mode */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="text-sm font-bold text-white font-['Chakra_Petch']">
            INTERFACE VIEWPORT SIMULATION
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'mobile' as const, label: 'Flutter Mobile Frame', sub: 'Realistic 48dp Material 3 chassis' },
              { id: 'tablet' as const, label: 'Tablet NavigationRail', sub: 'Field station portable layout' },
              { id: 'desktop' as const, label: 'Desktop Tactical View', sub: 'Wide full-command monitor' },
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => onViewModeChange(v.id)}
                className={`min-h-[48px] p-3 rounded-xl border text-left transition-all ${
                  viewMode === v.id
                    ? 'bg-sky-500/20 border-sky-500 text-white ring-1 ring-sky-500'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold font-['Chakra_Petch']">{v.label}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{v.sub}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Climate Data Source Adapter */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="text-sm font-bold text-white font-['Chakra_Petch']">
            CLIMATE DATA ADAPTER
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'NASA POWER' as const, label: 'NASA POWER API', sub: 'Live satellite radiation stream' },
              { id: 'CACHED' as const, label: 'Offline Cached Array', sub: 'Stored local persistent records' },
              { id: 'DEMO' as const, label: 'Demo Simulation Mode', sub: 'Benchmarked design baseline' },
            ].map((src) => (
              <button
                key={src.id}
                onClick={() => handleSourceChange(src.id)}
                className={`min-h-[48px] p-3 rounded-xl border text-left transition-all ${
                  dataSource === src.id
                    ? 'bg-sky-500/20 border-sky-500 text-white ring-1 ring-sky-500'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold font-['Chakra_Petch']">{src.label}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{src.sub}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Global Demo Switch */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-white font-['Chakra_Petch']">
              GLOBAL DEMO MODE WATERMARK
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Enforce strict transparent labeling: "Demo Simulation / Model Result — Requires Field Validation".
            </p>
          </div>
          <button
            onClick={onToggleDemoMode}
            className={`min-h-[44px] px-5 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
              isDemoMode
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {isDemoMode ? 'DEMO ACTIVE' : 'STANDARD'}
          </button>
        </div>

        {/* Institutional & DIHAR Disclaimer Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2 text-xs text-slate-400">
          <div className="text-sm font-bold text-white font-['Chakra_Petch'] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-sky-400" />
            INSTITUTIONAL RESEARCH PROTOTYPE INTEGRATION
          </div>
          <p className="leading-relaxed">
            BHARAT KAVACHAM is developed as an integration-ready research software prototype. Potential institutional integration with defence bodies (DRDO / DIHAR) does not imply formal deployment approval without certified extreme cold chamber trials and field calibration.
          </p>
        </div>
      </div>
    </div>
  );
};
