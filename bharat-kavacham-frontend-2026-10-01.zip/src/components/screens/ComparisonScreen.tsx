/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  GitCompare,
  ArrowRight,
  TrendingDown,
  ShieldCheck,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface ComparisonScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ComparisonScreen: React.FC<ComparisonScreenProps> = ({ onNavigate }) => {
  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            TECHNICAL BENCHMARK COMPARISON
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            DESIGN A vs DESIGN B
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Side-by-side baseline field shelter versus BHARAT KAVACHAM composite passive solar shelter.
          </p>
        </div>

        <button
          onClick={() => onNavigate('solar_pcm')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>SOLAR / PCM STORAGE</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Side-by-Side Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* DESIGN A: Baseline */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 relative">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/20">
              DESIGN A · FIELD BASELINE
            </span>
            <span className="text-xs text-slate-400 font-mono">Uninsulated Corrugated Tin / Stone</span>
          </div>

          <h3 className="font-['Chakra_Petch'] font-bold text-xl text-white">
            Conventional High-Altitude Shelter
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Capital Cost:</span>
              <span className="font-mono font-bold text-slate-200">₹1,85,000</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Daily Heating Energy:</span>
              <span className="font-mono font-bold text-red-400 text-base">178 kWh/day</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Heat Loss Rate (UA Total):</span>
              <span className="font-mono font-bold text-red-400">285 W/K</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Comfort Envelope Hours:</span>
              <span className="font-mono font-bold text-slate-400">4 / 24 Hours</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Wall Insulation:</span>
              <span className="font-mono font-bold text-slate-300">25mm Glass Wool</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Solar Passive Contribution:</span>
              <span className="font-mono font-bold text-slate-400">12%</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">PCM Thermal Storage:</span>
              <span className="font-mono font-bold text-red-400 flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5" /> None
              </span>
            </div>
          </div>
        </div>

        {/* DESIGN B: Optimized BHARAT KAVACHAM */}
        <div className="p-6 rounded-2xl bg-slate-900 border-2 border-sky-500/80 shadow-xl shadow-sky-950/50 space-y-5 relative">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40">
              DESIGN B · BHARAT KAVACHAM OPTIMIZED
            </span>
            <span className="text-xs text-emerald-400 font-mono font-semibold">
              Selected Configuration
            </span>
          </div>

          <h3 className="font-['Chakra_Petch'] font-bold text-xl text-white">
            High-Altitude Solar Trombe Composite
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Capital Cost:</span>
              <span className="font-mono font-bold text-white">₹4,20,000</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Daily Heating Energy:</span>
              <span className="font-mono font-bold text-emerald-400 text-base">21 kWh/day (-88%)</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Heat Loss Rate (UA Total):</span>
              <span className="font-mono font-bold text-emerald-400">32 W/K (-89%)</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Comfort Envelope Hours:</span>
              <span className="font-mono font-bold text-emerald-400">23 / 24 Hours</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Wall Insulation:</span>
              <span className="font-mono font-bold text-sky-300">120mm PUF + Stone Core</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Solar Passive Contribution:</span>
              <span className="font-mono font-bold text-amber-300">68%</span>
            </div>

            <div className="flex justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">PCM Thermal Storage:</span>
              <span className="font-mono font-bold text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> 12 kWh Core
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
