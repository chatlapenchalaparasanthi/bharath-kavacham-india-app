/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Layers,
  ArrowUp,
  ArrowDown,
  Plus,
  Trash2,
  Cpu,
  ArrowRight,
  ShieldCheck,
  Flame,
} from 'lucide-react';
import { AssemblyLayer, AssemblyModel, ScreenId } from '../../types';
import { materialService, MATERIALS } from '../../services/materialService';

interface AssemblyBuilderScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const AssemblyBuilderScreen: React.FC<AssemblyBuilderScreenProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'wall' | 'roof' | 'floor'>('wall');
  const [assembly, setAssembly] = useState<AssemblyModel>(materialService.getAssembly('wall'));

  const switchTab = (type: 'wall' | 'roof' | 'floor') => {
    setActiveTab(type);
    setAssembly(materialService.getAssembly(type));
  };

  const metrics = materialService.calculateAssemblyMetrics(assembly);

  const handleThicknessChange = (layerId: string, mm: number) => {
    const updatedLayers = assembly.layers.map((l) =>
      l.id === layerId ? { ...l, thicknessMm: Math.max(5, mm) } : l
    );
    const updated = { ...assembly, layers: updatedLayers };
    setAssembly(updated);
    materialService.updateAssembly(updated);
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= assembly.layers.length) return;
    const newLayers = [...assembly.layers];
    const temp = newLayers[index];
    newLayers[index] = newLayers[targetIdx];
    newLayers[targetIdx] = temp;
    const updated = { ...assembly, layers: newLayers };
    setAssembly(updated);
    materialService.updateAssembly(updated);
  };

  const handleRemove = (layerId: string) => {
    if (assembly.layers.length <= 1) return;
    const updated = { ...assembly, layers: assembly.layers.filter((l) => l.id !== layerId) };
    setAssembly(updated);
    materialService.updateAssembly(updated);
  };

  const handleAddLayer = (materialId: string) => {
    const mat = materialService.getMaterialById(materialId);
    if (!mat) return;
    const newLayer: AssemblyLayer = {
      id: `lyr-${Date.now()}`,
      materialId: mat.id,
      name: mat.name,
      thicknessMm: mat.standardThicknessMm,
      kValue: mat.kValue,
    };
    const updated = { ...assembly, layers: [...assembly.layers, newLayer] };
    setAssembly(updated);
    materialService.updateAssembly(updated);
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            COMPOSITE ENVELOPE SYNTHESIS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            ASSEMBLY BUILDER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Stack layered insulation, thermal mass, and weather barriers. Reorder layers to simulate condensation plane and U-values.
          </p>
        </div>

        <button
          onClick={() => onNavigate('simulation')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>RUN THERMAL SOLVER</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Assembly Category Selector */}
      <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 max-w-md">
        {(['wall', 'roof', 'floor'] as const).map((type) => (
          <button
            key={type}
            onClick={() => switchTab(type)}
            className={`flex-1 min-h-[44px] py-2 rounded-xl text-xs font-bold font-['Chakra_Petch'] uppercase tracking-wider transition-all ${
              activeTab === type
                ? 'bg-sky-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {type === 'wall' ? 'Wall Assembly' : type === 'roof' ? 'Roof Assembly' : 'Floor Assembly'}
          </button>
        ))}
      </div>

      {/* Assembly Metrics Overview Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Overall U-Value</span>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-sky-400">
            {metrics.uValue} <span className="text-xs text-slate-400 font-normal">W/m²·K</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono mt-1 block">Sub-Zero Standard Compliant</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Total R-Value</span>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-amber-300">
            {metrics.rValue} <span className="text-xs text-slate-400 font-normal">m²·K/W</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">Thermal Resistance</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Total Thickness</span>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white">
            {metrics.totalThicknessMm} <span className="text-xs text-slate-400 font-normal">mm</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">Envelope Depth</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Estimated Cost</span>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-teal-300">
            ₹{metrics.estimatedCostPerM2.toLocaleString()} <span className="text-xs text-slate-400 font-normal">/m²</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1 block">Raw Materials Index</span>
        </div>
      </div>

      {/* Layer Stack Visualizer & Reordering */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
              {assembly.name}
            </h3>
            <p className="text-xs text-slate-400">
              Outer Exterior Surface (Top) ↓ Inner Conditioned Living Space (Bottom)
            </p>
          </div>
          <span className="text-xs font-mono text-sky-400 font-semibold px-2 py-1 rounded bg-sky-500/10 border border-sky-500/20">
            {assembly.layers.length} Active Layers
          </span>
        </div>

        <div className="space-y-3">
          {assembly.layers.map((layer, index) => {
            const layerR = Math.round((layer.thicknessMm / 1000 / (layer.kValue || 0.03)) * 100) / 100;
            return (
              <div
                key={layer.id}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-sky-400 text-xs font-mono font-bold flex items-center justify-center shrink-0">
                    {index + 1}
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-white font-['Chakra_Petch']">
                      {layer.name}
                    </h4>
                    <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400 mt-0.5">
                      <span>k: <strong className="text-sky-300">{layer.kValue}</strong> W/m·K</span>
                      <span>·</span>
                      <span>R: <strong className="text-amber-300">{layerR}</strong> m²K/W</span>
                    </div>
                  </div>
                </div>

                {/* Thickness Slider & Controls */}
                <div className="flex items-center gap-3 self-end sm:self-center">
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min="10"
                      max="300"
                      step="5"
                      value={layer.thicknessMm}
                      onChange={(e) => handleThicknessChange(layer.id, parseInt(e.target.value) || 10)}
                      className="w-24 sm:w-32 accent-sky-400 h-1.5 bg-slate-850 rounded-lg cursor-pointer"
                    />
                    <span className="w-14 text-right text-xs font-mono font-bold text-slate-200">
                      {layer.thicknessMm}mm
                    </span>
                  </div>

                  {/* Reordering */}
                  <div className="flex items-center gap-1 border-l border-slate-800 pl-2">
                    <button
                      onClick={() => handleMove(index, 'up')}
                      disabled={index === 0}
                      aria-label="Move layer up"
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 disabled:opacity-30"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleMove(index, 'down')}
                      disabled={index === assembly.layers.length - 1}
                      aria-label="Move layer down"
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 disabled:opacity-30"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleRemove(layer.id)}
                      disabled={assembly.layers.length <= 1}
                      aria-label="Remove layer"
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-red-950 text-slate-500 hover:text-red-400 disabled:opacity-30"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Add Layer Palette */}
        <div className="pt-3 border-t border-slate-800">
          <span className="text-xs font-semibold text-slate-400 block mb-2">
            Append Material Layer:
          </span>
          <div className="flex flex-wrap gap-2">
            {MATERIALS.slice(0, 6).map((m) => (
              <button
                key={m.id}
                onClick={() => handleAddLayer(m.id)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5 text-sky-400" />
                <span>{m.name.split(' ')[0]} ({m.standardThicknessMm}mm)</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
