/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Mountain, Shield, Sun, Home, ArrowRight } from 'lucide-react';
import { ScreenId } from '../../types';

interface SplashScreenProps {
  onFinish: () => void;
  onNavigate: (screen: ScreenId) => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [stage, setStage] = useState<number>(0);

  useEffect(() => {
    const timer1 = setTimeout(() => setStage(1), 500); // Mountain
    const timer2 = setTimeout(() => setStage(2), 1100); // Shelter
    const timer3 = setTimeout(() => setStage(3), 1700); // Sun & Thermal waves
    const timer4 = setTimeout(() => setStage(4), 2300); // Shield & Final text
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, []);

  return (
    <div className="flex-1 flex flex-col items-center justify-between p-8 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 select-none min-h-[500px]">
      <div className="w-full flex justify-end">
        <button
          onClick={onFinish}
          className="text-xs font-mono text-slate-400 hover:text-sky-400 transition-colors uppercase tracking-wider py-1 px-3 rounded-lg hover:bg-slate-800"
        >
          Skip Intro
        </button>
      </div>

      {/* Animated Emblem */}
      <div className="flex flex-col items-center justify-center my-auto relative">
        <div className="relative w-44 h-44 flex items-center justify-center">
          {/* Ambient Glow */}
          <div className="absolute inset-0 bg-sky-500/15 rounded-full blur-3xl animate-pulse"></div>

          {/* Thermal Waves Ring */}
          <div
            className={`absolute inset-0 rounded-full border border-amber-500/30 transition-all duration-1000 ${
              stage >= 3 ? 'scale-110 opacity-100 animate-spin-slow' : 'scale-75 opacity-0'
            }`}
          ></div>
          <div
            className={`absolute inset-4 rounded-full border border-sky-400/20 transition-all duration-1000 ${
              stage >= 3 ? 'scale-105 opacity-100' : 'scale-90 opacity-0'
            }`}
          ></div>

          {/* Sun Element */}
          <div
            className={`absolute top-2 right-4 transition-all duration-700 transform ${
              stage >= 3 ? 'scale-100 opacity-100 translate-y-0' : 'scale-50 opacity-0 translate-y-4'
            }`}
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/40 text-slate-950">
              <Sun className="w-6 h-6 animate-spin-very-slow" />
            </div>
          </div>

          {/* Mountain Element */}
          <div
            className={`absolute bottom-4 inset-x-0 flex justify-center transition-all duration-700 ${
              stage >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <Mountain className="w-28 h-28 text-sky-800/80 stroke-1" />
          </div>

          {/* Shelter Element */}
          <div
            className={`absolute bottom-6 flex items-center justify-center transition-all duration-700 ${
              stage >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
            }`}
          >
            <div className="p-3 bg-slate-900/90 border border-sky-500/50 rounded-xl shadow-xl backdrop-blur-md">
              <Home className="w-8 h-8 text-sky-300" />
            </div>
          </div>

          {/* Shield Element */}
          <div
            className={`absolute inset-0 flex items-center justify-center transition-all duration-700 ${
              stage >= 4 ? 'opacity-100 scale-100' : 'opacity-0 scale-125'
            }`}
          >
            <Shield className="w-36 h-36 text-sky-400/90 stroke-[1.2] drop-shadow-[0_0_20px_rgba(56,189,248,0.35)]" />
          </div>
        </div>

        {/* Title & Identity */}
        <div
          className={`text-center mt-8 transition-all duration-700 ${
            stage >= 4 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <div className="inline-block px-3 py-1 mb-2 rounded bg-sky-500/10 border border-sky-500/30 text-[10px] font-mono text-sky-400 tracking-widest uppercase">
            DEFENCE & HIMALAYAN HABITAT INTELLIGENCE
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-3xl sm:text-4xl tracking-wider text-white">
            BHARAT KAVACHAM
          </h1>
          <p className="text-sm font-semibold text-sky-300 mt-1">
            Area-Specific Thermal Shelter Intelligence
          </p>
          <p className="text-xs text-slate-400 mt-2 font-medium tracking-wide">
            Thermal Comfort · Energy Optimization · Smart Monitoring
          </p>
        </div>
      </div>

      {/* Enter Action */}
      <div className="w-full max-w-xs mt-6">
        <button
          onClick={onFinish}
          className="w-full min-h-[48px] py-3 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 active:scale-[0.98] text-white font-semibold text-sm shadow-xl shadow-sky-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <span>Enter Intelligence Platform</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
