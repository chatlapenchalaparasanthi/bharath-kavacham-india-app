/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Leaf,
  Fuel,
  TrendingDown,
  Calculator,
  ArrowRight,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface EnvironmentalImpactScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const EnvironmentalImpactScreen: React.FC<EnvironmentalImpactScreenProps> = ({ onNavigate }) => {
  const [baselineFuelPerDay, setBaselineFuelPerDay] = useState<number>(112);
  const [simulatedFuelPerDay, setSimulatedFuelPerDay] = useState<number>(13.4);
  const [fuelPricePerLitre, setFuelPricePerLitre] = useState<number>(180); // Includes high-altitude air-drop logistics
  const [winterDays, setWinterDays] = useState<number>(180);
  const [shelterCount, setShelterCount] = useState<number>(10);

  // Dynamic calculations
  const dailyFuelSavedPerShelter = Math.max(0, baselineFuelPerDay - simulatedFuelPerDay);
  const totalSeasonFuelSavedLitres = Math.round(dailyFuelSavedPerShelter * winterDays * shelterCount);
  const totalCostSavedInr = Math.round(totalSeasonFuelSavedLitres * fuelPricePerLitre);
  const co2AvoidedKg = Math.round(totalSeasonFuelSavedLitres * 2.68); // 2.68 kg CO2 per litre of diesel fuel
  const fuelReductionPct = Math.round((dailyFuelSavedPerShelter / baselineFuelPerDay) * 100);

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-emerald-400 uppercase tracking-wider mb-1">
            LOGISTICS BURDEN & CARBON DISPLACEMENT
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            ENVIRONMENTAL & FUEL CALCULATOR
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Transparent algorithmic models calculating diesel kerosene reduction and avoided carbon emissions.
          </p>
        </div>

        <button
          onClick={() => onNavigate('reports')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>TECHNICAL REPORT</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Primary KPI Results */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            SEASONAL FUEL DISPLACED
          </span>
          <div className="text-3xl font-bold font-mono text-emerald-400">
            {totalSeasonFuelSavedLitres.toLocaleString()} <span className="text-sm font-sans font-normal text-slate-300">Litres</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono mt-1 block">
            {fuelReductionPct}% Model Reduction
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            AVOIDED CO₂ EMISSIONS
          </span>
          <div className="text-3xl font-bold font-mono text-teal-300">
            {Math.round(co2AvoidedKg / 1000).toLocaleString()} <span className="text-sm font-sans font-normal text-slate-300">Tonnes</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono mt-1 block">
            2.68 kg CO₂ / L coefficient
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            ESTIMATED FISCAL SAVING
          </span>
          <div className="text-3xl font-bold font-mono text-amber-300">
            ₹{(Math.round(totalCostSavedInr / 100000) / 10).toLocaleString()} <span className="text-sm font-sans font-normal text-slate-300">Cr</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono mt-1 block">
            ₹{fuelPricePerLitre}/L airlift cost
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            SOLAR DISPLACEMENT RATIO
          </span>
          <div className="text-3xl font-bold font-mono text-sky-400">
            68%
          </div>
          <span className="text-[11px] text-slate-500 font-mono mt-1 block">
            Passive Trombe & PCM
          </span>
        </div>
      </div>

      {/* Dynamic Interactive Input Sliders */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
        <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
          DEPLOYMENT PARAMETERS & LOGISTICS ASSUMPTIONS
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 text-xs">
          <div>
            <div className="flex justify-between mb-1.5 font-medium">
              <span className="text-slate-300">Baseline Shelter Fuel (L/day)</span>
              <span className="font-mono font-bold text-red-400">{baselineFuelPerDay} L</span>
            </div>
            <input
              type="range"
              min="50"
              max="200"
              step="2"
              value={baselineFuelPerDay}
              onChange={(e) => setBaselineFuelPerDay(parseInt(e.target.value) || 100)}
              className="w-full accent-red-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1.5 font-medium">
              <span className="text-slate-300">Simulated Shelter Fuel (L/day)</span>
              <span className="font-mono font-bold text-emerald-400">{simulatedFuelPerDay} L</span>
            </div>
            <input
              type="range"
              min="5"
              max="40"
              step="0.5"
              value={simulatedFuelPerDay}
              onChange={(e) => setSimulatedFuelPerDay(parseFloat(e.target.value) || 10)}
              className="w-full accent-emerald-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1.5 font-medium">
              <span className="text-slate-300">Airlift Fuel Cost (₹/Litre)</span>
              <span className="font-mono font-bold text-amber-400">₹{fuelPricePerLitre}</span>
            </div>
            <input
              type="range"
              min="80"
              max="350"
              step="10"
              value={fuelPricePerLitre}
              onChange={(e) => setFuelPricePerLitre(parseInt(e.target.value) || 150)}
              className="w-full accent-amber-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1.5 font-medium">
              <span className="text-slate-300">Sub-Zero Winter Days</span>
              <span className="font-mono font-bold text-sky-400">{winterDays} Days</span>
            </div>
            <input
              type="range"
              min="90"
              max="270"
              step="10"
              value={winterDays}
              onChange={(e) => setWinterDays(parseInt(e.target.value) || 180)}
              className="w-full accent-sky-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1.5 font-medium">
              <span className="text-slate-300">Number of Deployed Shelters</span>
              <span className="font-mono font-bold text-white">{shelterCount} Shelters</span>
            </div>
            <input
              type="range"
              min="1"
              max="100"
              step="1"
              value={shelterCount}
              onChange={(e) => setShelterCount(parseInt(e.target.value) || 10)}
              className="w-full accent-white h-2 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Formulas transparently displayed as requested */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono text-slate-400">
          <div className="font-bold text-sky-300">TRANSPARENT FORMULA LOGIC:</div>
          <div>• Daily Fuel Avoided = (Baseline L/day - Simulated L/day) × Shelters = {dailyFuelSavedPerShelter.toFixed(1)} × {shelterCount} = {(dailyFuelSavedPerShelter * shelterCount).toFixed(1)} L/day</div>
          <div>• Seasonal Avoided CO₂ = Total Litres Saved × 2.68 kg CO₂/L = {co2AvoidedKg.toLocaleString()} kg CO₂</div>
          <div>• Model Status: <span className="text-amber-400 font-bold">ESTIMATED · MODEL OUTPUT · FIELD VALIDATION REQUIRED</span></div>
        </div>
      </div>
    </div>
  );
};
