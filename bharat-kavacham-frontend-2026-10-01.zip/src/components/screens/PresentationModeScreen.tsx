/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Flame,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Layers,
  Sun,
  Activity,
  FileSpreadsheet,
  GitCompare,
  X,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface PresentationModeScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onExit: () => void;
}

export const PresentationModeScreen: React.FC<PresentationModeScreenProps> = ({
  onNavigate,
  onExit,
}) => {
  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6 pb-24 select-none">
      {/* Top Presentation Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/30">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-['Chakra_Petch'] font-bold text-xl sm:text-2xl text-white tracking-wider">
              BHARAT KAVACHAM · DEFENCE PRESENTATION MODE
            </h1>
            <p className="text-xs text-sky-400 font-mono">
              AREA-SPECIFIC SHELTER INTELLIGENCE · DEMO SIMULATION
            </p>
          </div>
        </div>

        <button
          onClick={onExit}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
        >
          <X className="w-4 h-4" />
          <span>Exit Presentation</span>
        </button>
      </div>

      {/* Human-Centered Story Opening required by prompt */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950/40 to-slate-900 border border-sky-500/30 shadow-2xl space-y-4 text-center">
        <span className="text-[11px] font-mono uppercase tracking-widest text-sky-400 block">
          CENTRAL SCIENTIFIC INQUIRY
        </span>
        <h2 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white max-w-3xl mx-auto leading-tight">
          "Extreme environments demand shelter designs based on real environmental conditions."
        </h2>
        <p className="text-base sm:text-lg text-amber-300 font-semibold max-w-2xl mx-auto">
          "Can software help us design a shelter before we build it?"
        </p>

        {/* Narrative Flow Pipeline */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4 text-xs font-mono font-bold text-slate-300">
          <span className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 text-sky-400">1. CLIMATE</span>
          <span>→</span>
          <span className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 text-amber-400">2. THERMAL MODEL</span>
          <span>→</span>
          <span className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 text-teal-400">3. MATERIALS</span>
          <span>→</span>
          <span className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 text-amber-300">4. SOLAR STORAGE</span>
          <span>→</span>
          <span className="px-3 py-1 rounded-md bg-slate-800 border border-slate-700 text-emerald-400">5. MONITORING</span>
        </div>
      </div>

      {/* Large KPI Cards (Specified in prompt) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* OUTDOOR */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            OUTDOOR
          </span>
          <div className="text-4xl font-bold font-mono text-sky-400 my-2">
            -40°C
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Siachen Ambient</span>
        </div>

        {/* INDOOR */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            INDOOR
          </span>
          <div className="text-4xl font-bold font-mono text-white my-2">
            17°C
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Target: 15–20°C</span>
        </div>

        {/* STATUS */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            THERMAL STATUS
          </span>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400 my-2">
            COMFORTABLE
          </div>
          <span className="text-[10px] text-emerald-500 font-mono">No Chilling Risk</span>
        </div>

        {/* ENERGY */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            ENERGY DEMAND
          </span>
          <div className="text-3xl sm:text-4xl font-bold font-mono text-sky-300 my-2">
            21 <span className="text-xs text-slate-400 font-normal">kWh/day</span>
          </div>
          <span className="text-[10px] text-amber-400 font-mono">Demo Simulation</span>
        </div>

        {/* SOLAR */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            SOLAR PASSIVE
          </span>
          <div className="text-3xl sm:text-4xl font-bold font-mono text-amber-300 my-2">
            68%
          </div>
          <span className="text-[10px] text-amber-500 font-mono">Trombe + PCM</span>
        </div>

        {/* HEAT FLOW */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            HEAT FLOW
          </span>
          <div className="text-xs font-mono font-bold text-slate-200 my-2 space-y-0.5">
            <div>Wall: <strong className="text-sky-300">40%</strong></div>
            <div>Roof: <strong className="text-amber-300">30%</strong></div>
            <div>Floor: <strong className="text-emerald-400">15%</strong></div>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Door/Vent: 15%</span>
        </div>
      </div>

      {/* Presentation Status & Actions */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></div>
          <div>
            <div className="text-sm font-bold text-white font-['Chakra_Petch']">
              SIMULATION COMPLETE · VALIDATED ARCHITECTURE
            </div>
            <div className="text-xs text-slate-400 font-mono">
              All figures carry: <em>Demo Simulation / Model Result — Requires Field Validation</em>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onNavigate('simulation')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold active:scale-95 transition-all"
          >
            VIEW DETAILS
          </button>
          <button
            onClick={() => onNavigate('comparison')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold active:scale-95 transition-all"
          >
            COMPARE DESIGN
          </button>
          <button
            onClick={() => onNavigate('reports')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs shadow-md shadow-sky-600/25 active:scale-95 transition-all"
          >
            GENERATE REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
