/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  History,
  TrendingUp,
  Brain,
  ArrowRight,
  ShieldCheck,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface ThermalMemoryScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ThermalMemoryScreen: React.FC<ThermalMemoryScreenProps> = ({ onNavigate }) => {
  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            SEASONAL RETROSPECTIVE & ADAPTIVE MODELING
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            THERMAL MEMORY AI
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Learns from previous extreme winter blizzard cycles to predict next-season heating loads and retrofit ROI.
          </p>
        </div>

        <button
          onClick={() => onNavigate('ar_preview')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>AR SHELTER PREVIEW</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Historical Data Cards */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-sky-400" />
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
              HISTORICAL TELEMETRY LOG · WINTER 2024–2025
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">Siachen North Glacier Sector</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-1">Peak Outdoor Minimum</span>
            <div className="text-3xl font-bold font-mono text-sky-400">-35°C</div>
            <span className="text-[11px] text-slate-500 font-mono mt-1 block">Logged on 18 Jan 2025</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-1">Indoor Core Temperature Average</span>
            <div className="text-3xl font-bold font-mono text-emerald-400">16.8°C</div>
            <span className="text-[11px] text-emerald-500/80 font-mono mt-1 block">96% inside comfort zone</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-1">Mean Daily Heating Demand</span>
            <div className="text-3xl font-bold font-mono text-amber-300">22.4 kWh/day</div>
            <span className="text-[11px] text-slate-500 font-mono mt-1 block">Displaced 86.4% fuel vs baseline</span>
          </div>
        </div>
      </div>

      {/* Next Winter Predictive AI Card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-sky-500/40 space-y-4 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-sky-400 uppercase tracking-wider block">
                MACHINE LEARNING FORECAST
              </span>
              <h3 className="font-['Chakra_Petch'] font-bold text-lg text-white">
                NEXT-WINTER PREDICTIVE MODEL (WINTER 2026–2027)
              </h3>
            </div>
          </div>

          <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 self-start sm:self-center">
            AI / MODEL PREDICTION
          </span>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-white font-['Chakra_Petch'] text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Proactive Optimization Suggestion
            </h4>
            <p>
              "Simulation and historical drift analysis suggest evaluating additional <strong>40mm roof insulation</strong> or an exterior thermal blanket prior to November 2026. High snow accumulation rates on the leeward pitch induce minor conductive leakage."
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] font-mono">
              <span className="text-slate-400 block mb-0.5">Projected Next-Winter Demand:</span>
              <span className="text-sm font-bold text-sky-300">19.8 kWh/day (with roof upgrade)</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] font-mono">
              <span className="text-slate-400 block mb-0.5">Estimated Diesel Saved:</span>
              <span className="text-sm font-bold text-emerald-400">~3,480 Litres / Season / Shelter</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
