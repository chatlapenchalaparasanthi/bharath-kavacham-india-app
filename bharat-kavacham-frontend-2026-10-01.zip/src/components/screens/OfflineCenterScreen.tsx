/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  HardDriveDownload,
  CheckCircle,
  RefreshCw,
  Download,
  Database,
  Volume2,
  Cpu,
  Layers,
  CloudSun,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { exportZipService } from '../../services/exportZipService';

interface OfflineCenterScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const OfflineCenterScreen: React.FC<OfflineCenterScreenProps> = ({ onNavigate }) => {
  const [syncTime, setSyncTime] = useState('14:20 IST');
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST');
    }, 800);
  };

  const offlinePacks = [
    { title: 'Climate Meteorological Datasets', size: '14.2 MB', icon: CloudSun, status: 'Cached & Synced' },
    { title: 'Himalayan Materials Database', size: '2.8 MB', icon: Database, status: 'Cached & Synced' },
    { title: 'Shelter Assembly & CAD Models', size: '8.4 MB', icon: Layers, status: 'Cached & Synced' },
    { title: '1D Transient Solver Binaries', size: '4.1 MB', icon: Cpu, status: 'Cached & Synced' },
    { title: 'Trilingual Voice Packs (EN, HI, LAD)', size: '32.0 MB', icon: Volume2, status: 'Cached & Synced' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            LOCAL PERSISTENT STORAGE VAULT
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            OFFLINE DATA CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Full operational independence in GPS-denied or severed communications forward environments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSync}
            disabled={isSyncing}
            className="min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-2 active:scale-95 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 text-sky-400 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>SYNC WHEN ONLINE</span>
          </button>
        </div>
      </div>

      {/* Sync Status Banner */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white font-['Chakra_Petch']">
              ALL LOCAL CACHES VERIFIED
            </div>
            <div className="text-xs text-slate-400">
              Last synchronized: <strong className="text-emerald-400 font-mono">{syncTime}</strong>
            </div>
          </div>
        </div>

        <button
          onClick={() => exportZipService.generateAndDownloadZip()}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-sky-600/25 active:scale-95 transition-all"
        >
          <Download className="w-4 h-4" />
          <span>Export Source (.ZIP)</span>
        </button>
      </div>

      {/* Offline Packs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {offlinePacks.map((pack, idx) => {
          const Icon = pack.icon;
          return (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Ready
                </span>
              </div>

              <div>
                <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
                  {pack.title}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Payload Size: {pack.size}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex justify-between">
                <span>{pack.status}</span>
                <span className="text-sky-300">IndexedDB ✓</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
