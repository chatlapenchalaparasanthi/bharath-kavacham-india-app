/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  CheckCircle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Code2,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface ValidationCenterScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ValidationCenterScreen: React.FC<ValidationCenterScreenProps> = ({ onNavigate }) => {
  const checks = [
    { title: 'Energy Balance Conservation', status: 'PASS', desc: '1st Law of Thermodynamics satisfied across internal nodes' },
    { title: 'Boundary Conditions Stability', status: 'PASS', desc: 'Sol-Air convective and radiative coefficients bounded' },
    { title: 'Material Properties Bounds', status: 'PASS', desc: 'k > 0, density > 0, specific heat within physical ranges' },
    { title: 'Time Step Courant-Friedrichs-Lewy (CFL)', status: 'PASS', desc: 'Implicit Backward Euler allows unconditionally stable Δt=300s' },
    { title: 'Residual Convergence Tolerance', status: 'PASS', desc: 'L2 norm residuals < 1e-4 within 8 Newton iterations' },
    { title: 'Mathematical Unit Formulations', status: 'PASS', desc: '12 core thermophysical solver functions verified' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-emerald-400 uppercase tracking-wider mb-1">
            NUMERICAL INTEGRITY & MATHEMATICAL RIGOR
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            MODEL VALIDATION CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Transparent solver validation benchmarks and explicit mathematical formulations.
          </p>
        </div>

        <button
          onClick={() => onNavigate('live_box_demo')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>LIVE CHAMBER DEMO</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Validation Checks Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {checks.map((c, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono text-slate-400">BENCHMARK 0{idx + 1}</span>
              <span className="text-xs font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> {c.status}
              </span>
            </div>
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-white">{c.title}</h3>
            <p className="text-xs text-slate-400 leading-relaxed">{c.desc}</p>
          </div>
        ))}
      </div>

      {/* Mathematical Transparency Card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="font-['Chakra_Petch'] font-bold text-base text-white flex items-center gap-2">
          <Code2 className="w-4 h-4 text-sky-400" />
          TECHNICAL TRANSPARENCY & FORMULATIONS
        </h3>

        <div className="space-y-3 text-xs font-mono text-slate-300 leading-relaxed">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-sky-400 font-bold">1. 1D Heat Diffusion Equation:</span>
            <div className="text-amber-300">ρ·Cp·(∂T/∂t) = ∂/∂x (k·∂T/∂x) + q_gen</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Discretized spatially into composite control volumes corresponding to layer boundaries.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-sky-400 font-bold">2. Implicit Backward Euler Discretization:</span>
            <div className="text-amber-300">T_i^(n+1) - T_i^n = (Δt / C_i) · [ Σ ((T_j^(n+1) - T_i^(n+1)) / R_ij) + Q_in ]</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Yields a strictly diagonally dominant tridiagonal matrix solved via Thomas algorithm.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-sky-400 font-bold">3. Sol-Air Boundary Condition:</span>
            <div className="text-amber-300">T_sol-air = T_out + (α·I - ε·ΔR) / h_out</div>
            <p className="text-[11px] text-slate-400 font-sans">
              Integrates high-altitude Karakoram global horizontal irradiance (GHI) and infrared clear-sky radiant deficit.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
