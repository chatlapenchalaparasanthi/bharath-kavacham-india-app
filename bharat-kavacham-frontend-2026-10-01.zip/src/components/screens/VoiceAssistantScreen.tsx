/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Mic,
  Volume2,
  Radio,
  ArrowRight,
  MessageSquare,
  Sparkles,
  CheckCircle,
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { voiceService, VOICE_COMMANDS, VoiceCommandSample } from '../../services/voiceService';

interface VoiceAssistantScreenProps {
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

export const VoiceAssistantScreen: React.FC<VoiceAssistantScreenProps> = ({
  onNavigate,
  language,
  onLanguageChange,
}) => {
  const [isListening, setIsListening] = useState<boolean>(false);
  const [activeResponse, setActiveResponse] = useState<string>(
    VOICE_COMMANDS[0].response[language]
  );
  const [lastQuery, setLastQuery] = useState<string>(
    VOICE_COMMANDS[0].command[language]
  );

  const handleCommandClick = (cmd: VoiceCommandSample) => {
    setLastQuery(cmd.command[language]);
    const reply = cmd.response[language];
    setActiveResponse(reply);
    voiceService.speak(reply, language);
  };

  const handleMicToggle = () => {
    if (!isListening) {
      setIsListening(true);
      // Simulate listening and picking random sample
      setTimeout(() => {
        const randomCmd = VOICE_COMMANDS[Math.floor(Math.random() * VOICE_COMMANDS.length)];
        setLastQuery(randomCmd.command[language]);
        setActiveResponse(randomCmd.response[language]);
        voiceService.speak(randomCmd.response[language], language);
        setIsListening(false);
      }, 1500);
    } else {
      setIsListening(false);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            MULTILINGUAL HANDS-FREE OPERATIONAL VOICE
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            JAWAN MITRA VOICE ASSISTANT
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Voice telemetry query interface in English, Hindi, and Ladakhi for sub-zero glove operation.
          </p>
        </div>

        {/* Language Switcher */}
        <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
          {(['en', 'hi', 'lad'] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => onLanguageChange(lang)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                language === lang ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lang === 'en' ? 'English' : lang === 'hi' ? 'हिंदी' : 'ལ་དྭགས་སྐད'}
            </button>
          ))}
        </div>
      </div>

      {/* Voice Core Card */}
      <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-6 relative overflow-hidden shadow-2xl">
        {/* Glow */}
        <div className="absolute inset-0 bg-radial from-sky-500/10 via-transparent to-transparent pointer-events-none"></div>

        {/* Large Microphone Button (Min touch target 48dp, actually 96dp!) */}
        <div className="relative inline-flex items-center justify-center">
          {isListening && (
            <div className="absolute -inset-4 rounded-full bg-sky-500/20 animate-ping"></div>
          )}
          <button
            onClick={handleMicToggle}
            aria-label="Toggle Voice Recording"
            className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 active:scale-95 cursor-pointer ${
              isListening
                ? 'bg-gradient-to-br from-red-500 to-rose-600 text-white ring-4 ring-rose-500/50 shadow-red-500/40'
                : 'bg-gradient-to-br from-sky-500 to-blue-600 text-white hover:scale-105 shadow-sky-500/30'
            }`}
          >
            <Mic className="w-10 h-10 sm:w-12 sm:h-12" />
          </button>
        </div>

        <div>
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-sky-400 mb-1">
            {isListening ? 'LISTENING FOR SPOKEN MISSION COMMAND...' : 'TAP MICROPHONE TO SPEAK'}
          </div>
          <p className="text-sm text-slate-300 max-w-md mx-auto">
            {language === 'hi'
              ? 'आदेश बोलें: "तापमान दिखाओ", "सिमुलेशन प्रारंभ करो", "आश्रय स्वास्थ्य जांचो"'
              : language === 'lad'
              ? 'བཀའ་གནང་རོགས: "དྲོད་ཚད་སྟོན་ཅིག", "ཚོད་ལྟ་འགོ་འཛུགས"'
              : 'Speak queries like: "Show temperature", "Start simulation", "Check shelter health"'}
          </p>
        </div>

        {/* Spoken Response Bubble */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-left space-y-2 max-w-2xl mx-auto shadow-inner">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span className="flex items-center gap-1.5 text-sky-400 font-bold">
              <MessageSquare className="w-3.5 h-3.5" /> RECOGNIZED: "{lastQuery}"
            </span>
            <span className="text-[11px] text-emerald-400 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Jawan Mitra Ready
            </span>
          </div>

          <p className="text-sm sm:text-base text-white font-medium leading-relaxed">
            "{activeResponse}"
          </p>

          <div className="flex justify-end pt-1">
            <button
              onClick={() => voiceService.speak(activeResponse, language)}
              className="text-xs font-mono text-sky-400 hover:text-sky-300 flex items-center gap-1 py-1 px-2 rounded hover:bg-slate-900"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Replay Spoken Audio</span>
            </button>
          </div>
        </div>
      </div>

      {/* Suggested Quick Command Prompts */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
          TACTICAL VOICE COMMAND LIBRARY
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {VOICE_COMMANDS.map((cmd) => (
            <button
              key={cmd.id}
              onClick={() => handleCommandClick(cmd)}
              className="p-3.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-left flex items-center justify-between group transition-all"
            >
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-white font-['Chakra_Petch'] group-hover:text-sky-300">
                  "{cmd.command[language]}"
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-1 font-mono">
                  {cmd.response[language]}
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all shrink-0 ml-2" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
