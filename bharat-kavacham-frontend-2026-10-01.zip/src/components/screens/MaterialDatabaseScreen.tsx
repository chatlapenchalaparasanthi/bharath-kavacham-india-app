/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Boxes,
  Search,
  Check,
  Info,
  ArrowRight,
  TrendingDown,
  Layers,
  Sparkles,
} from 'lucide-react';
import { MaterialModel, ScreenId } from '../../types';
import { materialService, MATERIALS } from '../../services/materialService';

interface MaterialDatabaseScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const MaterialDatabaseScreen: React.FC<MaterialDatabaseScreenProps> = ({ onNavigate }) => {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'LOW_K' | 'LOW_COST' | 'LOCAL' | 'HIGH_MASS' | 'INSULATION'>('ALL');
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialModel | null>(MATERIALS[0]);

  const filtered = MATERIALS.filter((m) => {
    const matchesQuery =
      m.name.toLowerCase().includes(query.toLowerCase()) ||
      m.description.toLowerCase().includes(query.toLowerCase());

    if (!matchesQuery) return false;

    if (activeFilter === 'LOW_K') return m.kValue <= 0.04;
    if (activeFilter === 'LOW_COST') return m.costPerM3Inr <= 5000;
    if (activeFilter === 'LOCAL') return m.localAvailability.includes('High');
    if (activeFilter === 'HIGH_MASS') return m.density >= 1000;
    if (activeFilter === 'INSULATION') return m.category === 'insulation' || m.category === 'advanced';
    return true;
  });

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            SUB-ZERO ENVELOPE MATERIALS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            MATERIAL DATABASE
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Calibrated thermo-physical properties for extreme Himalayan sub-zero deployment.
          </p>
        </div>

        <button
          onClick={() => onNavigate('assemblies')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>GO TO ASSEMBLY BUILDER</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Search & Filter Controls */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search material by name or application (e.g. PUF, Aerogel, Stone)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 font-medium"
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 pt-1">
          {[
            { id: 'ALL', label: 'All Materials' },
            { id: 'LOW_K', label: 'LOW K-VALUE' },
            { id: 'LOW_COST', label: 'LOW COST' },
            { id: 'LOCAL', label: 'LOCAL MATERIAL' },
            { id: 'HIGH_MASS', label: 'HIGH THERMAL MASS' },
            { id: 'INSULATION', label: 'INSULATION' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeFilter === f.id
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Materials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((mat) => {
          const isSelected = selectedMaterial?.id === mat.id;
          return (
            <div
              key={mat.id}
              className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-slate-850 border-sky-500 ring-1 ring-sky-500/80 shadow-lg'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-sky-400 block mb-0.5">
                      {mat.category}
                    </span>
                    <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
                      {mat.name}
                    </h3>
                  </div>
                  <span
                    className={`text-[11px] font-mono font-medium px-2 py-0.5 rounded ${
                      mat.localAvailability.includes('High')
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : mat.localAvailability.includes('Medium')
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                    }`}
                  >
                    {mat.localAvailability}
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {mat.description}
                </p>

                {/* Metrics Table */}
                <div className="grid grid-cols-2 gap-2 text-xs pt-3 border-t border-slate-800/80 mb-4">
                  <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Conductivity (k)</span>
                    <span className="font-mono font-bold text-sky-300">
                      {mat.kValue} <span className="text-[10px] text-slate-400 font-normal">W/m·K</span>
                    </span>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Density (ρ)</span>
                    <span className="font-mono font-bold text-slate-200">
                      {mat.density} <span className="text-[10px] text-slate-400 font-normal">kg/m³</span>
                    </span>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Specific Heat (Cp)</span>
                    <span className="font-mono font-bold text-teal-300">
                      {mat.specificHeat} <span className="text-[10px] text-slate-400 font-normal">J/kg·K</span>
                    </span>
                  </div>

                  <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Est. Cost</span>
                    <span className="font-mono font-bold text-amber-300">
                      ₹{mat.costPerM3Inr.toLocaleString()} <span className="text-[10px] text-slate-400 font-normal">/m³</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => setSelectedMaterial(mat)}
                  className="flex-1 min-h-[44px] py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-semibold text-slate-200 transition-colors"
                >
                  VIEW SPECS
                </button>
                <button
                  onClick={() => {
                    setSelectedMaterial(mat);
                    onNavigate('assemblies');
                  }}
                  className="min-h-[44px] py-2 px-4 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>SELECT</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
