/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Cpu,
  Play,
  CheckCircle,
  ThermometerSnowflake,
  Sun,
  Flame,
  ArrowRight,
  Info,
  Clock,
  Zap,
} from 'lucide-react';
import { ScreenId, SimulationInput, SimulationResult } from '../../types';
import { thermalSimulationService } from '../../services/thermalSimulationService';
import { climateService } from '../../services/climateService';

interface ThermalSimulationScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ThermalSimulationScreen: React.FC<ThermalSimulationScreenProps> = ({ onNavigate }) => {
  const loc = climateService.getActiveLocation();
  const [duration, setDuration] = useState<6 | 12 | 24 | 48 | 168>(24);
  const [initialTemp, setInitialTemp] = useState<number>(17);
  const [heatingPowerKw, setHeatingPowerKw] = useState<number>(1.5);
  const [useTrombe, setUseTrombe] = useState<boolean>(true);
  const [usePcm, setUsePcm] = useState<boolean>(true);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const [result, setResult] = useState<SimulationResult>(() =>
    thermalSimulationService.run1DTransientSimulation({
      durationHours: 24,
      outdoorTempBase: loc.designWinterTemp,
      initialIndoorTemp: 17,
      heatingPowerKw: 1.5,
      timeStepSeconds: 300,
      useTrombeWall: true,
      usePcm: true,
    })
  );

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = thermalSimulationService.run1DTransientSimulation({
        durationHours: duration,
        outdoorTempBase: loc.designWinterTemp,
        initialIndoorTemp: initialTemp,
        heatingPowerKw,
        timeStepSeconds: 300,
        useTrombeWall: useTrombe,
        usePcm,
      });
      setResult(res);
      setIsRunning(false);
    }, 450);
  };

  // Generate chart paths
  const hoursCount = result.hourly.length;
  const minTempChart = -45;
  const maxTempChart = 25;
  const tempSpan = maxTempChart - minTempChart;

  const outdoorPoints = result.hourly
    .map((h, idx) => {
      const x = (idx / (hoursCount - 1 || 1)) * 600;
      const y = 180 - ((h.outdoorTemp - minTempChart) / tempSpan) * 160;
      return `${x},${y}`;
    })
    .join(' ');

  const indoorPoints = result.hourly
    .map((h, idx) => {
      const x = (idx / (hoursCount - 1 || 1)) * 600;
      const y = 180 - ((h.indoorTemp - minTempChart) / tempSpan) * 160;
      return `${x},${y}`;
    })
    .join(' ');

  // Comfort zone band (15°C to 20°C)
  const yComfortTop = 180 - ((20 - minTempChart) / tempSpan) * 160;
  const yComfortBottom = 180 - ((15 - minTempChart) / tempSpan) * 160;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            NUMERICAL TIME-STEPPING SIMULATION
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            1D TRANSIENT THERMAL SOLVER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Implicit Backward Euler numerical solution across composite layers with solar flux and Trombe buffering.
          </p>
        </div>

        <button
          onClick={() => onNavigate('heat_flow')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-2 self-start sm:self-center active:scale-95 transition-all"
        >
          <span>VIEW HEAT FLOW</span>
          <ArrowRight className="w-4 h-4 text-sky-400" />
        </button>
      </div>

      {/* Solver Specifications Banner */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div>
          <span className="text-slate-400 block font-mono">Numerical Model</span>
          <span className="font-bold text-white">1D transient finite difference</span>
        </div>
        <div>
          <span className="text-slate-400 block font-mono">Time Integration</span>
          <span className="font-bold text-sky-300">Implicit Backward Euler (Δt = 300s)</span>
        </div>
        <div>
          <span className="text-slate-400 block font-mono">Material Model</span>
          <span className="font-bold text-amber-300">Layered composite assembly</span>
        </div>
        <div>
          <span className="text-slate-400 block font-mono">Solver Status</span>
          <span className="font-bold text-emerald-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span> READY
          </span>
        </div>
      </div>

      {/* Controls & Inputs */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
          SIMULATION BOUNDARY CONDITIONS
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          {/* Duration Selector */}
          <div>
            <label className="text-slate-300 font-medium block mb-1.5">Simulation Duration</label>
            <div className="grid grid-cols-3 gap-1">
              {([6, 12, 24, 48, 168] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => setDuration(d)}
                  className={`py-1.5 px-2 rounded-lg font-mono font-semibold transition-colors ${
                    duration === d ? 'bg-sky-500 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {d === 168 ? '7 DAYS' : `${d}H`}
                </button>
              ))}
            </div>
          </div>

          {/* Initial Indoor Temp */}
          <div>
            <label className="text-slate-300 font-medium block mb-1.5">
              Initial Indoor Temp: <span className="font-mono font-bold text-sky-400">{initialTemp}°C</span>
            </label>
            <input
              type="range"
              min="5"
              max="25"
              step="1"
              value={initialTemp}
              onChange={(e) => setInitialTemp(parseInt(e.target.value) || 17)}
              className="w-full accent-sky-400 h-2 bg-slate-950 rounded-lg cursor-pointer mt-2"
            />
          </div>

          {/* Supplemental Heating Power */}
          <div>
            <label className="text-slate-300 font-medium block mb-1.5">
              Supplemental Heat: <span className="font-mono font-bold text-amber-400">{heatingPowerKw} kW</span>
            </label>
            <input
              type="range"
              min="0"
              max="4.0"
              step="0.25"
              value={heatingPowerKw}
              onChange={(e) => setHeatingPowerKw(parseFloat(e.target.value) || 0)}
              className="w-full accent-amber-400 h-2 bg-slate-950 rounded-lg cursor-pointer mt-2"
            />
          </div>

          {/* Passive Features Toggles */}
          <div className="flex flex-col gap-2 justify-end">
            <label className="flex items-center gap-2 cursor-pointer text-slate-300 select-none">
              <input
                type="checkbox"
                checked={useTrombe}
                onChange={(e) => setUseTrombe(e.target.checked)}
                className="w-4 h-4 accent-sky-400 rounded"
              />
              <span>Trombe Passive Wall</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer text-slate-300 select-none">
              <input
                type="checkbox"
                checked={usePcm}
                onChange={(e) => setUsePcm(e.target.checked)}
                className="w-4 h-4 accent-sky-400 rounded"
              />
              <span>PCM Thermal Storage</span>
            </label>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex justify-end pt-2">
          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="min-h-[48px] px-8 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs shadow-lg shadow-sky-600/30 flex items-center gap-2 active:scale-95 transition-all disabled:opacity-50"
          >
            <Play className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'SOLVING EQUATIONS...' : 'RUN SIMULATION'}</span>
          </button>
        </div>
      </div>

      {/* Primary Result Headline */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
              SIMULATED STEADY-STATE COMFORT
            </span>
            <div className="flex items-baseline gap-3 mt-1">
              <span className="text-4xl sm:text-5xl font-bold font-mono text-white">
                {result.avgIndoorTemp}°C
              </span>
              <span className="text-sm font-semibold text-emerald-400 font-mono">
                {result.comfortHours} of {result.totalComfortHours} Hours in Comfort Envelope
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              {result.label}
            </span>
          </div>
        </div>

        {/* Transient Graph Outdoor vs Indoor */}
        <div className="w-full bg-slate-950/80 rounded-xl p-4 border border-slate-800/80">
          <div className="flex flex-wrap items-center justify-between text-[11px] font-mono mb-2">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-white font-semibold">
                <span className="w-3 h-1 bg-white rounded-full"></span> Indoor Temperature
              </span>
              <span className="flex items-center gap-1.5 text-sky-400">
                <span className="w-3 h-1 bg-sky-400 rounded-full"></span> Outdoor Ambient ({loc.designWinterTemp}°C)
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-3 h-3 bg-emerald-500/20 border border-emerald-500/40 rounded-sm"></span> 15–20°C Comfort Zone
              </span>
            </div>
            <span className="text-slate-500">Duration: {duration} Hours</span>
          </div>

          <svg viewBox="0 0 600 200" className="w-full h-52 overflow-visible">
            {/* Comfort Zone Band */}
            <rect
              x="0"
              y={yComfortTop}
              width="600"
              height={Math.max(1, yComfortBottom - yComfortTop)}
              fill="rgba(16, 185, 129, 0.10)"
            />

            {/* Zero Degree line */}
            <line
              x1="0"
              y1={180 - ((0 - minTempChart) / tempSpan) * 160}
              x2="600"
              y2={180 - ((0 - minTempChart) / tempSpan) * 160}
              stroke="#475569"
              strokeDasharray="4 4"
            />

            {/* Outdoor Line */}
            <polyline
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              strokeDasharray="4 2"
              points={outdoorPoints}
            />

            {/* Indoor Line */}
            <polyline
              fill="none"
              stroke="#ffffff"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={indoorPoints}
            />
          </svg>

          <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2">
            <span>Hour 0</span>
            <span>Hour {Math.round(duration / 2)}</span>
            <span>Hour {duration} (End)</span>
          </div>
        </div>

        {/* Detailed Quantitative Output Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Min Indoor Temp</span>
            <span className="text-xl font-bold font-mono text-sky-300">{result.minIndoorTemp}°C</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Max Indoor Temp</span>
            <span className="text-xl font-bold font-mono text-amber-300">{result.maxIndoorTemp}°C</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Daily Heating Demand</span>
            <span className="text-xl font-bold font-mono text-teal-300">{result.dailyHeatingDemandKwh} kWh/day</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Solar Contribution</span>
            <span className="text-xl font-bold font-mono text-emerald-400">{result.solarContributionPct}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
