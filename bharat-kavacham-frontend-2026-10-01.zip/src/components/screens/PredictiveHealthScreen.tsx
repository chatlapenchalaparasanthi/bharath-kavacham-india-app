/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  HeartPulse,
  AlertTriangle,
  Info,
  CheckCircle,
  ArrowRight,
  ShieldCheck,
  Wrench,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { sensorService } from '../../services/sensorService';

interface PredictiveHealthScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const PredictiveHealthScreen: React.FC<PredictiveHealthScreenProps> = ({ onNavigate }) => {
  const health = sensorService.getShelterHealth();

  const components = [
    { name: 'Opaque Wall Envelope', score: health.wallScorePct, status: 'Healthy', note: 'No interstitial moisture or thermal bridge breach' },
    { name: 'Roof Assembly & Truss', score: health.roofScorePct, status: 'Attention', note: 'Snow load deflection within limits; sensor desync' },
    { name: 'Heating & Heat Recovery (HRV)', score: health.heatingScorePct, status: 'Optimal', note: 'Auxiliary heating coils operating at rated draw' },
    { name: 'Sensor & Thermocouple Bus', score: health.sensorsScorePct, status: 'Calibration Rec.', note: 'Roof pyranometer thermocouple drift logged' },
    { name: 'Trombe Damper Actuator Motor', score: health.motorScorePct, status: 'Normal', note: 'Low-temperature mechanical seals intact' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            MACHINE LEARNING HEALTH DIAGNOSTICS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SHELTER HEALTH
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Component degradation forecast, insulation aging analysis, and proactive maintenance cues.
          </p>
        </div>

        <button
          onClick={() => onNavigate('thermal_memory')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>THERMAL MEMORY AI</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Overall Score Headline */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
              OVERALL STRUCTURAL & THERMAL HEALTH
            </span>
            <div className="flex items-baseline gap-3 mt-1">
              <span className="text-5xl font-bold font-mono text-emerald-400">
                {health.overallScorePct}%
              </span>
              <span className="text-sm font-semibold text-slate-200">
                Operational Field Readiness Score
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-sky-500/10 text-sky-300 border border-sky-500/30">
              PREDICTIVE MODEL
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-sky-500 to-emerald-400 rounded-full"
            style={{ width: `${health.overallScorePct}%` }}
          ></div>
        </div>
      </div>

      {/* Subsystem Health Progress Bars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {components.map((c, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex justify-between items-baseline text-xs">
              <span className="font-bold text-white font-['Chakra_Petch']">{c.name}</span>
              <span className="font-mono font-bold text-emerald-400 text-sm">{c.score}%</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full rounded-full ${
                  c.score >= 90 ? 'bg-emerald-400' : c.score >= 84 ? 'bg-sky-400' : 'bg-amber-400'
                }`}
                style={{ width: `${c.score}%` }}
              ></div>
            </div>
            <p className="text-[11px] text-slate-400">{c.note}</p>
          </div>
        ))}
      </div>

      {/* Predictive Maintenance Alerts */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-['Chakra_Petch'] font-bold text-base text-white flex items-center gap-2">
            <Wrench className="w-4 h-4 text-sky-400" />
            MAINTENANCE QUEUE & EARLY WARNINGS
          </h3>
          <span className="text-xs font-mono text-slate-400">
            {health.alerts.length} Items Logged
          </span>
        </div>

        <div className="space-y-3">
          {health.alerts.map((alt) => (
            <div
              key={alt.id}
              className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-start justify-between gap-3 ${
                alt.severity === 'WARNING'
                  ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                  : 'bg-slate-950 border-slate-800 text-slate-300'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      alt.severity === 'WARNING'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                    }`}
                  >
                    {alt.severity}
                  </span>
                  <h4 className="text-xs sm:text-sm font-bold text-white font-['Chakra_Petch']">
                    {alt.title}
                  </h4>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({alt.component})
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {alt.message}
                </p>
                <div className="text-[11px] font-mono text-sky-300 pt-1">
                  Action: {alt.recommendation}
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[10px] font-mono text-slate-400 block">
                  {alt.timestamp}
                </span>
                <span className="text-[10px] font-mono text-amber-400 font-bold">
                  PREDICTIVE MODEL
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
