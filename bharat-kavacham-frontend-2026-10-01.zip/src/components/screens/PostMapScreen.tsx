/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  MapPin,
  Layers,
  ThermometerSnowflake,
  ShieldCheck,
  Activity,
  ArrowRight,
  Info,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface PostMapScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const PostMapScreen: React.FC<PostMapScreenProps> = ({ onNavigate }) => {
  const [activeLayer, setActiveLayer] = useState<'thermal' | 'sensor' | 'maintenance' | 'alert'>('thermal');

  const posts = [
    { id: 'p1', name: 'Post 14 - Siachen Glacier', x: 280, y: 80, temp: '17.2°C', loss: 'Normal', status: 'GREEN', alert: 'All nominal' },
    { id: 'p2', name: 'Post 08 - Daulat Beg Oldi (DBO)', x: 380, y: 50, temp: '14.8°C', loss: 'Attention', status: 'YELLOW', alert: 'Door seal check' },
    { id: 'p3', name: 'Post 22 - Dras Ridge Point', x: 140, y: 150, temp: '11.5°C', loss: 'High Loss', status: 'RED', alert: 'Wall insulation leak' },
    { id: 'p4', name: 'Post 05 - Kargil Forward', x: 180, y: 170, temp: '16.5°C', loss: 'Normal', status: 'GREEN', alert: 'Comfort stable' },
    { id: 'p5', name: 'Post 01 - Leh Base Hospital Shelter', x: 260, y: 200, temp: '18.0°C', loss: 'Normal', status: 'GREEN', alert: 'All nominal' },
    { id: 'p6', name: 'Post 31 - Nyoma Airfield Post', x: 410, y: 220, temp: '15.9°C', loss: 'Normal', status: 'GREEN', alert: 'All nominal' },
  ];

  const [selectedPost, setSelectedPost] = useState(posts[0]);

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            GEOSPATIAL FLEET RADAR
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            POST RADAR / INTELLIGENCE MAP
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Tactical distribution map across Northern Himalayan posts with multi-layer thermal diagnostics.
          </p>
        </div>

        <button
          onClick={() => onNavigate('command_center')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>COMMAND CENTER</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Layer Toggles & Color Legend */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        {/* Layer Selector */}
        <div className="flex flex-wrap gap-1.5">
          {(['thermal', 'sensor', 'maintenance', 'alert'] as const).map((layer) => (
            <button
              key={layer}
              onClick={() => setActiveLayer(layer)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase font-['Chakra_Petch'] transition-all ${
                activeLayer === layer
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200'
              }`}
            >
              {layer} Layer
            </button>
          ))}
        </div>

        {/* Color Legend required by prompt */}
        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="flex items-center gap-1.5 text-red-400">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span> RED: High thermal loss
          </span>
          <span className="flex items-center gap-1.5 text-amber-400">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> YELLOW: Attention required
          </span>
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> GREEN: Normal
          </span>
        </div>
      </div>

      {/* Map & Post Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tactical Map Canvas */}
        <div className="lg:col-span-8 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>SECTOR: LADAKH & KARAKORAM CORRIDOR</span>
            <span>6 Active Field Shelters</span>
          </div>

          <div className="relative w-full aspect-video max-h-[380px] bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 540 300" className="w-full h-full max-w-[520px]">
              {/* Topographic Lines */}
              <path d="M 50,150 Q 150,120 250,180 T 450,140" fill="none" stroke="#1e293b" strokeWidth="1.5" />
              <path d="M 80,180 Q 200,160 300,220 T 500,190" fill="none" stroke="#1e293b" strokeWidth="1.5" />
              <path d="M 200,60 Q 300,40 400,90" fill="none" stroke="#1e293b" strokeWidth="1.5" />

              {/* Connecting Mesh lines */}
              <line x1="280" y1="80" x2="380" y2="50" stroke="#334155" strokeDasharray="3 3" />
              <line x1="280" y1="80" x2="260" y2="200" stroke="#334155" strokeDasharray="3 3" />
              <line x1="140" y1="150" x2="180" y2="170" stroke="#334155" strokeDasharray="3 3" />
              <line x1="180" y1="170" x2="260" y2="200" stroke="#334155" strokeDasharray="3 3" />
              <line x1="260" y1="200" x2="410" y2="220" stroke="#334155" strokeDasharray="3 3" />

              {/* Render Posts */}
              {posts.map((p) => {
                const isSelected = selectedPost.id === p.id;
                const nodeColor = p.status === 'RED' ? '#ef4444' : p.status === 'YELLOW' ? '#f59e0b' : '#10b981';
                return (
                  <g key={p.id} className="cursor-pointer" onClick={() => setSelectedPost(p)}>
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r={isSelected ? 10 : 7}
                      fill={nodeColor}
                      opacity={isSelected ? 1.0 : 0.85}
                      stroke="#ffffff"
                      strokeWidth={isSelected ? 2 : 0}
                    />
                    <text
                      x={p.x}
                      y={p.y - 12}
                      fill="#ffffff"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="middle"
                      className="font-bold pointer-events-none drop-shadow"
                    >
                      {p.name.split(' - ')[0]}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Selected Post Detail Inspector */}
        <div className="lg:col-span-4 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="pb-3 border-b border-slate-800">
            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-wider block">
              SELECTED POST STATUS
            </span>
            <h3 className="font-['Chakra_Petch'] font-bold text-lg text-white">
              {selectedPost.name}
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Indoor Temp:</span>
              <span className="font-mono font-bold text-white text-base">{selectedPost.temp}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Thermal Envelope Status:</span>
              <span
                className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                  selectedPost.status === 'RED'
                    ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                    : selectedPost.status === 'YELLOW'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                }`}
              >
                {selectedPost.loss}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-500 block text-[11px] font-mono">Telemetry Alert:</span>
              <span className="text-slate-200 font-medium">{selectedPost.alert}</span>
            </div>
          </div>

          <button
            onClick={() => onNavigate('qr_identity')}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <span>Inspect QR Shelter Identity</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
