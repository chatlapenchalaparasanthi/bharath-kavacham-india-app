/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Share2,
  Printer,
  CheckCircle,
  Eye,
  ArrowRight,
  Shield,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { climateService } from '../../services/climateService';
import { thermalSimulationService } from '../../services/thermalSimulationService';
import { exportZipService } from '../../services/exportZipService';

interface ReportGeneratorScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ReportGeneratorScreen: React.FC<ReportGeneratorScreenProps> = ({ onNavigate }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const loc = climateService.getActiveLocation();
  const geom = thermalSimulationService.getGeometry();

  const sections = [
    '1. Project Information & Identity (BHARAT KAVACHAM PK-2026-26051)',
    '2. Design Location & Elevation (Siachen Base 5400m AGL)',
    '3. Climate Dataset & NASA POWER Diurnal Profiles',
    '4. Parametric Shelter Geometry (6.0m × 4.0m × 2.8m, South Facing)',
    '5. Material Selection (PUF, AAC, Himalayan Stone, Aerogel)',
    '6. Wall Assembly Stack & Condensation Plane Analysis (U=0.18 W/m²K)',
    '7. Roof Assembly & Snow-Shedding Pitch Specification (U=0.14 W/m²K)',
    '8. Ground Permafrost Thermal Break Floor Assembly (U=0.22 W/m²K)',
    '9. 1D Transient Thermal Solver & Implicit Backward Euler Stability',
    '10. Heat Flow Decomposition (Wall 40%, Roof 30%, Floor 15%, Door 8%, Vent 7%)',
    '11. Design Space Exploration (324 Permutations Evaluated)',
    '12. Multi-Objective Pareto Frontier Optimization',
    '13. Passive Solar Trombe Wall & 12 kWh PCM Latent Thermal Battery',
    '14. Energy Demand Synthesis (178 → 21 kWh/day, 88% Reduction)',
    '15. Environmental & Logistics Impact (Diesel Avoided, CO2 Displaced)',
    '16. Model Numerical Validation & Benchmark Convergence Verification',
  ];

  const handleExportPdf = () => {
    setIsExporting(true);
    setTimeout(() => {
      window.print();
      setIsExporting(false);
      setExportNotice('Technical report prepared for PDF printing or export.');
      setTimeout(() => setExportNotice(null), 3000);
    }, 400);
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            ENGINEERING DOSSIER COMPILATION
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            GENERATE TECHNICAL REPORT
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Full 16-section comprehensive technical documentation and verification package.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleExportPdf}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all"
          >
            <Printer className="w-4 h-4 text-sky-400" />
            <span>Print / PDF</span>
          </button>

          <button
            onClick={() => exportZipService.generateAndDownloadZip()}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-sky-600/25 active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Export Codebase (.ZIP)</span>
          </button>
        </div>
      </div>

      {exportNotice && (
        <div className="p-3 rounded-xl bg-sky-950/60 border border-sky-800 text-xs font-mono text-sky-300 animate-fadeIn flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{exportNotice}</span>
        </div>
      )}

      {/* 16 Sections Check Overview */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
            16-SECTION TECHNICAL DOSSIER INDEX
          </h3>
          <span className="text-xs font-mono text-emerald-400">16 / 16 Validated</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {sections.map((sec, idx) => (
            <div
              key={idx}
              className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2 text-slate-300"
            >
              <CheckCircle className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="truncate">{sec}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Executive Summary Preview Card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="font-['Chakra_Petch'] font-bold text-base text-white flex items-center gap-2">
          <Eye className="w-4 h-4 text-sky-400" />
          EXECUTIVE TECHNICAL SUMMARY PREVIEW
        </h3>

        <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-3 font-mono">
          <p>
            <strong>PROJECT:</strong> BHARAT KAVACHAM — Area-Specific Thermal Shelter Intelligence Platform
          </p>
          <p>
            <strong>LOCATION:</strong> {loc.name} ({loc.altitudeMeters}m AGL) · Winter Design Baseline: {loc.designWinterTemp}°C
          </p>
          <p>
            <strong>PERFORMANCE:</strong> Indoor Mean Temperature 17.0°C achieved with 21 kWh/day auxiliary heating. Fuel reduction: 88% compared to uninsulated baseline (178 kWh/day).
          </p>
          <p>
            <strong>RELIABILITY:</strong> 1D Transient implicit Backward Euler solver confirms stable comfort envelope under sub-zero diurnal swing.
          </p>
          <p className="text-amber-400 pt-2 border-t border-slate-800">
            * All figures labeled: "Demo Simulation" / "Model Result — Requires Field Validation".
          </p>
        </div>
      </div>
    </div>
  );
};
