/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  ThermometerSnowflake,
  Wind,
  Sun,
  Flame,
  Zap,
  PieChart,
  HardDrive,
  Cpu,
  CloudSun,
  Compass,
  Boxes,
  SunMedium,
  Activity,
  FileSpreadsheet,
  Camera,
  ChevronRight,
  ShieldAlert,
  ArrowUpRight,
} from 'lucide-react';
import { LanguageCode, ScreenId } from '../../types';
import { translations } from '../../localization/translations';
import { climateService } from '../../services/climateService';

interface HomeScreenProps {
  onNavigate: (screen: ScreenId) => void;
  language: LanguageCode;
  onOpenDrawer: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  language,
}) => {
  const t = translations[language];
  const activeLoc = climateService.getActiveLocation();
  const climateData = climateService.getClimateData(activeLoc.id);

  const quickActions = [
    {
      id: 'simulation' as ScreenId,
      name: 'RUN SIMULATION',
      desc: '1D Transient Backward Euler solver',
      icon: Cpu,
      color: 'from-sky-500/20 to-blue-500/10 text-sky-400 border-sky-500/30',
    },
    {
      id: 'climate' as ScreenId,
      name: 'CLIMATE DATA',
      desc: 'Diurnal solar radiation & wind',
      icon: CloudSun,
      color: 'from-amber-500/20 to-orange-500/10 text-amber-400 border-amber-500/30',
    },
    {
      id: 'shelter_design' as ScreenId,
      name: 'DESIGN SHELTER',
      desc: 'Parametric dimensions & roof form',
      icon: Compass,
      color: 'from-cyan-500/20 to-teal-500/10 text-cyan-400 border-cyan-500/30',
    },
    {
      id: 'materials' as ScreenId,
      name: 'MATERIAL DATABASE',
      desc: 'PUF, AAC, Himalayan Stone & Aerogel',
      icon: Boxes,
      color: 'from-indigo-500/20 to-purple-500/10 text-indigo-400 border-indigo-500/30',
    },
    {
      id: 'solar_pcm' as ScreenId,
      name: 'SOLAR STORAGE',
      desc: 'Trombe passive wall & PCM thermal bank',
      icon: SunMedium,
      color: 'from-amber-500/20 to-yellow-500/10 text-amber-300 border-amber-500/30',
    },
    {
      id: 'field_monitor' as ScreenId,
      name: 'FIELD MONITOR',
      desc: '6-channel IoT telemetry & health',
      icon: Activity,
      color: 'from-emerald-500/20 to-green-500/10 text-emerald-400 border-emerald-500/30',
    },
    {
      id: 'reports' as ScreenId,
      name: 'TECHNICAL REPORT',
      desc: '16-section export & simulation logs',
      icon: FileSpreadsheet,
      color: 'from-blue-500/20 to-slate-500/10 text-blue-400 border-blue-500/30',
    },
    {
      id: 'ar_preview' as ScreenId,
      name: 'AR PREVIEW',
      desc: 'Spatial footprint overlay on terrain',
      icon: Camera,
      color: 'from-violet-500/20 to-fuchsia-500/10 text-violet-400 border-violet-500/30',
    },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full pb-24">
      {/* Top Welcome / Mission Status Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-sky-500/10 to-transparent pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-mono font-bold tracking-wider text-emerald-400">
                {t.systemOnline}
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-xs font-mono text-slate-400">SI-2026 TACTICAL RELEASE</span>
            </div>
            <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white tracking-wide">
              {t.appName}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              Software-Based Model Development for Design of Area-Specific Shelter for Thermal Comfort Maintenance in Sub-Zero Himalayan Altitudes.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-center">
            <button
              onClick={() => onNavigate('location_select')}
              className="min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-2 transition-all active:scale-95"
            >
              <span>{t.changeLocation}</span>
              <ChevronRight className="w-4 h-4 text-sky-400" />
            </button>
            <button
              onClick={() => onNavigate('presentation')}
              className="min-h-[48px] px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95"
            >
              <Flame className="w-4 h-4" />
              <span>Demo Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Climate Summary Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
          <div>
            <div className="text-[11px] font-mono text-sky-400 uppercase tracking-wider">
              DESIGN LOCATION ENVIRONMENT
            </div>
            <div className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <span>{activeLoc.name}</span>
              <span className="text-xs text-slate-400 font-normal">({activeLoc.altitudeMeters}m AGL)</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400">Data Source:</span>
            <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-sky-300 border border-slate-700">
              {climateData.source} / DEMO DATA
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-sky-500/10 text-sky-400">
              <ThermometerSnowflake className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] font-medium text-slate-400">{t.outdoorTemp}</div>
              <div className="text-2xl font-bold font-mono text-sky-300">
                {activeLoc.designWinterTemp}°C
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-teal-500/10 text-teal-400">
              <Wind className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] font-medium text-slate-400">{t.windSpeed}</div>
              <div className="text-2xl font-bold font-mono text-slate-100">
                {activeLoc.avgWindKmh} <span className="text-xs text-slate-400 font-normal">km/h</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Sun className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] font-medium text-slate-400">{t.solarRadiation}</div>
              <div className="text-2xl font-bold font-mono text-amber-300">
                {activeLoc.dailySolarGhiKwh} <span className="text-xs text-slate-400 font-normal">kWh/m²/day</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* KPI 1: Thermal Comfort */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 relative flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.thermalComfort}
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              {t.comfortable}
            </span>
          </div>
          <div className="my-2">
            <div className="text-4xl font-bold font-mono text-white tracking-tight">
              17°C
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Target Envelope: <strong className="text-slate-200">15–20°C</strong> (ASHRAE / Cold Protocol)
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-500">
            <span>Ambient: {activeLoc.designWinterTemp}°C</span>
            <span className="text-sky-400">ΔT = {17 - activeLoc.designWinterTemp}°C</span>
          </div>
        </div>

        {/* KPI 2: Energy Demand */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 relative flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.energyDemand}
            </span>
            <span className="text-[11px] font-mono text-sky-400 font-medium">
              SIMULATION
            </span>
          </div>
          <div className="my-2">
            <div className="text-4xl font-bold font-mono text-sky-300 tracking-tight">
              21 <span className="text-lg text-slate-400 font-sans font-normal">kWh/day</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Uninsulated Baseline: <span className="line-through text-slate-500">178 kWh/day</span>
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-amber-400/90">
            Requires Field Validation
          </div>
        </div>

        {/* KPI 3: Heat Loss */}
        <div
          onClick={() => onNavigate('heat_flow')}
          className="bg-slate-900 border border-slate-800 hover:border-sky-500/40 rounded-2xl p-4 sm:p-5 cursor-pointer group transition-all relative flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.heatLoss}
            </span>
            <span className="text-[11px] font-semibold text-sky-400 group-hover:underline flex items-center gap-0.5">
              VIEW BREAKDOWN <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-4xl font-bold font-mono text-white tracking-tight">
              100%
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Wall (40%) · Roof (30%) · Floor (15%) · Door/Vent (15%)
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
            Tap to inspect layer-by-layer flux
          </div>
        </div>

        {/* KPI 4: Solar Contribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 relative flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.solarContribution}
            </span>
            <span className="text-[11px] font-mono text-amber-400 font-medium">
              SIMULATION
            </span>
          </div>
          <div className="my-2">
            <div className="text-4xl font-bold font-mono text-amber-300 tracking-tight">
              68%
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Passive Trombe glazing + South daylight aperture
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-500">
            Storage: 8.4 kWh in PCM core
          </div>
        </div>

        {/* KPI 5: Fuel Saving */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 relative flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.fuelSaving}
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-medium">
              MODEL ESTIMATE
            </span>
          </div>
          <div className="my-2">
            <div className="text-4xl font-bold font-mono text-emerald-400 tracking-tight">
              88%
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Displaces ~112 L kerosene/diesel per shelter daily
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-amber-400/90">
            Model Result — Requires Field Validation
          </div>
        </div>

        {/* KPI 6: Offline Status */}
        <div
          onClick={() => onNavigate('offline_center')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 cursor-pointer group relative flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.offlineStatus}
            </span>
            <span className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              {t.ready}
            </span>
          </div>
          <div className="my-2">
            <div className="text-3xl font-bold font-mono text-slate-200">
              OFFLINE READY
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Climate, Materials, Models & Voice cached locally
            </div>
          </div>
          <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 group-hover:text-sky-400">
            Last sync: 14:20 IST · Tap to manage
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS SECTION */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-['Chakra_Petch'] font-bold text-lg text-white tracking-wide">
            {t.quickActions}
          </h2>
          <span className="text-xs font-mono text-slate-400">8 Modules Ready</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={() => onNavigate(action.id)}
                className="min-h-[72px] p-4 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-left flex flex-col justify-between group transition-all active:scale-[0.98] shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <div className={`p-2.5 rounded-lg bg-gradient-to-br ${action.color} border shadow-inner`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-bold text-white font-['Chakra_Petch'] tracking-wide">
                    {action.name}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                    {action.desc}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Research & Forward Integration Disclaimer Footer Card */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="text-slate-200">RESEARCH PLATFORM INTEGRATION NOTICE:</strong> Designed as an integration-ready software model and prototype frontend. Potential research/institutional integration with defence agencies (DRDO / DIHAR) does not imply pre-deployment certification until calibrated field trials are logged.
        </div>
      </div>
    </div>
  );
};
