/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  QrCode,
  CheckCircle,
  Scan,
  ShieldCheck,
  History,
  Layers,
  Cpu,
  ArrowRight,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface QrIdentityScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const QrIdentityScreen: React.FC<QrIdentityScreenProps> = ({ onNavigate }) => {
  const [isScanned, setIsScanned] = useState(true);

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            CRYPTOGRAPHIC FIELD ASSET PASSPORT
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SHELTER ID: PK-2026-26051
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Physical QR verification plate mounted inside airlock for field maintenance, CAD spec, and calibration logs.
          </p>
        </div>

        <button
          onClick={() => onNavigate('environmental')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>ENVIRONMENTAL IMPACT</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Main Grid: QR Card on Left, Asset Passport on Right */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* QR Plate */}
        <div className="md:col-span-5 p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-between text-center space-y-4">
          <div className="space-y-1">
            <span className="text-[11px] font-mono text-sky-400 uppercase tracking-wider block">
              OFFICIAL EQUIPMENT IDENTIFIER
            </span>
            <h2 className="font-['Chakra_Petch'] font-bold text-2xl text-white">
              PK-2026-26051
            </h2>
            <p className="text-xs text-slate-400">Siachen North Glacial Sector · Unit 04</p>
          </div>

          {/* High Contrast Clean SVG QR Code */}
          <div className="p-4 bg-white rounded-2xl shadow-xl border-4 border-slate-300 flex items-center justify-center">
            <svg viewBox="0 0 160 160" className="w-44 h-44">
              {/* Corner position squares */}
              <rect x="10" y="10" width="40" height="40" fill="#0f172a" rx="4" />
              <rect x="20" y="20" width="20" height="20" fill="#ffffff" />
              <rect x="110" y="10" width="40" height="40" fill="#0f172a" rx="4" />
              <rect x="120" y="20" width="20" height="20" fill="#ffffff" />
              <rect x="10" y="110" width="40" height="40" fill="#0f172a" rx="4" />
              <rect x="20" y="120" width="20" height="20" fill="#ffffff" />

              {/* Data Blocks */}
              <rect x="60" y="20" width="10" height="20" fill="#0f172a" />
              <rect x="80" y="10" width="20" height="10" fill="#0f172a" />
              <rect x="70" y="40" width="20" height="10" fill="#0f172a" />
              <rect x="60" y="60" width="40" height="40" fill="#0f172a" rx="2" />
              <circle cx="80" cy="80" r="10" fill="#ffffff" />
              <rect x="20" y="60" width="10" height="30" fill="#0f172a" />
              <rect x="40" y="70" width="10" height="20" fill="#0f172a" />
              <rect x="110" y="60" width="20" height="10" fill="#0f172a" />
              <rect x="130" y="80" width="20" height="10" fill="#0f172a" />
              <rect x="60" y="110" width="10" height="40" fill="#0f172a" />
              <rect x="80" y="120" width="30" height="10" fill="#0f172a" />
              <rect x="120" y="110" width="20" height="20" fill="#0f172a" />
              <rect x="90" y="140" width="40" height="10" fill="#0f172a" />
            </svg>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400">
            <CheckCircle className="w-4 h-4" />
            <span>Digital Signature Verified · DIHAR Spec</span>
          </div>
        </div>

        {/* Passport Scanned Data */}
        <div className="md:col-span-7 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
              SHELTER ASSET PASSPORT DATA
            </h3>
            <span className="text-xs font-mono text-sky-400">Status: Active</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Commission Date:</span>
              <span className="font-mono font-bold text-white">12 October 2025</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Material Configuration:</span>
              <span className="font-mono font-bold text-sky-300">PUF 120mm + Trombe Core + AAC</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Simulation Baseline:</span>
              <span className="font-mono font-bold text-emerald-400">21 kWh/day (88% Fuel Avoided)</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Thermal Memory Log:</span>
              <span className="font-mono font-bold text-white">Winter 2025 Peak -35°C (Passed)</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Last Field Maintenance:</span>
              <span className="font-mono font-bold text-amber-400">28 Aug 2026 (Damper Lubrication)</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Sensor Mesh Health:</span>
              <span className="font-mono font-bold text-emerald-400">98% Nominal (All 6 Probes OK)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
