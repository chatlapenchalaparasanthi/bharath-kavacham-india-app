/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  SunMedium,
  BatteryCharging,
  ArrowRight,
  Flame,
  Clock,
  Sparkles,
  Zap,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface SolarPcmScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const SolarPcmScreen: React.FC<SolarPcmScreenProps> = ({ onNavigate }) => {
  const [selectedHour, setSelectedHour] = useState<number>(14);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setSelectedHour((prev) => (prev + 1) % 24);
    }, 1200);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const isDay = selectedHour >= 6 && selectedHour <= 17;
  const isPeakSolar = selectedHour >= 11 && selectedHour <= 14;
  const isNightDischarge = selectedHour >= 18 || selectedHour <= 5;

  const solarWatts = isDay ? Math.round(Math.sin(((selectedHour - 6) / 12) * Math.PI) * 780) : 0;
  const pcmTemp = isDay ? Math.round((19 + Math.sin(((selectedHour - 6) / 12) * Math.PI) * 7) * 10) / 10 : 20.8;
  const storedKwh = isDay
    ? Math.round((5.0 + Math.sin(((selectedHour - 6) / 12) * Math.PI) * 3.4) * 10) / 10
    : Math.round((8.4 - ((selectedHour > 17 ? selectedHour - 18 : selectedHour + 6) / 12) * 3.2) * 10) / 10;

  const chargePct = Math.round((storedKwh / 12.0) * 100);

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            PASSIVE SOLAR ENTHALPY STORAGE
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SOLAR THERMAL STORAGE (TROMBE + PCM)
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Phase Change Material latent heat buffering coupled with South-facing glazed Trombe wall.
          </p>
        </div>

        <button
          onClick={() => onNavigate('field_monitor')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>FIELD TELEMETRY</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Primary Battery Component */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="text-xs font-mono text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <BatteryCharging className="w-4 h-4" /> THERMAL STORAGE STATUS
            </div>
            <h2 className="font-['Chakra_Petch'] font-bold text-xl text-white mt-1">
              Latent Phase Change Battery Core
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              SIMULATION
            </span>
          </div>
        </div>

        {/* Battery Meter Visual */}
        <div className="space-y-2">
          <div className="flex justify-between items-baseline text-xs font-mono">
            <span className="text-slate-300">
              Stored Enthalpy: <strong className="text-amber-300 font-bold text-base">{storedKwh} kWh thermal</strong>
            </span>
            <span className="text-slate-400">
              Capacity: <strong>12.0 kWh thermal</strong> ({chargePct}%)
            </span>
          </div>

          <div className="relative w-full h-8 bg-slate-950 rounded-xl p-1 border border-slate-800 flex items-center">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-lg transition-all duration-500 shadow-md shadow-amber-500/20"
              style={{ width: `${chargePct}%` }}
            ></div>
            <span className="absolute inset-0 flex items-center justify-center text-xs font-mono font-bold text-white drop-shadow">
              {chargePct}% CHARGED · {isDay ? 'CHARGING' : 'DISCHARGING INTO LIVING ZONE'}
            </span>
          </div>
        </div>

        {/* Real-Time Flux Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-2">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Solar Incident Input</span>
            <span className="text-xl font-bold font-mono text-amber-400">{solarWatts} W/m²</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">PCM Core Temp</span>
            <span className="text-xl font-bold font-mono text-white">{pcmTemp}°C</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Charging Status</span>
            <span className={`text-sm font-bold font-mono ${isDay ? 'text-amber-400' : 'text-slate-500'}`}>
              {isDay ? '● ABSORBING' : 'IDLE'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Discharging Status</span>
            <span className={`text-sm font-bold font-mono ${isNightDischarge ? 'text-emerald-400' : 'text-slate-500'}`}>
              {isNightDischarge ? '● RELEASING HEAT' : 'STANDBY'}
            </span>
          </div>
        </div>
      </div>

      {/* Visual Flux Flow Diagram */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
          THERMAL TRANSFER CASCADE (SUN → TROMBE → PCM → SHELTER)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 relative">
          <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/40 text-center space-y-1">
            <div className="text-2xl">☀️</div>
            <div className="text-xs font-bold text-amber-300 font-['Chakra_Petch']">1. SOLAR FLUX</div>
            <div className="text-[11px] text-slate-400">High-altitude GHI rays penetrate south glazing</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-sky-500/40 text-center space-y-1">
            <div className="text-2xl">🧱</div>
            <div className="text-xs font-bold text-sky-300 font-['Chakra_Petch']">2. TROMBE WALL</div>
            <div className="text-[11px] text-slate-400">Dense masonry absorbs shortwave diurnal radiation</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 text-center space-y-1">
            <div className="text-2xl">🧪</div>
            <div className="text-xs font-bold text-emerald-300 font-['Chakra_Petch']">3. PCM STORAGE</div>
            <div className="text-[11px] text-slate-400">Phase transition locks latent enthalpy at 21°C</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-purple-500/40 text-center space-y-1">
            <div className="text-2xl">🏠</div>
            <div className="text-xs font-bold text-purple-300 font-['Chakra_Petch']">4. SHELTER LIVING</div>
            <div className="text-[11px] text-slate-400">Slow nocturnal radiation maintains 17°C warmth</div>
          </div>
        </div>
      </div>

      {/* 24-Hour Timeline */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
            24-HOUR DIURNAL STORAGE TIMELINE
          </h3>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-3 py-1 rounded bg-slate-800 text-xs text-sky-300 font-mono hover:bg-slate-700"
          >
            {isPlaying ? 'Pause Loop' : 'Play Loop'}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div
            onClick={() => setSelectedHour(6)}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              selectedHour >= 6 && selectedHour < 12
                ? 'bg-amber-500/20 border-amber-500 text-white'
                : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            <span className="font-mono font-bold block text-sm">06:00</span>
            <span className="font-bold text-amber-300 block">SOLAR CHARGING</span>
            <span className="text-[10px]">Sun ascends, glazing air warms</span>
          </div>

          <div
            onClick={() => setSelectedHour(12)}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              selectedHour >= 12 && selectedHour < 18
                ? 'bg-amber-500/20 border-amber-500 text-white'
                : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            <span className="font-mono font-bold block text-sm">12:00</span>
            <span className="font-bold text-amber-300 block">MAXIMUM CHARGE</span>
            <span className="text-[10px]">PCM core melts at peak enthalpy</span>
          </div>

          <div
            onClick={() => setSelectedHour(18)}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              selectedHour >= 18 && selectedHour < 24
                ? 'bg-sky-500/20 border-sky-500 text-white'
                : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            <span className="font-mono font-bold block text-sm">18:00</span>
            <span className="font-bold text-sky-300 block">DISCHARGE START</span>
            <span className="text-[10px]">Ambient drops to -35°C; dampers open</span>
          </div>

          <div
            onClick={() => setSelectedHour(0)}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              selectedHour >= 0 && selectedHour < 6
                ? 'bg-sky-500/20 border-sky-500 text-white'
                : 'bg-slate-950 border-slate-800 text-slate-400'
            }`}
          >
            <span className="font-mono font-bold block text-sm">00:00</span>
            <span className="font-bold text-sky-300 block">THERMAL RELEASE</span>
            <span className="text-[10px]">Latent heat keeps interior at 17°C</span>
          </div>
        </div>
      </div>
    </div>
  );
};
