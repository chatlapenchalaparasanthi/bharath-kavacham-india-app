/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Compass,
  Box,
  Maximize2,
  Users,
  Wind,
  Layers,
  ArrowRight,
  Sun,
  Eye,
} from 'lucide-react';
import { ScreenId, ShelterGeometryModel } from '../../types';
import { thermalSimulationService } from '../../services/thermalSimulationService';

interface ShelterDesignScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ShelterDesignScreen: React.FC<ShelterDesignScreenProps> = ({ onNavigate }) => {
  const [geometry, setGeometry] = useState<ShelterGeometryModel>(
    thermalSimulationService.getGeometry()
  );

  const updateField = <K extends keyof ShelterGeometryModel>(
    key: K,
    val: ShelterGeometryModel[K]
  ) => {
    const updated = thermalSimulationService.updateGeometry({ [key]: val });
    setGeometry(updated);
  };

  // Enclosure calculations
  const floorArea = Math.round(geometry.lengthM * geometry.widthM * 10) / 10;
  const volume = Math.round(floorArea * geometry.heightM * 10) / 10;
  const grossWallArea = Math.round(2 * (geometry.lengthM + geometry.widthM) * geometry.heightM * 10) / 10;
  const windowArea = Math.round(grossWallArea * geometry.windowToWallRatio * 10) / 10;
  const doorArea = 3.8;
  const roofArea = Math.round(floorArea * (geometry.roofType === 'sloped' ? 1.08 : geometry.roofType === 'dome' ? 1.25 : 1.0) * 10) / 10;
  const totalSurfaceArea = Math.round((grossWallArea + roofArea + floorArea) * 10) / 10;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            PARAMETRIC ENVELOPE GEOMETRY
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SHELTER DESIGN WORKSPACE
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Optimize envelope volume, aspect ratio, and passive solar orientation for high-altitude thermal retention.
          </p>
        </div>

        <button
          onClick={() => onNavigate('assemblies')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>BUILD ASSEMBLIES</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Main Grid: Parameters on Left, 2D Interactive Blueprint on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls Column */}
        <div className="lg:col-span-7 space-y-5">
          {/* Dimensional Sliders */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider flex items-center gap-2">
              <Box className="w-4 h-4" />
              DIMENSIONS & PROPORTIONS
            </h3>

            {/* Length */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Shelter Length (m)</span>
                <span className="font-mono font-bold text-sky-400">{geometry.lengthM} m</span>
              </div>
              <input
                type="range"
                min="3.0"
                max="12.0"
                step="0.5"
                value={geometry.lengthM}
                onChange={(e) => updateField('lengthM', parseFloat(e.target.value))}
                className="w-full accent-sky-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
              />
            </div>

            {/* Width */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Shelter Width (m)</span>
                <span className="font-mono font-bold text-sky-400">{geometry.widthM} m</span>
              </div>
              <input
                type="range"
                min="2.5"
                max="8.0"
                step="0.5"
                value={geometry.widthM}
                onChange={(e) => updateField('widthM', parseFloat(e.target.value))}
                className="w-full accent-sky-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
              />
            </div>

            {/* Height */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Internal Height (m)</span>
                <span className="font-mono font-bold text-sky-400">{geometry.heightM} m</span>
              </div>
              <input
                type="range"
                min="2.2"
                max="4.0"
                step="0.1"
                value={geometry.heightM}
                onChange={(e) => updateField('heightM', parseFloat(e.target.value))}
                className="w-full accent-sky-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
              />
            </div>

            {/* Orientation */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">
                  Solar Orientation (Azimuth: {geometry.orientationDeg}°)
                </span>
                <span className="font-mono font-bold text-amber-400">
                  {geometry.orientationDeg === 180 ? 'South (Max Solar)' : `${geometry.orientationDeg}°`}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="355"
                step="5"
                value={geometry.orientationDeg}
                onChange={(e) => updateField('orientationDeg', parseInt(e.target.value))}
                className="w-full accent-amber-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Roof Type Selection */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
              ROOF ARCHITECTURE
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {(['sloped', 'flat', 'dome', 'custom'] as const).map((rType) => (
                <button
                  key={rType}
                  onClick={() => updateField('roofType', rType)}
                  className={`min-h-[48px] py-2.5 px-3 rounded-xl border text-xs font-semibold capitalize transition-all ${
                    geometry.roofType === rType
                      ? 'bg-sky-500/20 border-sky-500 text-sky-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {rType === 'sloped' ? 'Sloped (Snow Shed)' : rType}
                </button>
              ))}
            </div>
          </div>

          {/* Operational Inputs */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
              OCCUPANCY & VENTILATION
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Design Personnel Capacity
                </label>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-sky-400" />
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={geometry.occupancy}
                    onChange={(e) => updateField('occupancy', parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-white"
                  />
                  <span className="text-xs text-slate-400">Troops</span>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1">
                  Ventilation Infiltration (ACH)
                </label>
                <div className="flex items-center gap-2">
                  <Wind className="w-4 h-4 text-teal-400" />
                  <input
                    type="number"
                    min="0.1"
                    max="3.0"
                    step="0.1"
                    value={geometry.ventilationAch}
                    onChange={(e) => updateField('ventilationAch', parseFloat(e.target.value) || 0.5)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-white"
                  />
                  <span className="text-xs text-slate-400">ACH</span>
                </div>
              </div>
            </div>

            {/* Window to Wall ratio */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Window-to-Wall Ratio (WWR)</span>
                <span className="font-mono font-bold text-cyan-400">
                  {Math.round(geometry.windowToWallRatio * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.30"
                step="0.01"
                value={geometry.windowToWallRatio}
                onChange={(e) => updateField('windowToWallRatio', parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* 2D Interactive Blueprint & Geometry Metrics */}
        <div className="lg:col-span-5 space-y-5">
          {/* Blueprint Canvas Card */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-semibold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-4 h-4" /> 2D SHELTER PLAN VIEW
              </span>
              <span className="text-[11px] font-mono text-amber-400 flex items-center gap-1">
                <Sun className="w-3.5 h-3.5" /> South Passive Solar Face
              </span>
            </div>

            {/* SVG Interactive Blueprint */}
            <div className="relative w-full aspect-square max-h-[320px] bg-slate-950 rounded-xl border border-slate-800 p-4 flex items-center justify-center overflow-hidden">
              {/* Compass Needle */}
              <div
                className="absolute top-3 right-3 flex flex-col items-center pointer-events-none transition-transform duration-300"
                style={{ transform: `rotate(${geometry.orientationDeg}deg)` }}
              >
                <div className="w-2.5 h-6 bg-gradient-to-t from-transparent via-red-500 to-red-500 rounded-t-sm shadow-md"></div>
                <div className="w-2.5 h-6 bg-gradient-to-b from-transparent via-slate-600 to-slate-400 rounded-b-sm"></div>
                <span className="text-[9px] font-mono font-bold text-red-400 -mt-7 -rotate-90">N</span>
              </div>

              {/* Shelter Footprint SVG */}
              <svg viewBox="0 0 280 220" className="w-full h-full max-w-[260px] max-h-[200px]">
                {/* Outer Wall Boundary */}
                <rect
                  x="20"
                  y="20"
                  width="240"
                  height="160"
                  rx="6"
                  fill="#0f172a"
                  stroke="#38bdf8"
                  strokeWidth="3.5"
                />

                {/* Thermal Core Hatching */}
                <rect
                  x="30"
                  y="30"
                  width="220"
                  height="140"
                  fill="#1e293b"
                  opacity="0.4"
                />

                {/* Trombe Wall South Glazing Strip */}
                <rect
                  x="45"
                  y="176"
                  width="190"
                  height="8"
                  fill="#f59e0b"
                  rx="2"
                />
                <text x="140" y="196" fill="#f59e0b" fontSize="10" fontFamily="monospace" textAnchor="middle">
                  TROMBE SOLAR WALL ({geometry.trombeWallAreaM2} m²)
                </text>

                {/* Entry Airlock Door */}
                <rect x="25" y="80" width="6" height="40" fill="#10b981" rx="1" />
                <text x="15" y="104" fill="#10b981" fontSize="9" fontFamily="monospace" textAnchor="end">
                  AIRLOCK
                </text>

                {/* Occupancy Bunks Indicator */}
                <circle cx="90" cy="70" r="10" fill="#38bdf8" opacity="0.3" />
                <circle cx="130" cy="70" r="10" fill="#38bdf8" opacity="0.3" />
                <circle cx="170" cy="70" r="10" fill="#38bdf8" opacity="0.3" />
                <circle cx="210" cy="70" r="10" fill="#38bdf8" opacity="0.3" />
                <text x="150" y="74" fill="#94a3b8" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  {geometry.occupancy} OCCUPANTS
                </text>

                {/* Dimensions Label */}
                <text x="140" y="14" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">
                  L: {geometry.lengthM}m
                </text>
                <text x="270" y="105" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">
                  W: {geometry.widthM}m
                </text>
              </svg>
            </div>
          </div>

          {/* Derived Envelope Calculations */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
              CALCULATED ENVELOPE METRICS
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Floor Area</span>
                <span className="text-xl font-bold font-mono text-white">{floorArea} m²</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Shelter Volume</span>
                <span className="text-xl font-bold font-mono text-white">{volume} m³</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Opaque Wall Area</span>
                <span className="text-xl font-bold font-mono text-sky-300">{grossWallArea} m²</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Glazing Area</span>
                <span className="text-xl font-bold font-mono text-amber-400">{windowArea} m²</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Roof Surface</span>
                <span className="text-xl font-bold font-mono text-slate-200">{roofArea} m²</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Total Envelope Area</span>
                <span className="text-xl font-bold font-mono text-teal-300">{totalSurfaceArea} m²</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
