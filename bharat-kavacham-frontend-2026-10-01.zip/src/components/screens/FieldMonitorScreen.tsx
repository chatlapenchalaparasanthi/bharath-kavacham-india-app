/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  ThermometerSnowflake,
  Wind,
  Sun,
  Droplets,
  BatteryMedium,
  CheckCircle,
  ArrowRight,
  RefreshCw,
  Gauge,
} from 'lucide-react';
import { ScreenId, SensorModel } from '../../types';
import { sensorService } from '../../services/sensorService';

interface FieldMonitorScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const FieldMonitorScreen: React.FC<FieldMonitorScreenProps> = ({ onNavigate }) => {
  const [sensors, setSensors] = useState<SensorModel[]>(sensorService.getSensors());
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setSensors(sensorService.getSensors());
      setIsRefreshing(false);
    }, 400);
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            FORWARD POST SENSOR TELEMETRY
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            FIELD MONITOR
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Real-time IoT bus telemetry and automated thermal envelope diagnostics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            className="min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-2 active:scale-95 transition-all"
          >
            <RefreshCw className={`w-4 h-4 text-sky-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Poll Telemetry</span>
          </button>
          <button
            onClick={() => onNavigate('digital_twin')}
            className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all"
          >
            <span>DIGITAL TWIN 3D</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Top 6 KPI Cards specified in prompt */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Indoor Temp</span>
          <div className="text-2xl font-bold font-mono text-emerald-400">17°C</div>
          <span className="text-[10px] text-emerald-500 font-mono">Comfortable</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Outdoor Temp</span>
          <div className="text-2xl font-bold font-mono text-sky-400">-38°C</div>
          <span className="text-[10px] text-sky-500 font-mono">Siachen Ambient</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Humidity</span>
          <div className="text-2xl font-bold font-mono text-teal-300">31%</div>
          <span className="text-[10px] text-slate-400 font-mono">Optimal</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Wind Speed</span>
          <div className="text-2xl font-bold font-mono text-slate-200">22 km/h</div>
          <span className="text-[10px] text-slate-400 font-mono">Gusting 35</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Solar GHI</span>
          <div className="text-2xl font-bold font-mono text-amber-400">4.8 kWh/m²</div>
          <span className="text-[10px] text-amber-500 font-mono">Clear Sky</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Battery Level</span>
          <div className="text-2xl font-bold font-mono text-emerald-400">82%</div>
          <span className="text-[10px] text-emerald-500 font-mono">Aux Backup</span>
        </div>
      </div>

      {/* Sensor Dashboard Table */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
              INTEGRATED SENSOR SUITE
            </h3>
            <p className="text-xs text-slate-400">
              RS-485 Modbus RTU / Low-Power Mesh Sensor Nodes
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            ALL SENSORS ONLINE
          </span>
        </div>

        <div className="space-y-2.5">
          {sensors.map((sensor) => (
            <div
              key={sensor.id}
              className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-700 text-sky-400 flex items-center justify-center font-bold">
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-white font-['Chakra_Petch']">
                      {sensor.name}
                    </h4>
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      ● {sensor.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono">
                    {sensor.location} · Ping: {sensor.lastUpdate}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-6 self-end sm:self-center">
                <div className="text-right">
                  <span className="text-xs text-slate-500 block font-mono">Sensor Health</span>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {sensor.healthScorePct}%
                  </span>
                </div>

                <div className="text-right min-w-[70px]">
                  <span className="text-xs text-slate-500 block font-mono">Reading</span>
                  <span className="text-lg font-bold font-mono text-white">
                    {sensor.value} {sensor.unit}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
