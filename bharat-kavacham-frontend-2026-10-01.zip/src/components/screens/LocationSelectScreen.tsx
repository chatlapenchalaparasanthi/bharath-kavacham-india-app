/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MapPin, Mountain, ArrowRight, Check, Compass, ThermometerSnowflake, Wind, Sun } from 'lucide-react';
import { LocationModel, ScreenId } from '../../types';
import { climateService, LOCATIONS } from '../../services/climateService';

interface LocationSelectScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const LocationSelectScreen: React.FC<LocationSelectScreenProps> = ({ onNavigate }) => {
  const [selectedId, setSelectedId] = useState<string>(climateService.getActiveLocation().id);
  const [customLat, setCustomLat] = useState<number>(34.5000);
  const [customLng, setCustomLng] = useState<number>(77.0000);
  const [customAlt, setCustomAlt] = useState<number>(4500);
  const [customTemp, setCustomTemp] = useState<number>(-30);
  const [isApplying, setIsApplying] = useState(false);

  const handleSelect = (locId: string) => {
    setSelectedId(locId);
  };

  const handleApply = () => {
    setIsApplying(true);
    let target = LOCATIONS.find((l) => l.id === selectedId);
    if (selectedId === 'custom') {
      const customLoc: LocationModel = {
        id: 'custom',
        name: 'Custom High-Altitude Sector',
        region: `Lat ${customLat}° / Lng ${customLng}°`,
        latitude: customLat,
        longitude: customLng,
        altitudeMeters: customAlt,
        designWinterTemp: customTemp,
        avgWindKmh: 20,
        dailySolarGhiKwh: 5.4,
        isCustom: true,
      };
      target = customLoc;
    }

    if (target) {
      climateService.setActiveLocation(target);
    }

    setTimeout(() => {
      setIsApplying(false);
      onNavigate('climate');
    }, 400);
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div>
        <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
          AREA-SPECIFIC ENVIRONMENT CONFIGURATION
        </div>
        <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
          SELECT DESIGN LOCATION
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Himalayan and Karakoram forward posts experience distinct diurnal solar radiation and extreme sub-zero baselines.
        </p>
      </div>

      {/* Grid of Locations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {LOCATIONS.map((loc) => {
          const isSelected = selectedId === loc.id;
          return (
            <div
              key={loc.id}
              onClick={() => handleSelect(loc.id)}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-slate-850 border-sky-500 shadow-lg shadow-sky-500/10 ring-1 ring-sky-500'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2.5 rounded-xl ${
                      isSelected ? 'bg-sky-500 text-white' : 'bg-slate-800 text-sky-400'
                    }`}
                  >
                    <Mountain className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
                      {loc.name}
                    </h3>
                    <p className="text-xs text-slate-400">{loc.region}</p>
                  </div>
                </div>

                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center border ${
                    isSelected
                      ? 'bg-sky-500 border-sky-500 text-white'
                      : 'border-slate-700 bg-slate-800 text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                </div>
              </div>

              {!loc.isCustom ? (
                <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-xs">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Design Winter</span>
                    <span className="font-mono font-bold text-sky-400">
                      {loc.designWinterTemp}°C
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Altitude</span>
                    <span className="font-mono font-bold text-slate-200">
                      {loc.altitudeMeters}m
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Daily Solar</span>
                    <span className="font-mono font-bold text-amber-400">
                      {loc.dailySolarGhiKwh} kWh
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
                  Custom coordinates with user-defined temperature and elevation parameters.
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Custom Location Detailed Inputs */}
      {selectedId === 'custom' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
            CUSTOM COORDINATE & ELEVATION SPECIFICATIONS
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Latitude (°N)
              </label>
              <input
                type="number"
                step="0.0001"
                value={customLat}
                onChange={(e) => setCustomLat(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-slate-100"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Longitude (°E)
              </label>
              <input
                type="number"
                step="0.0001"
                value={customLng}
                onChange={(e) => setCustomLng(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-slate-100"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Altitude (Meters AGL)
              </label>
              <input
                type="number"
                step="50"
                value={customAlt}
                onChange={(e) => setCustomAlt(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-slate-100"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Design Winter Temp (°C)
              </label>
              <input
                type="number"
                step="1"
                value={customTemp}
                onChange={(e) => setCustomTemp(parseInt(e.target.value) || -30)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-mono text-sky-400"
              />
            </div>
          </div>
        </div>
      )}

      {/* Action Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={handleApply}
          disabled={isApplying}
          className="min-h-[48px] px-8 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-sm shadow-xl shadow-sky-600/30 flex items-center gap-2 active:scale-95 transition-all disabled:opacity-50"
        >
          <span>LOAD CLIMATE DATA</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
