/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  GitCompare,
  Sliders,
  CheckCircle2,
  TrendingDown,
  ArrowRight,
  Flame,
  Info,
} from 'lucide-react';
import { OptimizationDesignPoint, ScreenId } from '../../types';
import { optimizationService } from '../../services/optimizationService';

interface DesignSpaceScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const DesignSpaceScreen: React.FC<DesignSpaceScreenProps> = ({ onNavigate }) => {
  const designs = optimizationService.getDesignSpace();
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'cost' | 'energy' | 'comfort' | 'balanced'>('balanced');
  const [selectedDesign, setSelectedDesign] = useState<OptimizationDesignPoint>(
    designs.find((d) => d.id === 'cfg-balanced') || designs[0]
  );
  const [isSimulatingBatch, setIsSimulatingBatch] = useState(false);

  const filtered = designs.filter((d) => {
    if (activeFilter === 'ALL') return true;
    return d.tag === activeFilter;
  });

  const handleRerun324 = () => {
    setIsSimulatingBatch(true);
    setTimeout(() => {
      setIsSimulatingBatch(false);
    }, 600);
  };

  // Scatter plot geometry calculations
  const minCost = 180000;
  const maxCost = 750000;
  const minKwh = 10;
  const maxKwh = 180;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            MULTI-OBJECTIVE PARETO OPTIMIZATION
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            DESIGN SPACE EXPLORER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Evaluate cost vs daily energy demand across 324 simulated thermal envelope permutations.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
            SIMULATION DEMO
          </span>
          <button
            onClick={() => onNavigate('comparison')}
            className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all"
          >
            <span>COMPARE A vs B</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Explorer Meta Card */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div>
          <span className="text-slate-400 block font-mono">Configurations Solved</span>
          <span className="font-bold text-white font-mono text-base">324 configurations</span>
        </div>
        <div>
          <span className="text-slate-400 block font-mono">Execution Time</span>
          <span className="font-bold text-sky-300 font-mono text-base">20 sec (Parallel vectorized)</span>
        </div>
        <div>
          <span className="text-slate-400 block font-mono">Pareto Objective</span>
          <span className="font-bold text-teal-300">Cost (₹) vs Daily Energy (kWh/day)</span>
        </div>
        <button
          onClick={handleRerun324}
          disabled={isSimulatingBatch}
          className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium active:scale-95 transition-all"
        >
          {isSimulatingBatch ? 'Re-scanning 324 states...' : 'Re-Run Batch'}
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-400 mr-2">Filter Preset:</span>
        {(['balanced', 'cost', 'energy', 'comfort', 'ALL'] as const).map((tag) => (
          <button
            key={tag}
            onClick={() => setActiveFilter(tag)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase font-['Chakra_Petch'] transition-all ${
              activeFilter === tag
                ? 'bg-sky-500 text-white shadow-sm'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            {tag === 'ALL' ? 'Show All 324' : tag}
          </button>
        ))}
      </div>

      {/* Interactive Scatter Plot */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
            PARETO DESIGN FRONTIER SCATTER
          </h3>
          <span className="text-xs text-slate-400 font-mono">Click any design node to inspect</span>
        </div>

        {/* Chart Canvas */}
        <div className="relative w-full bg-slate-950/80 rounded-xl p-4 border border-slate-800">
          <div className="flex justify-between text-[11px] font-mono text-slate-500 mb-1">
            <span>High Energy (180 kWh/day)</span>
            <span>Optimal Pareto Curve ↓</span>
            <span>Ultra Low Energy (10 kWh/day)</span>
          </div>

          <svg viewBox="0 0 600 240" className="w-full h-64 overflow-visible">
            {/* Grid */}
            <line x1="40" y1="20" x2="580" y2="20" stroke="#334155" strokeDasharray="3 3" />
            <line x1="40" y1="120" x2="580" y2="120" stroke="#334155" strokeDasharray="3 3" />
            <line x1="40" y1="200" x2="580" y2="200" stroke="#334155" strokeDasharray="3 3" />

            {/* Axes */}
            <line x1="40" y1="20" x2="40" y2="200" stroke="#475569" strokeWidth="1.5" />
            <line x1="40" y1="200" x2="580" y2="200" stroke="#475569" strokeWidth="1.5" />

            {/* Plot design points */}
            {designs.map((pt) => {
              const x = 40 + ((pt.costInr - minCost) / (maxCost - minCost)) * 520;
              // Higher kWh = top of chart (y is inverted in SVG)
              const y = 200 - ((pt.dailyEnergyKwh - minKwh) / (maxKwh - minKwh)) * 170;
              const isSelected = selectedDesign.id === pt.id;
              const isFiltered = activeFilter === 'ALL' || pt.tag === activeFilter;

              return (
                <g key={pt.id} className="cursor-pointer" onClick={() => setSelectedDesign(pt)}>
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 7 : isFiltered ? 4.5 : 2.5}
                    fill={
                      isSelected
                        ? '#38bdf8'
                        : pt.tag === 'baseline'
                        ? '#ef4444'
                        : pt.tag === 'balanced'
                        ? '#f59e0b'
                        : pt.tag === 'energy'
                        ? '#10b981'
                        : '#94a3b8'
                    }
                    opacity={isSelected ? 1.0 : isFiltered ? 0.9 : 0.25}
                    stroke={isSelected ? '#ffffff' : 'none'}
                    strokeWidth={isSelected ? 2 : 0}
                  />
                  {isSelected && (
                    <text
                      x={Math.min(500, Math.max(70, x))}
                      y={Math.max(25, y - 10)}
                      fill="#ffffff"
                      fontSize="10"
                      fontFamily="monospace"
                      textAnchor="middle"
                      className="font-bold pointer-events-none"
                    >
                      {pt.dailyEnergyKwh} kWh/day
                    </text>
                  )}
                </g>
              );
            })}
          </svg>

          <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2 px-6">
            <span>Low Cost (₹1.85 Lakh)</span>
            <span>Cost Scale →</span>
            <span>High Spec (₹6.9 Lakh)</span>
          </div>
        </div>
      </div>

      {/* Selected Configuration Inspector */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <span className="text-[11px] font-mono text-sky-400 uppercase tracking-wider">
              SELECTED CONFIGURATION
            </span>
            <h2 className="font-['Chakra_Petch'] font-bold text-xl text-white">
              {selectedDesign.name}
            </h2>
          </div>
          <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-sky-500/10 text-sky-300 border border-sky-500/30 self-start sm:self-center">
            Tag: {selectedDesign.tag.toUpperCase()}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Estimated Unit Cost</span>
            <span className="text-xl font-bold font-mono text-white">₹{selectedDesign.costInr.toLocaleString()}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Daily Heating Energy</span>
            <span className="text-xl font-bold font-mono text-sky-400">{selectedDesign.dailyEnergyKwh} kWh/day</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Thermal Comfort Score</span>
            <span className="text-xl font-bold font-mono text-emerald-400">{selectedDesign.comfortScorePct}%</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Wall Insulation</span>
            <span className="text-xl font-bold font-mono text-amber-300">{selectedDesign.wallInsulationMm} mm PUF</span>
          </div>
        </div>
      </div>
    </div>
  );
};
