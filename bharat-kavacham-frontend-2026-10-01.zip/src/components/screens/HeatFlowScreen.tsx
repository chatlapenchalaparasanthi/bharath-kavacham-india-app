/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  PieChart,
  ArrowRight,
  TrendingDown,
  Layers,
  Thermometer,
  ShieldAlert,
  Sliders,
} from 'lucide-react';
import { HeatFlowComponent, ScreenId } from '../../types';
import { thermalSimulationService } from '../../services/thermalSimulationService';

interface HeatFlowScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const HeatFlowScreen: React.FC<HeatFlowScreenProps> = ({ onNavigate }) => {
  const components = thermalSimulationService.getHeatFlowDecomposition();
  const [selectedId, setSelectedId] = useState<string>('wall');

  const selected = components.find((c) => c.id === selectedId) || components[0];

  const colors: Record<string, string> = {
    wall: '#38bdf8', // sky
    roof: '#f59e0b', // amber
    floor: '#10b981', // emerald
    door: '#a855f7', // purple
    ventilation: '#f43f5e', // rose
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            ENVELOPE TRANSMISSION FLUX ANALYSIS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            HEAT FLOW DECOMPOSITION
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Breakdown of conductive, convective, and ventilation heat loss paths under design winter conditions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
            DEMO SIMULATION DATA
          </span>
        </div>
      </div>

      {/* Main Grid: Interactive Donut on Left, Detailed Inspector on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Donut Chart & Component Selector */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
              TOTAL THERMAL TRANSMISSION LOSS (100%)
            </h3>
            <span className="text-xs text-slate-400 font-mono">Tap slice to inspect</span>
          </div>

          {/* SVG Donut */}
          <div className="relative flex items-center justify-center p-4">
            <svg viewBox="0 0 200 200" className="w-56 h-56 transform -rotate-90">
              {/* Segments: Wall 40% (144°), Roof 30% (108°), Floor 15% (54°), Door 8% (28.8°), Vent 7% (25.2°) */}
              {/* Circumference for r=70 is 2 * PI * 70 = 439.82 */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#38bdf8"
                strokeWidth="32"
                strokeDasharray="175.9 439.8"
                strokeDashoffset="0"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => setSelectedId('wall')}
              />
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="32"
                strokeDasharray="131.9 439.8"
                strokeDashoffset="-175.9"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => setSelectedId('roof')}
              />
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#10b981"
                strokeWidth="32"
                strokeDasharray="66.0 439.8"
                strokeDashoffset="-307.8"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => setSelectedId('floor')}
              />
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#a855f7"
                strokeWidth="32"
                strokeDasharray="35.2 439.8"
                strokeDashoffset="-373.8"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => setSelectedId('door')}
              />
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#f43f5e"
                strokeWidth="32"
                strokeDasharray="30.8 439.8"
                strokeDashoffset="-409.0"
                className="cursor-pointer transition-all hover:opacity-80"
                onClick={() => setSelectedId('ventilation')}
              />
            </svg>

            {/* Inner Label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-3xl font-bold font-mono text-white">
                {selected.percentage}%
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                {selected.name}
              </span>
            </div>
          </div>

          {/* Component Quick List */}
          <div className="space-y-2 pt-2">
            {components.map((comp) => {
              const isSelected = selectedId === comp.id;
              return (
                <button
                  key={comp.id}
                  onClick={() => setSelectedId(comp.id)}
                  className={`w-full min-h-[48px] p-3 rounded-xl border flex items-center justify-between text-left transition-all ${
                    isSelected
                      ? 'bg-slate-800 border-sky-500 ring-1 ring-sky-500 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-3.5 h-3.5 rounded-full"
                      style={{ backgroundColor: colors[comp.id] }}
                    ></span>
                    <span className="text-xs font-bold text-slate-200">
                      {comp.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-slate-400">
                      {comp.heatLossWatts} W
                    </span>
                    <span className="text-sm font-bold font-mono text-white">
                      {comp.percentage}%
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Detailed Inspector for Selected Component */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-[11px] font-mono text-sky-400 uppercase tracking-wider">
                COMPONENT DETAIL
              </span>
              <h2 className="font-['Chakra_Petch'] font-bold text-xl text-white">
                {selected.name}
              </h2>
            </div>
            <div className="text-right">
              <span className="text-2xl font-bold font-mono text-sky-300">
                {selected.heatLossWatts} W
              </span>
              <span className="text-[11px] text-slate-400 block font-mono">
                Steady Transmission
              </span>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block mb-0.5">Component Surface Area</span>
              <span className="text-lg font-bold font-mono text-white">{selected.areaM2} m²</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block mb-0.5">Calculated U-Value</span>
              <span className="text-lg font-bold font-mono text-sky-400">{selected.uValue} W/m²·K</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block mb-0.5">Design ΔT</span>
              <span className="text-lg font-bold font-mono text-amber-300">{selected.tempDiffC}°C</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400 block mb-0.5">Insulation Depth</span>
              <span className="text-lg font-bold font-mono text-teal-300">{selected.insulationThicknessMm} mm</span>
            </div>
          </div>

          {/* Recommended Engineering Action */}
          <div className="p-4 rounded-xl bg-sky-950/30 border border-sky-800/50 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-sky-300 font-['Chakra_Petch']">
              <TrendingDown className="w-4 h-4" />
              SUGGESTED DESIGN OPTIMIZATION
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {selected.recommendedAction}
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <button
              onClick={() => onNavigate('assemblies')}
              className="flex-1 min-h-[48px] py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Layers className="w-4 h-4" />
              <span>Modify {selected.name} Assembly</span>
            </button>
            <button
              onClick={() => onNavigate('design_space')}
              className="min-h-[48px] py-2.5 px-5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <span>Explore Trade-Offs</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
