/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Award,
  CloudSun,
  Cpu,
  Layers,
  PieChart,
  GitCompare,
  SunMedium,
  HardDriveDownload,
  Mic,
  Box,
  HeartPulse,
  Camera,
  ArrowRight,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface DifferentiatorsScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const DifferentiatorsScreen: React.FC<DifferentiatorsScreenProps> = ({ onNavigate }) => {
  const differentiators = [
    { title: 'AREA-SPECIFIC CLIMATE', desc: 'Real meteorological data integration from NASA POWER tailored to micro-climates across Karakoram & Ladakh.', icon: CloudSun, target: 'climate' as ScreenId },
    { title: 'TRANSIENT THERMAL MODEL', desc: '1D finite-difference implicit Backward Euler solver capturing thermal capacitance rather than steady-state estimates.', icon: Cpu, target: 'simulation' as ScreenId },
    { title: 'LAYERED MATERIAL DESIGN', desc: 'Dynamic assembly builder calculating U-values, R-values, condensation plane, and cost per square meter.', icon: Layers, target: 'assemblies' as ScreenId },
    { title: 'HEAT-FLOW DECOMPOSITION', desc: 'Pinpoint thermal loss across walls, roof, ground, doors, and infiltration for targeted engineering intervention.', icon: PieChart, target: 'heat_flow' as ScreenId },
    { title: 'DESIGN SPACE EXPLORATION', desc: 'Evaluates 324 architectural permutations simultaneously to map the true Pareto cost-performance frontier.', icon: GitCompare, target: 'design_space' as ScreenId },
    { title: 'SOLAR + PCM STORAGE', desc: 'Passive Trombe wall paired with 12 kWh latent heat phase change material for 24-hour diurnal thermal autonomy.', icon: SunMedium, target: 'solar_pcm' as ScreenId },
    { title: 'OFFLINE-FIRST OPERATION', desc: 'Engineered for zero-internet Himalayan outposts with locally cached climate datasets and voice models.', icon: HardDriveDownload, target: 'offline_center' as ScreenId },
    { title: 'MULTILINGUAL INTERFACE', desc: 'Jawan Mitra hands-free voice interface in English, Hindi, and Ladakhi for glove-friendly field usage.', icon: Mic, target: 'voice_assistant' as ScreenId },
    { title: 'DIGITAL TWIN 3D', desc: 'Interactive structural cutaway showing real-time temperature gradients and IoT telemetry node states.', icon: Box, target: 'digital_twin' as ScreenId },
    { title: 'PREDICTIVE MAINTENANCE', desc: 'Component degradation models and early warnings to prevent mid-winter insulation failure or sensor desync.', icon: HeartPulse, target: 'predictive_health' as ScreenId },
    { title: 'AR DESIGN PREVIEW', desc: 'Forward spatial projection onto actual terrain ensuring solar alignment and level foundation footprint.', icon: Camera, target: 'ar_preview' as ScreenId },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            CORE PLATFORM INNOVATIONS
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            WHAT MAKES THE PLATFORM DIFFERENT?
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Key capabilities distinguishing BHARAT KAVACHAM from conventional uninsulated field structures.
          </p>
        </div>

        <button
          onClick={() => onNavigate('settings')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-2 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>SYSTEM SETTINGS</span>
          <ArrowRight className="w-4 h-4 text-sky-400" />
        </button>
      </div>

      {/* Differentiators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {differentiators.map((d, idx) => {
          const Icon = d.icon;
          return (
            <div
              key={idx}
              onClick={() => onNavigate(d.target)}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-sky-500/50 cursor-pointer group transition-all flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-400 group-hover:bg-sky-500 group-hover:text-white transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">0{idx + 1}</span>
                </div>

                <h3 className="font-['Chakra_Petch'] font-bold text-base text-white group-hover:text-sky-300 transition-colors">
                  {d.title}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {d.desc}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-sky-400 font-medium group-hover:underline">
                <span>Explore Module</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
