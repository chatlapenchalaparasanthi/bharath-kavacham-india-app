/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Radar,
  Radio,
  Camera,
  BatteryCharging,
  AlertTriangle,
  ArrowRight,
  Info,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { securityPrototypeService, SecurityStatus } from '../../services/securityService';
import { voiceService } from '../../services/voiceService';

interface SecurityScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const SecurityScreen: React.FC<SecurityScreenProps> = ({ onNavigate }) => {
  const [status, setStatus] = useState<SecurityStatus>(securityPrototypeService.getStatus());

  const handleSimulateAlert = () => {
    const updated = securityPrototypeService.triggerSimulatedEvent(800);
    setStatus(updated);
    voiceService.speak('Simulated security alert. Conceptual aerial object registered at 800 meters.');
  };

  const handleClearAlert = () => {
    const updated = securityPrototypeService.clearSimulatedEvent();
    setStatus(updated);
  };

  const modules = [
    { name: 'Detection Module', state: status.detectionModule, icon: Radar, desc: 'Passive optical/acoustic boundary sensor mock' },
    { name: 'Thermal Perimeter Camera', state: status.thermalCamera, icon: Camera, desc: 'Long-wave infrared (LWIR) 360° situational mock' },
    { name: 'RF Spectrum Monitoring', state: status.rfMonitoring, icon: Radio, desc: 'Passive commercial ISM spectrum presence mock' },
    { name: 'System Auxiliary Power', state: status.systemPower, icon: BatteryCharging, desc: 'Solar-buffered isolated 24V DC bus mock' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-amber-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4" /> INTEGRATED DEFENCE RESEARCH CONCEPT
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SECURITY INTEGRATION — PROTOTYPE
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            High-level research exploration of peripheral sensor monitoring for isolated high-altitude shelters.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40">
            RESEARCH PROTOTYPE
          </span>
        </div>
      </div>

      {/* Strict Research & Compliance Notice */}
      <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/30 flex items-start gap-3 text-xs text-slate-300">
        <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="text-white">RESEARCH COMPLIANCE MANDATE:</strong> This frontend module illustrates a high-level conceptual boundary surveillance integration. It contains <strong>NO operational instructions for electronic warfare, RF jamming, weapon targeting, or kinetic countermeasures</strong>. Designed strictly as an academic and technological architecture proof-of-concept.
        </div>
      </div>

      {/* 4 High-Level System Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {modules.map((m, idx) => {
          const Icon = m.icon;
          return (
            <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-lg bg-slate-800 text-sky-400">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-mono font-bold text-amber-400 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                  ● {m.state}
                </span>
              </div>
              <h3 className="font-['Chakra_Petch'] font-bold text-sm text-white">
                {m.name}
              </h3>
              <p className="text-[11px] text-slate-400">{m.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Conceptual Radar Map */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
              CONCEPTUAL BOUNDARY SURVEILLANCE RADAR MAP
            </h3>
            <p className="text-xs text-slate-400">
              Shelter Core · 800m Alert Ring · 1200m Detection Perimeter
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSimulateAlert}
              className="px-3.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold active:scale-95 transition-all"
            >
              Simulate 800m Detection
            </button>
            <button
              onClick={handleClearAlert}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold active:scale-95 transition-all"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Circular Radar Graphic */}
        <div className="relative w-full aspect-video max-h-[360px] bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
          <svg viewBox="0 0 500 300" className="w-full h-full max-w-[480px]">
            {/* Concentric rings */}
            <circle cx="250" cy="150" r="130" fill="none" stroke="#1e293b" strokeWidth="1.5" strokeDasharray="4 4" />
            <circle cx="250" cy="150" r="90" fill="rgba(245, 158, 11, 0.05)" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="3 3" />
            <circle cx="250" cy="150" r="50" fill="rgba(56, 189, 248, 0.08)" stroke="#38bdf8" strokeWidth="1.5" />

            {/* Crosshairs */}
            <line x1="250" y1="20" x2="250" y2="280" stroke="#334155" strokeWidth="1" />
            <line x1="120" y1="150" x2="380" y2="150" stroke="#334155" strokeWidth="1" />

            {/* Central Shelter Node */}
            <circle cx="250" cy="150" r="8" fill="#38bdf8" />
            <text x="250" y="172" fill="#38bdf8" fontSize="10" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
              BHARAT KAVACHAM SHELTER
            </text>

            {/* Labels */}
            <text x="250" y="32" fill="#64748b" fontSize="9" fontFamily="monospace" textAnchor="middle">
              1200m OUTER DETECTION SECTOR
            </text>
            <text x="250" y="70" fill="#f59e0b" fontSize="9" fontFamily="monospace" textAnchor="middle">
              800m ALERT RING
            </text>

            {/* Simulated Object Marker if distance > 0 */}
            {status.perimeterDistanceMeters > 0 && (
              <g>
                <circle cx="310" cy="100" r="7" fill="#ef4444" className="animate-ping" />
                <circle cx="310" cy="100" r="6" fill="#ef4444" />
                <text x="325" y="104" fill="#ef4444" fontSize="10" fontFamily="monospace" fontWeight="bold">
                  SIMULATED OBJECT (800m)
                </text>
              </g>
            )}
          </svg>
        </div>

        {/* Status Feed */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            <span>{status.lastEvent}</span>
          </span>
          <span className="text-[11px] text-slate-500">Telemetry Cycle: 1000ms</span>
        </div>
      </div>
    </div>
  );
};
