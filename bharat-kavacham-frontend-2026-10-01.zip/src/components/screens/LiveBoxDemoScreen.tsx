/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  FlaskConical,
  Play,
  RotateCcw,
  Sun,
  Flame,
  ArrowRight,
  Info,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface LiveBoxDemoScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const LiveBoxDemoScreen: React.FC<LiveBoxDemoScreenProps> = ({ onNavigate }) => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [chamberTemp, setChamberTemp] = useState<number>(-16);
  const [shelterTemp, setShelterTemp] = useState<number>(7);
  const [solarInput, setSolarInput] = useState<number>(0);
  const [pcmStoragePct, setPcmStoragePct] = useState<number>(10);
  const [stepName, setStepName] = useState<string>('Sub-Zero Baseline Chamber State');

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setSolarInput((prev) => Math.min(650, prev + 65));
      setShelterTemp((prev) => {
        if (prev >= 17.0) {
          setIsRunning(false);
          setStepName('Comfort Envelope Achieved (17°C Steady State)');
          return 17.0;
        }
        return Math.round((prev + 0.8) * 10) / 10;
      });
      setPcmStoragePct((prev) => Math.min(75, prev + 6));
    }, 400);

    return () => clearInterval(interval);
  }, [isRunning]);

  const handleStart = () => {
    setIsRunning(true);
    setStepName('Solar Radiation Engaging Trombe Wall & PCM Thermal Bank');
  };

  const handleReset = () => {
    setIsRunning(false);
    setChamberTemp(-16);
    setShelterTemp(7);
    setSolarInput(0);
    setPcmStoragePct(10);
    setStepName('Sub-Zero Baseline Chamber State');
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            LABORATORY TEST-BOX SIMULATION
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            LIVE THERMAL DEMO
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Demonstration of sub-zero cryogenic environmental chamber (-16°C) vs indoor thermal retention (17°C).
          </p>
        </div>

        <button
          onClick={() => onNavigate('presentation')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <Flame className="w-4 h-4" />
          <span>PRESENTATION MODE</span>
        </button>
      </div>

      {/* Notice Banner */}
      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
        <Info className="w-4 h-4 text-amber-400 shrink-0" />
        <span>
          <strong>Notice:</strong> This is a visual/demo simulation unless actual hardware environmental chamber thermocouple sensors are connected.
        </span>
      </div>

      {/* Main Chamber Display */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-wider block">
              EXPERIMENT PHASE
            </span>
            <h3 className="font-['Chakra_Petch'] font-bold text-lg text-white">
              {stepName}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleStart}
              disabled={isRunning || shelterTemp >= 17}
              className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5" />
              <span>START TROMBE SIMULATION</span>
            </button>
            <button
              onClick={handleReset}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold active:scale-95 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dual Chamber Comparison Box Graphic */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Outdoor Chamber Box */}
          <div className="p-5 rounded-2xl bg-sky-950/40 border border-sky-800/60 text-center space-y-2">
            <span className="text-xs font-mono font-bold text-sky-400 uppercase tracking-wider block">
              EXTERIOR CRYOGENIC CHAMBER
            </span>
            <div className="text-5xl font-bold font-mono text-sky-300 py-3">
              {chamberTemp}°C
            </div>
            <p className="text-xs text-slate-400">
              Simulated Himalayan sub-zero ambient with convective wind chiller active.
            </p>
          </div>

          {/* Indoor Shelter Model Box */}
          <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-800/60 text-center space-y-2">
            <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider block">
              SHELTER INTERIOR LIVING ZONE
            </span>
            <div className="text-5xl font-bold font-mono text-emerald-400 py-3">
              {shelterTemp}°C
            </div>
            <p className="text-xs text-slate-400">
              Passive Trombe wall solar gain and PCM buffering maintains 17°C steady target.
            </p>
          </div>
        </div>

        {/* Dynamic Telemetry Readouts */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs pt-2">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">Simulated Solar Flux</span>
            <span className="text-lg font-bold font-mono text-amber-300">{solarInput} W/m²</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block mb-0.5">PCM Battery Charge</span>
            <span className="text-lg font-bold font-mono text-emerald-400">{pcmStoragePct}%</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-slate-400 block mb-0.5">Thermal Envelope Lift</span>
            <span className="text-lg font-bold font-mono text-sky-300">ΔT = {Math.round(shelterTemp - chamberTemp)}°C</span>
          </div>
        </div>
      </div>
    </div>
  );
};
