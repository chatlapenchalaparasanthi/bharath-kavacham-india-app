/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CloudSun, Cpu, Activity, ArrowRight, Check } from 'lucide-react';
import { ScreenId } from '../../types';

interface OnboardingScreenProps {
  onComplete: () => void;
  onNavigate: (screen: ScreenId) => void;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState<number>(0);

  const steps = [
    {
      step: 1,
      tag: 'CLIMATE FIRST',
      title: 'DESIGN FOR THE CLIMATE',
      description:
        'Analyze area-specific environmental conditions before designing a shelter. Access diurnal solar radiation, sub-zero wind profiles, and altitude metrics from Siachen to Ladakh.',
      icon: CloudSun,
      accent: 'from-sky-500/20 to-blue-600/20 border-sky-500/40 text-sky-400',
    },
    {
      step: 2,
      tag: 'TRANSIENT SOLVER',
      title: 'SIMULATE BEFORE YOU BUILD',
      description:
        'Evaluate thermal performance, materials, heat flow and energy demand. Use our 1D finite-difference transient solver to optimize composite walls and Trombe PCM storage before field deployment.',
      icon: Cpu,
      accent: 'from-amber-500/20 to-orange-600/20 border-amber-500/40 text-amber-400',
    },
    {
      step: 3,
      tag: 'SMART OPERATIONS',
      title: 'MONITOR AND OPTIMIZE',
      description:
        'Track shelter performance using offline data, sensors and predictive models. Digital twin cutaways and Jawan Mitra voice diagnostics keep high-altitude posts safe and self-reliant.',
      icon: Activity,
      accent: 'from-emerald-500/20 to-teal-600/20 border-emerald-500/40 text-emerald-400',
    },
  ];

  const activeStep = steps[currentStep];
  const Icon = activeStep.icon;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-6 sm:p-8 bg-slate-950 text-slate-100 select-none">
      {/* Top Bar with Step Indicators & Skip */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {steps.map((s, idx) => (
            <div
              key={s.step}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentStep
                  ? 'w-8 bg-sky-400'
                  : idx < currentStep
                  ? 'w-3 bg-sky-700'
                  : 'w-3 bg-slate-800'
              }`}
            />
          ))}
        </div>
        <button
          onClick={onComplete}
          className="text-xs font-mono uppercase tracking-wider text-slate-400 hover:text-sky-300 px-3 py-1.5 rounded-lg hover:bg-slate-900 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Main Illustration & Copy */}
      <div className="my-auto max-w-lg mx-auto w-full text-center py-6">
        <div className="relative mx-auto w-28 h-28 sm:w-36 sm:h-36 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-1 flex items-center justify-center shadow-2xl mb-8">
          <div className={`w-full h-full rounded-2xl bg-gradient-to-br ${activeStep.accent} flex items-center justify-center border shadow-inner`}>
            <Icon className="w-14 h-14 sm:w-18 sm:h-18 stroke-[1.5]" />
          </div>
        </div>

        <div className="inline-block px-3 py-1 rounded bg-slate-800/80 border border-slate-700 text-[11px] font-mono tracking-widest text-sky-400 uppercase mb-3">
          STEP 0{activeStep.step} · {activeStep.tag}
        </div>

        <h2 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white tracking-wide mb-4">
          {activeStep.title}
        </h2>

        <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-md mx-auto">
          {activeStep.description}
        </p>
      </div>

      {/* Bottom Actions (Min touch target 48dp) */}
      <div className="w-full max-w-sm mx-auto flex items-center gap-3">
        {currentStep > 0 && (
          <button
            onClick={() => setCurrentStep(currentStep - 1)}
            className="min-h-[48px] px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-semibold active:scale-95 transition-all"
          >
            Back
          </button>
        )}
        <button
          onClick={handleNext}
          className="flex-1 min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white text-sm font-semibold shadow-lg shadow-sky-600/25 flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          {currentStep === steps.length - 1 ? (
            <>
              <span>GET STARTED</span>
              <Check className="w-4 h-4" />
            </>
          ) : (
            <>
              <span>NEXT</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
