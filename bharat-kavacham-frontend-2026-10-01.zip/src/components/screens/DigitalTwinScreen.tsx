/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Box,
  Layers,
  Thermometer,
  ShieldCheck,
  Activity,
  ArrowRight,
  Info,
  Maximize2,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface DigitalTwinScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const DigitalTwinScreen: React.FC<DigitalTwinScreenProps> = ({ onNavigate }) => {
  const [activeZone, setActiveZone] = useState<'wall' | 'roof' | 'floor' | 'door' | 'window'>('wall');

  const zoneData = {
    wall: {
      title: 'South-Facing Composite Wall & Trombe Core',
      temperature: '18.4°C (Interior) / -36.2°C (Exterior)',
      heatFlux: '12.8 W/m²',
      material: '120mm PUF + Granite Outer Armor + AAC Interior',
      condition: 'Optimal (94% Integrity)',
      sensorStatus: 'Thermocouple Bus T-01 to T-04 Online',
    },
    roof: {
      title: 'Snow-Shedding Insulated Roof Truss',
      temperature: '16.8°C (Ceiling) / -41.0°C (Exterior Surface)',
      heatFlux: '14.2 W/m²',
      material: '160mm Dense PUF + FRP Composite Shell',
      condition: 'Good (88% Integrity — Snow Load: 180 kg/m²)',
      sensorStatus: 'Pyranometer & Deflection Sensor Online',
    },
    floor: {
      title: 'Permafrost Thermal Break Floor Slab',
      temperature: '15.2°C (Floor Finish) / -12.4°C (Sub-Slab Permafrost)',
      heatFlux: '9.4 W/m²',
      material: '120mm EPS + Screed Slab + Insulated Deodar Wood',
      condition: 'Stable (96% Integrity — Zero Frost Heave)',
      sensorStatus: 'Ground Heat Probe G-01 Online',
    },
    door: {
      title: 'Magnetic Double-Sealed Airlock Vestibule',
      temperature: '9.5°C (Vestibule Buffer)',
      heatFlux: '24.1 W/m²',
      material: 'Vacuum Insulated Panel Door with Heated Gasket',
      condition: 'Normal (92% Magnetic Seal Contact)',
      sensorStatus: 'Door Contact Switch Sealed',
    },
    window: {
      title: 'Argon Low-E Double Glazing Aperture',
      temperature: '14.5°C (Inner Pane)',
      heatFlux: '28.5 W/m²',
      material: 'Double 6mm Toughened Glass + Argon Cavity',
      condition: 'Clear (Zero Condensation / Frosting)',
      sensorStatus: 'Solar Pyranometer Active',
    },
  };

  const curr = zoneData[activeZone];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            CYBER-PHYSICAL SYSTEM TWIN
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            SHELTER DIGITAL TWIN
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Interactive structural cutaway with live spatial heat flux mapping and thermal gradients.
          </p>
        </div>

        <button
          onClick={() => onNavigate('predictive_health')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>PREDICTIVE HEALTH</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Interactive 3D / Isometric Schematic Cutaway Canvas */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-semibold text-sky-400 tracking-wider">
            ISOMETRIC CUTAWAY MODEL · TAP COMPONENT TO PROBE
          </span>
          <div className="flex gap-1.5">
            {(['roof', 'wall', 'floor', 'door', 'window'] as const).map((z) => (
              <button
                key={z}
                onClick={() => setActiveZone(z)}
                className={`px-3 py-1 rounded-lg text-xs font-mono uppercase font-bold transition-all ${
                  activeZone === z
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                }`}
              >
                {z}
              </button>
            ))}
          </div>
        </div>

        {/* Isometric SVG Vector Graphic */}
        <div className="relative w-full aspect-video max-h-[380px] bg-slate-950 rounded-xl border border-slate-800 p-4 flex items-center justify-center overflow-hidden">
          <svg viewBox="0 0 600 320" className="w-full h-full max-w-[560px]">
            {/* Ground Grid */}
            <line x1="100" y1="260" x2="500" y2="260" stroke="#1e293b" strokeWidth="2" />
            <line x1="50" y1="290" x2="550" y2="290" stroke="#0f172a" strokeWidth="1.5" />

            {/* Sub-floor Permafrost Slab */}
            <polygon
              points="150,260 450,260 490,290 190,290"
              fill={activeZone === 'floor' ? '#0369a1' : '#1e293b'}
              stroke={activeZone === 'floor' ? '#38bdf8' : '#334155'}
              strokeWidth="2"
              className="cursor-pointer transition-all hover:opacity-80"
              onClick={() => setActiveZone('floor')}
            />
            <text x="320" y="280" fill="#94a3b8" fontSize="11" fontFamily="monospace" textAnchor="middle">
              FLOOR SLAB (-12.4°C GROUND)
            </text>

            {/* Back Wall */}
            <polygon
              points="150,140 450,140 450,260 150,260"
              fill="#0f172a"
              stroke="#1e293b"
              strokeWidth="1.5"
            />

            {/* Left Wall / Airlock */}
            <polygon
              points="150,140 190,160 190,290 150,260"
              fill={activeZone === 'door' ? '#7e22ce' : '#1e293b'}
              stroke={activeZone === 'door' ? '#c084fc' : '#334155'}
              strokeWidth="2"
              className="cursor-pointer transition-all hover:opacity-80"
              onClick={() => setActiveZone('door')}
            />
            <text x="160" y="210" fill="#c084fc" fontSize="10" fontFamily="monospace" textAnchor="middle" transform="rotate(-35, 160, 210)">
              AIRLOCK DOOR
            </text>

            {/* Front Wall with South Glazing & Trombe */}
            <polygon
              points="190,160 490,160 490,290 190,290"
              fill={activeZone === 'wall' ? 'rgba(56, 189, 248, 0.25)' : 'rgba(30, 41, 59, 0.4)'}
              stroke={activeZone === 'wall' ? '#38bdf8' : '#475569'}
              strokeWidth="2.5"
              className="cursor-pointer transition-all hover:opacity-80"
              onClick={() => setActiveZone('wall')}
            />

            {/* Window Aperture */}
            <rect
              x="240"
              y="190"
              width="90"
              height="60"
              fill={activeZone === 'window' ? '#f59e0b' : '#0284c7'}
              opacity="0.6"
              stroke={activeZone === 'window' ? '#fbbf24' : '#38bdf8'}
              strokeWidth="2"
              className="cursor-pointer transition-all"
              onClick={() => setActiveZone('window')}
            />
            <text x="285" y="225" fill="#ffffff" fontSize="10" fontFamily="monospace" textAnchor="middle">
              WINDOW
            </text>

            {/* Trombe Wall PCM Core */}
            <rect
              x="360"
              y="180"
              width="100"
              height="80"
              fill="#d97706"
              opacity="0.75"
              stroke="#fbbf24"
              strokeWidth="2"
              className="cursor-pointer transition-all"
              onClick={() => setActiveZone('wall')}
            />
            <text x="410" y="225" fill="#ffffff" fontSize="10" fontFamily="monospace" textAnchor="middle">
              PCM TROMBE
            </text>

            {/* Sloped Roof */}
            <polygon
              points="150,140 300,70 450,140"
              fill={activeZone === 'roof' ? '#d97706' : '#1e293b'}
              stroke={activeZone === 'roof' ? '#f59e0b' : '#475569'}
              strokeWidth="2.5"
              className="cursor-pointer transition-all hover:opacity-80"
              onClick={() => setActiveZone('roof')}
            />
            <polygon
              points="300,70 340,90 490,160 450,140"
              fill={activeZone === 'roof' ? '#b45309' : '#0f172a'}
              stroke={activeZone === 'roof' ? '#f59e0b' : '#334155'}
              strokeWidth="2"
              className="cursor-pointer transition-all"
              onClick={() => setActiveZone('roof')}
            />
            <text x="320" y="115" fill="#f59e0b" fontSize="11" fontFamily="monospace" textAnchor="middle">
              ROOF SHELL
            </text>

            {/* Interior Center Temperature Hotspot */}
            <circle cx="340" cy="230" r="14" fill="#10b981" opacity="0.85" />
            <text x="340" y="234" fill="#ffffff" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
              17°C
            </text>
          </svg>
        </div>

        {/* Inspected Hotspot Data Display */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <span className="text-[10px] font-mono text-sky-400 uppercase tracking-wider">
                SELECTED TWIN SUBSYSTEM
              </span>
              <h3 className="font-['Chakra_Petch'] font-bold text-lg text-white">
                {curr.title}
              </h3>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/20">
              {curr.condition}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">Boundary Temperature</span>
              <span className="font-mono font-bold text-sky-300">{curr.temperature}</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">Surface Heat Flux</span>
              <span className="font-mono font-bold text-amber-300">{curr.heatFlux}</span>
            </div>

            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block mb-0.5">Sensor Bus State</span>
              <span className="font-mono font-bold text-emerald-400">{curr.sensorStatus}</span>
            </div>
          </div>

          <div className="text-xs text-slate-400 font-mono pt-1">
            Material Stack: <span className="text-slate-200">{curr.material}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
