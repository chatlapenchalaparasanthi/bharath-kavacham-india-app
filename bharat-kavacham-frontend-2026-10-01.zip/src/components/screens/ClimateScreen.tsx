/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CloudSun,
  ThermometerSnowflake,
  Wind,
  Sun,
  Droplets,
  HardDriveDownload,
  CheckCircle,
  Clock,
  RefreshCw,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { climateService } from '../../services/climateService';

interface ClimateScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ClimateScreen: React.FC<ClimateScreenProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'24h' | '7d' | '30d'>('24h');
  const [activeMetric, setActiveMetric] = useState<'temp' | 'ghi' | 'wind'>('temp');
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [isDownloaded, setIsDownloaded] = useState<boolean>(true);
  const [syncStatus, setSyncStatus] = useState<string>('14:20 IST');

  const loc = climateService.getActiveLocation();
  const climateData = climateService.getClimateData(loc.id);

  const handleDownload = (duration: string) => {
    setDownloadProgress(10);
    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev === null) return 10;
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setDownloadProgress(null);
            setIsDownloaded(true);
            setSyncStatus(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST');
          }, 400);
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  // Compute SVG chart points
  const points = climateData.hourly;
  const maxVal = activeMetric === 'temp' ? 5 : activeMetric === 'ghi' ? 800 : 40;
  const minVal = activeMetric === 'temp' ? -45 : 0;
  const range = maxVal - minVal;

  const svgPoints = points
    .map((pt, idx) => {
      const val = activeMetric === 'temp' ? pt.temperature : activeMetric === 'ghi' ? pt.solarGhi : pt.windSpeed;
      const x = (idx / 23) * 600;
      const y = 180 - ((val - minVal) / range) * 160;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            ATMOSPHERIC & SOLAR REGIME
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            CLIMATE INTELLIGENCE
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            {loc.name} · Altitude: {loc.altitudeMeters}m AGL · Lat: {loc.latitude}°N, Long: {loc.longitude}°E
          </p>
        </div>

        {/* Source Badge */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">Source Adapter:</span>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-md bg-slate-800 text-sky-300 border border-slate-700">
            {climateData.source}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Average Temp</div>
          <div className="text-2xl font-bold font-mono text-white">
            {climateData.avgTemp}°C
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Minimum Temp</div>
          <div className="text-2xl font-bold font-mono text-sky-400">
            {climateData.minTemp}°C
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Maximum Temp</div>
          <div className="text-2xl font-bold font-mono text-amber-300">
            {climateData.maxTemp}°C
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Average GHI Solar</div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {climateData.avgGhi} <span className="text-xs text-slate-400 font-normal">kWh/m²</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 col-span-2 sm:col-span-1">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Average Wind</div>
          <div className="text-2xl font-bold font-mono text-teal-300">
            {climateData.avgWind} <span className="text-xs text-slate-400 font-normal">km/h</span>
          </div>
        </div>
      </div>

      {/* Interactive Hourly Chart */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveMetric('temp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeMetric === 'temp'
                  ? 'bg-sky-500 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Temperature (°C)
            </button>
            <button
              onClick={() => setActiveMetric('ghi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeMetric === 'ghi'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Solar GHI (W/m²)
            </button>
            <button
              onClick={() => setActiveMetric('wind')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeMetric === 'wind'
                  ? 'bg-teal-500 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Wind Speed (km/h)
            </button>
          </div>

          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
            {(['24h', '7d', '30d'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1 rounded-md text-xs font-mono uppercase transition-colors ${
                  activeTab === tab
                    ? 'bg-slate-800 text-sky-400 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab === '24h' ? '24 Hours' : tab === '7d' ? '7 Days' : '30 Days'}
              </button>
            ))}
          </div>
        </div>

        {/* SVG Curve */}
        <div className="w-full bg-slate-950/80 rounded-xl p-4 border border-slate-800/80">
          <div className="flex justify-between text-[11px] font-mono text-slate-500 mb-1">
            <span>Peak: {maxVal}</span>
            <span>Diurnal Baseline</span>
            <span>Floor: {minVal}</span>
          </div>

          <svg viewBox="0 0 600 200" className="w-full h-48 overflow-visible">
            {/* Grid Lines */}
            <line x1="0" y1="20" x2="600" y2="20" stroke="#334155" strokeDasharray="3 3" />
            <line x1="0" y1="100" x2="600" y2="100" stroke="#334155" strokeDasharray="3 3" />
            <line x1="0" y1="180" x2="600" y2="180" stroke="#334155" strokeDasharray="3 3" />

            {/* Shaded Area */}
            <polygon
              points={`0,180 ${svgPoints} 600,180`}
              fill={activeMetric === 'temp' ? 'rgba(56, 189, 248, 0.12)' : activeMetric === 'ghi' ? 'rgba(245, 158, 11, 0.12)' : 'rgba(20, 184, 166, 0.12)'}
            />

            {/* Polyline */}
            <polyline
              fill="none"
              stroke={activeMetric === 'temp' ? '#38bdf8' : activeMetric === 'ghi' ? '#f59e0b' : '#14b8a6'}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={svgPoints}
            />
          </svg>

          <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-2">
            <span>00:00 (Midnight)</span>
            <span>06:00 (Dawn)</span>
            <span>12:00 (Solar Peak)</span>
            <span>18:00 (Dusk)</span>
            <span>23:00</span>
          </div>
        </div>
      </div>

      {/* Download for Offline Section */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-['Chakra_Petch'] font-bold text-base text-white flex items-center gap-2">
              <HardDriveDownload className="w-5 h-5 text-sky-400" />
              DOWNLOAD FOR OFFLINE
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Cache full high-resolution meteorological arrays for zero-connectivity field operation.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
            <CheckCircle className="w-4 h-4" />
            <span>Climate dataset ✓ Downloaded · Last sync: {syncStatus}</span>
          </div>
        </div>

        {downloadProgress !== null && (
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono text-sky-400">
              <span>Synchronizing NASA POWER weather stream...</span>
              <span>{downloadProgress}%</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-sky-500 transition-all duration-200"
                style={{ width: `${downloadProgress}%` }}
              ></div>
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => handleDownload('24h')}
            disabled={downloadProgress !== null}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 active:scale-95 transition-all"
          >
            DOWNLOAD 24 HOURS
          </button>
          <button
            onClick={() => handleDownload('7d')}
            disabled={downloadProgress !== null}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 active:scale-95 transition-all"
          >
            DOWNLOAD 7 DAYS
          </button>
          <button
            onClick={() => handleDownload('30d')}
            disabled={downloadProgress !== null}
            className="px-4 py-2.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-xs font-semibold text-sky-300 border border-sky-500/40 active:scale-95 transition-all"
          >
            DOWNLOAD 30 DAYS (FULL SEASON)
          </button>
        </div>
      </div>
    </div>
  );
};
