/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Building2,
  AlertTriangle,
  Flame,
  BatteryMedium,
  Radio,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface CommandCenterScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const CommandCenterScreen: React.FC<CommandCenterScreenProps> = ({ onNavigate }) => {
  const shelterFleet = [
    { id: 'PK-2026-26051', sector: 'Siachen Ridge', temp: '17.2°C', health: '87%', status: 'Normal' },
    { id: 'PK-2026-26052', sector: 'Daulat Beg Oldi', temp: '14.8°C', health: '82%', status: 'Warning' },
    { id: 'PK-2026-26053', sector: 'Dras High Sector', temp: '16.5°C', health: '91%', status: 'Normal' },
    { id: 'PK-2026-26054', sector: 'Kargil Forward Base', temp: '18.1°C', health: '95%', status: 'Normal' },
    { id: 'PK-2026-26055', sector: 'Nyoma Plateau Outpost', temp: '15.9°C', health: '89%', status: 'Normal' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            THEATER FLEET SURVEILLANCE
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            COMMAND CENTER
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Regional operational dashboard monitoring high-altitude thermal shelter deployments across Northern Command.
          </p>
        </div>

        <button
          onClick={() => onNavigate('qr_identity')}
          className="min-h-[48px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-sky-600/25 active:scale-95 transition-all self-start sm:self-center"
        >
          <span>QR SHELTER IDENTITY</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 5 KPI Cards required by prompt */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Active Shelters</span>
          <div className="text-3xl font-bold font-mono text-white">14</div>
          <span className="text-[10px] text-emerald-400 font-mono">100% Deployed</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Thermal Alerts</span>
          <div className="text-3xl font-bold font-mono text-amber-400">1</div>
          <span className="text-[10px] text-amber-500 font-mono">DBO Door Latch</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Maintenance Queue</span>
          <div className="text-3xl font-bold font-mono text-sky-400">2</div>
          <span className="text-[10px] text-slate-400 font-mono">Calibration Cues</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Energy Saving</span>
          <div className="text-3xl font-bold font-mono text-emerald-400">88%</div>
          <span className="text-[10px] text-slate-400 font-mono">vs Fuel Baseline</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 col-span-2 sm:col-span-1">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Mesh Nodes</span>
          <div className="text-3xl font-bold font-mono text-teal-300">14 / 14</div>
          <span className="text-[10px] text-teal-400 font-mono">LoRa Connected</span>
        </div>
      </div>

      {/* Fleet Shelter Table */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="font-['Chakra_Petch'] font-bold text-base text-white">
          DEPLOYED SHELTERS ROSTER
        </h3>

        <div className="space-y-2">
          {shelterFleet.map((s) => (
            <div
              key={s.id}
              onClick={() => onNavigate('qr_identity')}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className="font-mono font-bold text-sky-300 text-sm">{s.id}</span>
                <span className="text-slate-400">{s.sector}</span>
              </div>

              <div className="flex items-center gap-4 text-xs font-mono">
                <span>Temp: <strong className="text-white">{s.temp}</strong></span>
                <span>Health: <strong className="text-emerald-400">{s.health}</strong></span>
                <span
                  className={`px-2 py-0.5 rounded font-bold ${
                    s.status === 'Warning' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {s.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
