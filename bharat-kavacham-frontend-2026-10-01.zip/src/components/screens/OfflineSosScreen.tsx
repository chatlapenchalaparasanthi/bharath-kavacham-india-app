/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Radio,
  WifiOff,
  Signal,
  AlertOctagon,
  Send,
  CheckCircle,
  ArrowRight,
  Info,
} from 'lucide-react';
import { ScreenId } from '../../types';

interface OfflineSosScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const OfflineSosScreen: React.FC<OfflineSosScreenProps> = ({ onNavigate }) => {
  const [sosSent, setSosSent] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleSendSos = () => {
    setSosSent(true);
    setStatusMsg('SOS broadcasted over local 868MHz LoRa mesh packet (Simulated ACK received from Node 02 Ridge).');
  };

  const handleSendStatus = () => {
    setStatusMsg('Telemetry status packet [Tin=17.2°C, Bat=82%, P=522hPa] dispatched to neighboring relay nodes.');
  };

  const nearbyNodes = [
    { id: 'node-01', name: 'Relay 01 - Siachen Forward Ridge', distance: '1.4 km', rssi: '-78 dBm', status: 'Online Mesh' },
    { id: 'node-02', name: 'Relay 02 - Base Camp Command Post', distance: '3.8 km', rssi: '-92 dBm', status: 'Online Mesh' },
    { id: 'node-03', name: 'Relay 03 - Transit Helipad Bunker', distance: '2.1 km', rssi: '-84 dBm', status: 'Online Mesh' },
  ];

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            SEVERED COMMUNICATIONS REDUNDANCY
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            OFFLINE SOS / LORA PROTOTYPE
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Zero-internet peer-to-peer Sub-GHz telemetry packet mesh for high-altitude emergency coordination.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40">
            LORA PROTOTYPE
          </span>
        </div>
      </div>

      {/* Connectivity Status Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <WifiOff className="w-6 h-6 text-red-400" />
            <div>
              <span className="text-xs font-mono text-slate-400 block">Cellular & Internet WAN</span>
              <span className="font-bold text-red-400 text-sm">UNAVAILABLE (SEVERED)</span>
            </div>
          </div>
          <span className="text-xs font-mono text-red-400 font-bold">OFFLINE</span>
        </div>

        <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Radio className="w-6 h-6 text-emerald-400" />
            <div>
              <span className="text-xs font-mono text-slate-400 block">Sub-GHz 868MHz Local Mesh</span>
              <span className="font-bold text-emerald-400 text-sm">AVAILABLE (3 HOP MESH)</span>
            </div>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-bold">ONLINE</span>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
        <Info className="w-4 h-4 text-sky-400 shrink-0" />
        <span>
          <strong>Prototyping Note:</strong> Do not claim real connectivity unless verified LoRa hardware is connected. This UI demonstrates packet format and mesh topology handling.
        </span>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={handleSendSos}
          className="min-h-[52px] py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          <AlertOctagon className="w-4 h-4" />
          <span>SEND EMERGENCY SOS</span>
        </button>

        <button
          onClick={handleSendStatus}
          className="min-h-[52px] py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          <Send className="w-4 h-4 text-sky-400" />
          <span>SEND TELEMETRY STATUS</span>
        </button>

        <button
          onClick={() => setStatusMsg('Pinging 3 registered nodes within line-of-sight... All ACKs within 180ms.')}
          className="min-h-[52px] py-3 px-4 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-semibold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          <Signal className="w-4 h-4" />
          <span>CHECK NEARBY NODES</span>
        </button>
      </div>

      {/* Status Output Console */}
      {statusMsg && (
        <div className="p-4 rounded-xl bg-slate-950 border border-sky-500/40 text-xs font-mono text-sky-300 animate-fadeIn flex items-start gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Simulated Nearby Nodes List */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="font-['Chakra_Petch'] font-bold text-sm text-sky-400 tracking-wider">
          REGISTERED LOCAL MESH REPEATERS
        </h3>

        <div className="space-y-2.5">
          {nearbyNodes.map((n) => (
            <div
              key={n.id}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-white font-['Chakra_Petch'] block">{n.name}</span>
                <span className="text-[11px] text-slate-400 font-mono">Distance: {n.distance} · RSSI: {n.rssi}</span>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                ● {n.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
