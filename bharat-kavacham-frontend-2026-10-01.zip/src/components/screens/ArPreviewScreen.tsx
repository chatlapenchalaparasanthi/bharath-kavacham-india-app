/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Compass,
  Maximize,
  Sun,
  ShieldCheck,
  Eye,
  RefreshCw,
  VideoOff,
  Video,
} from 'lucide-react';
import { ScreenId } from '../../types';
import { thermalSimulationService } from '../../services/thermalSimulationService';

interface ArPreviewScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ArPreviewScreen: React.FC<ArPreviewScreenProps> = ({ onNavigate }) => {
  const [isArActive, setIsArActive] = useState<boolean>(true);
  const [useLiveCamera, setUseLiveCamera] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const geom = thermalSimulationService.getGeometry();

  useEffect(() => {
    if (!useLiveCamera) {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
      return;
    }

    // Attempt WebRTC camera stream if permitted
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'environment' } })
      .then((stream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraError(null);
      })
      .catch((err) => {
        setCameraError('Camera access unavailable. Displaying realistic high-altitude forward terrain AR simulation.');
        setUseLiveCamera(false);
      });

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [useLiveCamera]);

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full space-y-6 pb-24">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs font-mono text-sky-400 uppercase tracking-wider mb-1">
            FORWARD FIELD SPATIAL AUGMENTATION
          </div>
          <h1 className="font-['Chakra_Petch'] font-bold text-2xl sm:text-3xl text-white">
            AR SHELTER PREVIEW
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Verify shelter footprint, ground leveling, South solar alignment, and access corridors before assembly.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseLiveCamera(!useLiveCamera)}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 active:scale-95 transition-all"
          >
            {useLiveCamera ? <VideoOff className="w-4 h-4 text-red-400" /> : <Video className="w-4 h-4 text-sky-400" />}
            <span>{useLiveCamera ? 'Use Simulated Terrain' : 'Toggle Live Camera'}</span>
          </button>
        </div>
      </div>

      {/* AR Viewport Frame */}
      <div className="relative w-full aspect-video max-h-[520px] rounded-3xl overflow-hidden border-2 border-slate-700/80 bg-slate-950 shadow-2xl flex items-center justify-center select-none">
        {/* Live Camera Stream Video Element */}
        {useLiveCamera ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover"
          />
        ) : (
          /* Simulated Mountain Terrain Background */
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-sky-950 to-slate-950">
            {/* Mountain Silhouettes */}
            <svg viewBox="0 0 800 450" className="w-full h-full object-cover opacity-60">
              <polygon points="0,450 150,220 320,340 500,180 680,310 800,240 800,450" fill="#0f172a" />
              <polygon points="0,450 220,290 400,380 620,270 800,360 800,450" fill="#1e293b" opacity="0.7" />
              <line x1="0" y1="360" x2="800" y2="360" stroke="#334155" strokeWidth="1" strokeDasharray="4 4" />
            </svg>
          </div>
        )}

        {/* Reticle & Level Sensor HUD */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs font-mono text-sky-400 z-10">
          <div className="bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/80 flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            <span>HEADING: 180° S (ALIGNMENT OPTIMAL)</span>
          </div>

          <div className="bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/80 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>SURFACE LEVEL: 0.8° TILT</span>
          </div>
        </div>

        {/* 3D Wireframe Overlay */}
        <div className="relative z-10 w-full max-w-[420px] aspect-4/3 flex items-center justify-center pointer-events-none">
          <svg viewBox="0 0 400 300" className="w-full h-full drop-shadow-[0_0_15px_rgba(56,189,248,0.5)]">
            {/* Ground Grid Projection */}
            <polygon
              points="80,240 320,240 360,280 40,280"
              fill="rgba(56, 189, 248, 0.15)"
              stroke="#38bdf8"
              strokeWidth="2"
              strokeDasharray="4 2"
            />

            {/* Shelter Base Box */}
            <polygon
              points="80,140 320,140 320,240 80,240"
              fill="rgba(15, 23, 42, 0.4)"
              stroke="#38bdf8"
              strokeWidth="2.5"
            />
            <polygon
              points="320,140 360,170 360,270 320,240"
              fill="rgba(15, 23, 42, 0.5)"
              stroke="#38bdf8"
              strokeWidth="2"
            />

            {/* Sloped Roof */}
            <polygon
              points="80,140 200,80 320,140"
              fill="rgba(245, 158, 11, 0.2)"
              stroke="#f59e0b"
              strokeWidth="2.5"
            />
            <polygon
              points="200,80 240,110 360,170 320,140"
              fill="rgba(245, 158, 11, 0.3)"
              stroke="#f59e0b"
              strokeWidth="2"
            />

            {/* Trombe Wall South Glazing Highlight */}
            <rect
              x="120"
              y="160"
              width="160"
              height="60"
              fill="rgba(245, 158, 11, 0.4)"
              stroke="#fbbf24"
              strokeWidth="2"
            />
            <text x="200" y="195" fill="#ffffff" fontSize="11" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
              SOLAR TROMBE CORE
            </text>

            {/* Dimensions Overlay */}
            <text x="200" y="258" fill="#38bdf8" fontSize="11" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
              LENGTH: {geom.lengthM}m × WIDTH: {geom.widthM}m
            </text>
            <text x="60" y="190" fill="#38bdf8" fontSize="10" fontFamily="monospace" textAnchor="end">
              H: {geom.heightM}m
            </text>
          </svg>
        </div>

        {/* Bottom Instruction Bar */}
        <div className="absolute bottom-4 inset-x-4 flex items-center justify-between z-10">
          <div className="bg-slate-950/90 backdrop-blur-md px-4 py-2 rounded-xl border border-slate-700/80 text-xs text-slate-200">
            <strong>Instruction:</strong> Point your camera toward the intended shelter location on level ground.
          </div>

          <div className="bg-sky-500/20 text-sky-300 border border-sky-500/40 px-3 py-1.5 rounded-lg text-xs font-mono font-bold">
            AR PROTOTYPE
          </div>
        </div>
      </div>

      {/* AR Specifications Footer */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-0.5">Footprint Area</span>
          <span className="text-lg font-bold font-mono text-white">
            {Math.round(geom.lengthM * geom.widthM)} m²
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-0.5">Azimuth Alignment</span>
          <span className="text-lg font-bold font-mono text-amber-400">
            {geom.orientationDeg}° (True South)
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-0.5">Roof Pitch</span>
          <span className="text-lg font-bold font-mono text-sky-400">
            22° Sloped (Shed Snow)
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-slate-400 block mb-0.5">Glazing Aperture</span>
          <span className="text-lg font-bold font-mono text-emerald-400">
            {geom.trombeWallAreaM2} m² South Face
          </span>
        </div>
      </div>
    </div>
  );
};
