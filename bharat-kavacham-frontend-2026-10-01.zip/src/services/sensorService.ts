/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MaintenanceAlert, SensorModel, ShelterHealthModel } from '../types';

export class SensorService {
  private sensors: SensorModel[] = [
    {
      id: 'sen-tin',
      name: 'Core Indoor Air Temp',
      type: 'temperature',
      location: 'Center Living Zone (1.5m AGL)',
      value: '17.2',
      unit: '°C',
      numericValue: 17.2,
      status: 'ONLINE',
      healthScorePct: 98,
      lastUpdate: 'Just now (10s ago)',
    },
    {
      id: 'sen-tout',
      name: 'Ambient Sub-Zero Exterior',
      type: 'temperature',
      location: 'North Mast Exposure',
      value: '-38.4',
      unit: '°C',
      numericValue: -38.4,
      status: 'ONLINE',
      healthScorePct: 94,
      lastUpdate: 'Just now (12s ago)',
    },
    {
      id: 'sen-rh',
      name: 'Indoor Relative Humidity',
      type: 'humidity',
      location: 'Living Quarters Core',
      value: '31',
      unit: '%',
      numericValue: 31,
      status: 'ONLINE',
      healthScorePct: 92,
      lastUpdate: '30s ago',
    },
    {
      id: 'sen-baro',
      name: 'Barometric Altitude Pressure',
      type: 'pressure',
      location: 'Main Avionics Bay',
      value: '522',
      unit: 'hPa',
      numericValue: 522,
      status: 'ONLINE',
      healthScorePct: 99,
      lastUpdate: '45s ago',
    },
    {
      id: 'sen-flux',
      name: 'Trombe Wall Heat Flux',
      type: 'heat_flux',
      location: 'South Trombe Glazing Cavity',
      value: '142',
      unit: 'W/m²',
      numericValue: 142,
      status: 'ONLINE',
      healthScorePct: 86,
      lastUpdate: 'Just now',
    },
    {
      id: 'sen-door',
      name: 'Vestibule Airlock Contact',
      type: 'door',
      location: 'Main Entry Vestibule',
      value: 'SEALED',
      unit: '',
      numericValue: 1,
      status: 'ONLINE',
      healthScorePct: 95,
      lastUpdate: '1m ago',
    },
    {
      id: 'sen-motor',
      name: 'Thermal Damper Actuator',
      type: 'damper_motor',
      location: 'Trombe Night Convection Damper',
      value: '15% Open',
      unit: '',
      numericValue: 15,
      status: 'ONLINE',
      healthScorePct: 88,
      lastUpdate: '2m ago',
    },
  ];

  private alerts: MaintenanceAlert[] = [
    {
      id: 'alt-1',
      severity: 'WARNING',
      title: 'Roof Sensor Calibration Desync',
      component: 'Roof Pyranometer / Temperature Probe',
      message: 'Thermocouple drift of +1.4°C detected versus reference bus under peak snow reflection.',
      recommendation: 'Perform seasonal zero-point calibration before peak blizzard window.',
      timestamp: 'Today, 11:42 IST',
    },
    {
      id: 'alt-2',
      severity: 'INFO',
      title: 'Trombe Wall Damper Routine Cycle',
      component: 'Motorized Low-Temp Flap Actuator',
      message: 'Damper reached 1,200 operational cycles with steady torque draw at -30°C.',
      recommendation: 'Check mechanical silicone seal for frost buildup during monthly check.',
      timestamp: 'Yesterday, 18:30 IST',
    },
    {
      id: 'alt-3',
      severity: 'INFO',
      title: 'PCM Storage Heat Bank State',
      component: 'Phase Change Core',
      message: 'Phase change boundary observed at 20.8°C with 70% thermal charge holding.',
      recommendation: 'Normal automated passive buffering active.',
      timestamp: 'Today, 06:15 IST',
    },
  ];

  public getSensors(): SensorModel[] {
    return [...this.sensors];
  }

  public getShelterHealth(): ShelterHealthModel {
    return {
      overallScorePct: 87,
      wallScorePct: 92,
      roofScorePct: 84,
      heatingScorePct: 90,
      sensorsScorePct: 81,
      motorScorePct: 88,
      alerts: [...this.alerts],
    };
  }
}

export const sensorService = new SensorService();
