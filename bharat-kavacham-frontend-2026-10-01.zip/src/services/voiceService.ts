/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LanguageCode } from '../types';

export interface VoiceCommandSample {
  id: string;
  command: {
    en: string;
    hi: string;
    lad: string;
  };
  response: {
    en: string;
    hi: string;
    lad: string;
  };
}

export const VOICE_COMMANDS: VoiceCommandSample[] = [
  {
    id: 'cmd-temp',
    command: {
      en: 'Show temperature',
      hi: 'तापमान दिखाओ',
      lad: 'དྲོད་ཚད་སྟོན་ཅིག',
    },
    response: {
      en: 'Current indoor temperature is 17.2 degrees Celsius. Outdoor ambient is minus 38.4 degrees. Shelter status is comfortable.',
      hi: 'वर्तमान भीतरी तापमान 17.2 डिग्री सेल्सियस है। बाहरी तापमान माइनस 38.4 डिग्री है। आश्रय अनुकूल स्थिति में है।',
      lad: 'ད་ལྟའི་ནང་གི་དྲོད་ཚད་ནི་ ༡༧.༢ ཌིག་རི་ཡིན། ཕྱི་རོལ་དྲོད་ཚད་ནི་ མར་འབབ་ ༣༨.༤ ཡིན། གནས་མཁར་བདེ་མོ་ཡོད།',
    },
  },
  {
    id: 'cmd-sim',
    command: {
      en: 'Start simulation',
      hi: 'सिमुलेशन प्रारंभ करो',
      lad: 'ཚོད་ལྟ་འགོ་འཛུགས།',
    },
    response: {
      en: '1D Transient Thermal Solver executed for 24 hours. Predicted average temperature 17.0 degrees with 88% fuel saving.',
      hi: '24 घंटे का 1D क्षणिक तापीय सिमुलेशन पूरा हुआ। औसत तापमान 17.0 डिग्री और 88% ईंधन बचत अनुमानित है।',
      lad: 'ཆུ་ཚོད་ ༢༤ ཡི་དྲོད་ཚད་ཚོད་ལྟ་ལེགས་གྲུབ་བྱུང་། ནང་གི་ཆ་སྙོམས་དྲོད་ཚད་ ༡༧ དང་སྣུམ་ ༨༨% གྲོན་ཆུང་ཐོབ།',
    },
  },
  {
    id: 'cmd-heatloss',
    command: {
      en: 'Show heat loss',
      hi: 'ऊष्मा ह्रास दिखाओ',
      lad: 'དྲོད་ཤོར་བགོ་བཤའ་སྟོན།',
    },
    response: {
      en: 'Heat loss breakdown: Walls 40%, Roof 30%, Floor 15%, Airlock door 8%, Infiltration ventilation 7%.',
      hi: 'ऊष्मा ह्रास विवरण: दीवारें 40%, छत 30%, फर्श 15%, प्रवेश द्वार 8%, वेंटिलेशन 7%।',
      lad: 'དྲོད་ཤོར་བགོ་བཤའ། རྩིག་པར་ ༤༠%། ཐོག་ཁར་ ༣༠%། ས་གདན་ལ་ ༡༥%། སྒོ་ལ་ ༨%། རླུང་འགྲོ་ལ་ ༧%།',
    },
  },
  {
    id: 'cmd-health',
    command: {
      en: 'Check shelter health',
      hi: 'आश्रय स्वास्थ्य जांचो',
      lad: 'གནས་མཁར་བདེ་ཐང་བརྟག་ཞིབ།',
    },
    response: {
      en: 'Shelter health is 87%. Wall integrity 92%, Roof 84%. Recommendation: Calibrate roof thermocouple before winter peak.',
      hi: 'आश्रय स्वास्थ्य 87% है। दीवार 92%, छत 84%। सुझाव: शीतकाल से पूर्व छत के सेंसर का अंशांकन करें।',
      lad: 'གནས་མཁར་གྱི་གནས་སྟངས་ ༨༧% ཡིན། རྩིག་པ་ ༩༢%། ཐོག་ཁ་ ༨༤%། དགུན་ཁའི་སྔོན་ལ་ཐོག་ཁའི་སེན་སར་བརྟག་ཞིབ་དགོས།',
    },
  },
  {
    id: 'cmd-solar',
    command: {
      en: 'Show solar storage',
      hi: 'सौर संचयन स्थिति बताओ',
      lad: 'ཉི་འོད་དྲོད་གསོག་གནས་སྟངས།',
    },
    response: {
      en: 'Trombe Wall and Phase Change Material bank holding 8.4 kilowatt-hours thermal energy at 70% storage capacity.',
      hi: 'ट्रॉम्ब वॉल और पीसीएम थर्मल बैंक में 8.4 किलोवाट-घंटे ऊष्मा संचित है, जो 70% क्षमता पर है।',
      lad: 'ཊོ་རོམ་བྷི་རྩིག་པ་དང་པི་སི་ཨེམ་དྲོད་གསོག་མཛོད་དུ་ ༨.༤ ཀི་ལོ་ཝཊ་ཉར་ཚགས་ཡོད། ༧༠% གྲ་སྒྲིག་ཡིན།',
    },
  },
];

export class VoiceService {
  public speak(text: string, lang: LanguageCode = 'en'): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      if (lang === 'hi') {
        utterance.lang = 'hi-IN';
      } else {
        utterance.lang = 'en-IN';
      }
      window.speechSynthesis.speak(utterance);
    }
  }

  public getCommands(): VoiceCommandSample[] {
    return VOICE_COMMANDS;
  }
}

export const voiceService = new VoiceService();
