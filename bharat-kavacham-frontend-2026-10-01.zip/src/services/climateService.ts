/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ClimateDataModel, ClimateHourlyPoint, LocationModel } from '../types';

export const LOCATIONS: LocationModel[] = [
  {
    id: 'siachen',
    name: 'Siachen Glacier Base',
    region: 'Karakoram Range, Ladakh',
    latitude: 35.4212,
    longitude: 77.1095,
    altitudeMeters: 5400,
    designWinterTemp: -40,
    avgWindKmh: 24,
    dailySolarGhiKwh: 5.5,
  },
  {
    id: 'dras',
    name: 'Dras High-Altitude Sector',
    region: 'Kargil District, Ladakh',
    latitude: 34.4285,
    longitude: 75.7511,
    altitudeMeters: 3280,
    designWinterTemp: -35,
    avgWindKmh: 18,
    dailySolarGhiKwh: 5.1,
  },
  {
    id: 'leh',
    name: 'Leh Military Station',
    region: 'Indus Valley, Ladakh',
    latitude: 34.1526,
    longitude: 77.5771,
    altitudeMeters: 3500,
    designWinterTemp: -20,
    avgWindKmh: 14,
    dailySolarGhiKwh: 6.2,
  },
  {
    id: 'kargil',
    name: 'Kargil Forward Sector',
    region: 'Suru Valley, Ladakh',
    latitude: 34.5539,
    longitude: 76.1349,
    altitudeMeters: 2676,
    designWinterTemp: -25,
    avgWindKmh: 16,
    dailySolarGhiKwh: 5.3,
  },
  {
    id: 'nyoma',
    name: 'Nyoma Advanced Post',
    region: 'Changthang Plateau, Ladakh',
    latitude: 33.1974,
    longitude: 78.6534,
    altitudeMeters: 4180,
    designWinterTemp: -32,
    avgWindKmh: 22,
    dailySolarGhiKwh: 6.4,
  },
  {
    id: 'custom',
    name: 'Custom High-Altitude Post',
    region: 'User Defined Coordinates',
    latitude: 34.5000,
    longitude: 77.0000,
    altitudeMeters: 4500,
    designWinterTemp: -30,
    avgWindKmh: 20,
    dailySolarGhiKwh: 5.4,
    isCustom: true,
  },
];

export class ClimateService {
  private activeLocation: LocationModel = LOCATIONS[0];
  private dataSource: 'NASA POWER' | 'CACHED' | 'DEMO' = 'DEMO';
  private cachedData: Map<string, ClimateDataModel> = new Map();

  constructor() {
    this.seedDefaultCache();
  }

  public getLocations(): LocationModel[] {
    return [...LOCATIONS];
  }

  public getActiveLocation(): LocationModel {
    return this.activeLocation;
  }

  public setActiveLocation(loc: LocationModel): void {
    this.activeLocation = loc;
  }

  public setDataSource(source: 'NASA POWER' | 'CACHED' | 'DEMO'): void {
    this.dataSource = source;
  }

  public getDataSource(): 'NASA POWER' | 'CACHED' | 'DEMO' {
    return this.dataSource;
  }

  public getClimateData(locationId: string): ClimateDataModel {
    const loc = LOCATIONS.find((l) => l.id === locationId) || this.activeLocation;
    const baseTemp = loc.designWinterTemp;
    const peakSolar = loc.dailySolarGhiKwh * 130; // peak W/m² approx

    const hourly: ClimateHourlyPoint[] = [];
    for (let h = 0; h < 24; h++) {
      // Diurnal temperature variation: lowest at 05:00, highest at 14:00
      const solarAngle = Math.max(0, Math.sin(((h - 6) / 12) * Math.PI));
      const tempVariation = (h >= 6 && h <= 18) ? Math.sin(((h - 7) / 11) * Math.PI) * 14 : -Math.cos(((h + 6) / 12) * Math.PI) * 4;
      const temperature = Math.round((baseTemp + tempVariation) * 10) / 10;
      const solarGhi = Math.round(solarAngle * peakSolar);
      const solarDni = Math.round(solarAngle * (peakSolar * 1.25));
      const windSpeed = Math.round((loc.avgWindKmh + Math.sin(h * 0.5) * 5) * 10) / 10;
      const humidity = Math.round(25 + (1 - solarAngle) * 20);

      hourly.push({
        hour: h,
        temperature,
        solarGhi,
        solarDni,
        windSpeed,
        humidity,
      });
    }

    const temps = hourly.map((p) => p.temperature);
    const minTemp = Math.min(...temps);
    const maxTemp = Math.max(...temps);
    const avgTemp = Math.round((temps.reduce((a, b) => a + b, 0) / temps.length) * 10) / 10;

    return {
      locationId: loc.id,
      date: '2026-10-15',
      source: this.dataSource,
      avgTemp,
      minTemp,
      maxTemp,
      avgGhi: loc.dailySolarGhiKwh,
      avgWind: loc.avgWindKmh,
      hourly,
      syncTimestamp: '14:20 IST (Offline Cached)',
    };
  }

  private seedDefaultCache(): void {
    LOCATIONS.forEach((loc) => {
      this.cachedData.set(loc.id, this.getClimateData(loc.id));
    });
  }
}

export const climateService = new ClimateService();
