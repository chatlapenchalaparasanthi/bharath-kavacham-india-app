/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

export class ExportZipService {
  public async generateAndDownloadZip(onProgress?: (percent: number, file: string) => void): Promise<void> {
    onProgress?.(20, 'Preparing pre-compiled package...');

    // Try fetching the pre-built public package first for instant zero-latency download
    try {
      const directResponse = await fetch('/bharat-kavacham-frontend.zip');
      if (directResponse.ok) {
        onProgress?.(80, 'Downloading pre-compiled archive...');
        const blob = await directResponse.blob();
        this.triggerDownload(blob);
        onProgress?.(100, 'Download complete!');
        return;
      }
    } catch {
      // Fallback to client-side bundle
    }

    onProgress?.(30, 'Bundling source tree...');
    const zip = new JSZip();

    // Package configuration
    const manifestFiles = [
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'index.html',
      'metadata.json',
      '.env.example',
      'README.md',
    ];

    for (const filename of manifestFiles) {
      try {
        const response = await fetch(`/${filename}`);
        if (response.ok) {
          const content = await response.text();
          zip.file(filename, content);
        }
      } catch {
        // Continue
      }
    }

    onProgress?.(60, 'Packaging source modules...');
    const srcFiles = [
      'src/main.tsx',
      'src/App.tsx',
      'src/index.css',
      'src/types/index.ts',
      'src/localization/translations.ts',
      'src/services/climateService.ts',
      'src/services/materialService.ts',
      'src/services/thermalSimulationService.ts',
      'src/services/optimizationService.ts',
      'src/services/sensorService.ts',
      'src/services/voiceService.ts',
      'src/services/securityService.ts',
      'src/services/exportZipService.ts',
    ];

    for (let i = 0; i < srcFiles.length; i++) {
      const path = srcFiles[i];
      try {
        const response = await fetch(`/${path}`);
        if (response.ok) {
          const text = await response.text();
          zip.file(path, text);
        }
      } catch {
        // Continue
      }
    }

    onProgress?.(90, 'Compressing archive...');
    const blob = await zip.generateAsync({ type: 'blob' });
    this.triggerDownload(blob);
    onProgress?.(100, 'Download finished!');
  }

  private triggerDownload(blob: Blob): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bharat-kavacham-frontend-${new Date().toISOString().slice(0, 10)}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export const exportZipService = new ExportZipService();
