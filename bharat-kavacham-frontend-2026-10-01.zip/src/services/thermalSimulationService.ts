/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HeatFlowComponent, ShelterGeometryModel, SimulationHourlyResult, SimulationInput, SimulationResult } from '../types';
import { climateService } from './climateService';
import { materialService } from './materialService';

export class ThermalSimulationService {
  private defaultGeometry: ShelterGeometryModel = {
    lengthM: 6.0,
    widthM: 4.0,
    heightM: 2.8,
    orientationDeg: 180, // Facing South for maximum solar gain
    roofType: 'sloped',
    occupancy: 4,
    ventilationAch: 0.5,
    windowToWallRatio: 0.12,
    trombeWallAreaM2: 8.5,
    pcmStorageCapacityKwh: 12.0,
  };

  public getGeometry(): ShelterGeometryModel {
    return { ...this.defaultGeometry };
  }

  public updateGeometry(geom: Partial<ShelterGeometryModel>): ShelterGeometryModel {
    this.defaultGeometry = { ...this.defaultGeometry, ...geom };
    return this.getGeometry();
  }

  public run1DTransientSimulation(input: SimulationInput): SimulationResult {
    const geom = this.defaultGeometry;
    const loc = climateService.getActiveLocation();
    const climate = climateService.getClimateData(loc.id);

    const wallMetrics = materialService.calculateAssemblyMetrics(materialService.getAssembly('wall'));
    const roofMetrics = materialService.calculateAssemblyMetrics(materialService.getAssembly('roof'));
    const floorMetrics = materialService.calculateAssemblyMetrics(materialService.getAssembly('floor'));

    // Enclosure areas
    const wallGrossArea = 2 * (geom.lengthM + geom.widthM) * geom.heightM;
    const windowArea = wallGrossArea * geom.windowToWallRatio;
    const netWallArea = wallGrossArea - windowArea - (input.useTrombeWall ? geom.trombeWallAreaM2 : 0);
    const roofArea = geom.lengthM * geom.widthM * 1.08; // slight sloped factor
    const floorArea = geom.lengthM * geom.widthM;
    const volume = floorArea * geom.heightM;

    // Thermal conductance UA total (W/K)
    const uaWall = netWallArea * wallMetrics.uValue;
    const uaRoof = roofArea * roofMetrics.uValue;
    const uaFloor = floorArea * floorMetrics.uValue;
    const uaWindow = windowArea * 1.8; // High performance argon double glazing
    const uaVent = 0.33 * geom.ventilationAch * volume; // W/K air exchange
    const totalUA = uaWall + uaRoof + uaFloor + uaWindow + uaVent;

    // Thermal mass capacity C (kJ/K -> Wh/K)
    const baseAirCapacityWh = (volume * 1.2 * 1005) / 3600; // Wh/K air
    const interiorCladdingMassWh = 3500; // timber cladding capacitance
    const pcmActiveCapacityWh = input.usePcm ? 6000 : 0;
    const totalThermalCapacitance = baseAirCapacityWh + interiorCladdingMassWh + pcmActiveCapacityWh;

    let currentIndoorTemp = input.initialIndoorTemp || 17.0;
    let pcmChargeStateKwh = input.usePcm ? 5.2 : 0;

    const hourlyResults: SimulationHourlyResult[] = [];
    let heatingEnergyConsumedTotalWh = 0;
    let comfortHoursCount = 0;

    for (let h = 0; h < input.durationHours; h++) {
      const climateHourIndex = h % 24;
      const climatePt = climate.hourly[climateHourIndex];
      const outdoorTemp = climatePt.temperature;
      const solarGhi = climatePt.solarGhi;

      // Solar passive gain through windows and Trombe wall
      const windowSolarGainW = windowArea * solarGhi * 0.65; // SHGC
      const trombeSolarGainW = input.useTrombeWall ? geom.trombeWallAreaM2 * solarGhi * 0.72 : 0;
      const totalSolarGainW = windowSolarGainW + (input.useTrombeWall ? trombeSolarGainW * 0.4 : 0);

      // Internal heat gain from occupants (80W sensible per occupant) + equipment
      const internalGainW = geom.occupancy * 85 + 120;

      // Heat loss to outdoor ambient
      const deltaT = currentIndoorTemp - outdoorTemp;
      const envelopeLossW = totalUA * deltaT;

      // Net energy balance before active heating (Watts)
      let netHeatFlowW = internalGainW + totalSolarGainW - envelopeLossW;

      // Trombe / PCM interaction:
      let trombeTemp = outdoorTemp + (solarGhi > 50 ? solarGhi * 0.05 : 2);
      if (input.usePcm) {
        if (solarGhi > 200 && currentIndoorTemp > 18) {
          // Charging PCM
          const chargeW = Math.min(800, (currentIndoorTemp - 18) * 150);
          netHeatFlowW -= chargeW;
          pcmChargeStateKwh = Math.min(geom.pcmStorageCapacityKwh, pcmChargeStateKwh + (chargeW / 1000));
        } else if (currentIndoorTemp < 17 && pcmChargeStateKwh > 0.5) {
          // Discharging PCM into room
          const dischargeW = Math.min(950, (17.5 - currentIndoorTemp) * 200);
          netHeatFlowW += dischargeW;
          pcmChargeStateKwh = Math.max(0, pcmChargeStateKwh - (dischargeW / 1000));
        }
      }

      // Backward Euler Numerical Update:
      // T_next = T_curr + (netHeatFlowW * dt_hours) / totalThermalCapacitance
      let nextIndoorTemp = currentIndoorTemp + (netHeatFlowW * 1.0) / (totalThermalCapacitance * 0.25);

      // Supplemental heating demand if below comfort target (16°C)
      let heatingPowerUsedKw = 0;
      if (nextIndoorTemp < 16.0) {
        const deficitW = (16.0 - nextIndoorTemp) * totalThermalCapacitance * 0.25;
        const heatSuppliedW = Math.min(input.heatingPowerKw * 1000, deficitW);
        heatingPowerUsedKw = heatSuppliedW / 1000;
        nextIndoorTemp += heatSuppliedW / (totalThermalCapacitance * 0.25);
        heatingEnergyConsumedTotalWh += heatSuppliedW;
      }

      currentIndoorTemp = Math.round(nextIndoorTemp * 10) / 10;
      if (currentIndoorTemp >= 15.0 && currentIndoorTemp <= 21.0) {
        comfortHoursCount++;
      }

      hourlyResults.push({
        hour: h,
        outdoorTemp,
        indoorTemp: currentIndoorTemp,
        trombeTemp: Math.round(trombeTemp * 10) / 10,
        pcmStoredKwh: Math.round(pcmChargeStateKwh * 10) / 10,
        heatingPowerUsedKw: Math.round(heatingPowerUsedKw * 100) / 100,
        solarGainKw: Math.round((totalSolarGainW / 1000) * 100) / 100,
      });
    }

    const indoorTemps = hourlyResults.map((r) => r.indoorTemp);
    const minIndoorTemp = Math.min(...indoorTemps);
    const maxIndoorTemp = Math.max(...indoorTemps);
    const avgIndoorTemp = Math.round((indoorTemps.reduce((a, b) => a + b, 0) / indoorTemps.length) * 10) / 10;

    // Daily normalized heating demand
    const dailyHeatingDemandKwh = Math.round((heatingEnergyConsumedTotalWh / 1000 / (input.durationHours / 24)) * 10) / 10;
    const baselineUninsulatedDemandKwh = 178.0;
    const fuelSavingPct = Math.round(((baselineUninsulatedDemandKwh - dailyHeatingDemandKwh) / baselineUninsulatedDemandKwh) * 100);

    return {
      durationHours: input.durationHours,
      minIndoorTemp,
      maxIndoorTemp,
      avgIndoorTemp,
      comfortHours: comfortHoursCount,
      totalComfortHours: input.durationHours,
      dailyHeatingDemandKwh,
      baselineDemandKwh: baselineUninsulatedDemandKwh,
      solarContributionPct: 68,
      fuelSavingPct,
      hourly: hourlyResults,
      label: 'Demo Simulation',
    };
  }

  public getHeatFlowDecomposition(): HeatFlowComponent[] {
    return [
      {
        id: 'wall',
        name: 'Opaque Walls',
        percentage: 40,
        heatLossWatts: 720,
        areaM2: 56.0,
        uValue: 0.18,
        tempDiffC: 57,
        insulationThicknessMm: 120,
        recommendedAction: 'Increasing PUF layer from 120mm to 150mm yields ~14% lower transmission loss.',
      },
      {
        id: 'roof',
        name: 'Roof Assembly',
        percentage: 30,
        heatLossWatts: 540,
        areaM2: 26.0,
        uValue: 0.14,
        tempDiffC: 59,
        insulationThicknessMm: 160,
        recommendedAction: 'Apply reflective sub-membrane and eliminate thermal fasteners to prevent condensation.',
      },
      {
        id: 'floor',
        name: 'Ground / Frost Floor',
        percentage: 15,
        heatLossWatts: 270,
        areaM2: 24.0,
        uValue: 0.22,
        tempDiffC: 45,
        insulationThicknessMm: 120,
        recommendedAction: 'Add perimeter frost skirts to prevent sub-permafrost freeze heave.',
      },
      {
        id: 'door',
        name: 'Airlock Entry Door',
        percentage: 8,
        heatLossWatts: 144,
        areaM2: 3.8,
        uValue: 0.95,
        tempDiffC: 57,
        insulationThicknessMm: 60,
        recommendedAction: 'Ensure dual magnetic cold-weather gaskets and vestibule air-lock buffer.',
      },
      {
        id: 'ventilation',
        name: 'Controlled Infiltration & Ventilation',
        percentage: 7,
        heatLossWatts: 126,
        areaM2: 67.2, // volume equivalent
        uValue: 0.33,
        tempDiffC: 57,
        insulationThicknessMm: 0,
        recommendedAction: 'Integrate counter-flow heat recovery ventilator (HRV) for 70% sensible enthalpy return.',
      },
    ];
  }
}

export const thermalSimulationService = new ThermalSimulationService();
