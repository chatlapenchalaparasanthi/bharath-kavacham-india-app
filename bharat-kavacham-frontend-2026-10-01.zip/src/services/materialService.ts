/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AssemblyLayer, AssemblyModel, MaterialModel } from '../types';

export const MATERIALS: MaterialModel[] = [
  {
    id: 'puf',
    name: 'PUF (Polyurethane Foam)',
    category: 'insulation',
    kValue: 0.022,
    density: 40,
    specificHeat: 1400,
    standardThicknessMm: 100,
    costPerM3Inr: 14500,
    embodiedCarbonKg: 3.2,
    localAvailability: 'Medium (Leh Stock)',
    description: 'High-performance closed-cell thermal insulation widely utilized in sub-zero prefabricated defence shelters.',
    features: ['Ultra-low thermal conductivity', 'Moisture resistant', 'Lightweight'],
  },
  {
    id: 'aac',
    name: 'AAC (Autoclaved Aerated Concrete)',
    category: 'masonry',
    kValue: 0.16,
    density: 550,
    specificHeat: 1000,
    standardThicknessMm: 150,
    costPerM3Inr: 4200,
    embodiedCarbonKg: 0.28,
    localAvailability: 'High (Himalayan)',
    description: 'Porous cellular concrete blocks providing both structural integrity and moderate insulating properties.',
    features: ['Fire resistant', 'Decent thermal mass', 'Structural capability'],
  },
  {
    id: 'mud_adobe',
    name: 'Mud / Sun-Dried Adobe Brick',
    category: 'masonry',
    kValue: 0.75,
    density: 1700,
    specificHeat: 1260,
    standardThicknessMm: 250,
    costPerM3Inr: 1200,
    embodiedCarbonKg: 0.05,
    localAvailability: 'High (Himalayan)',
    description: 'Traditional indigenous Himalayan building material with exceptional thermal mass for diurnal solar storage.',
    features: ['High thermal mass', 'Zero embodied carbon', 'Local vernacular availability'],
  },
  {
    id: 'glass_wool',
    name: 'Glass Wool Insulation',
    category: 'insulation',
    kValue: 0.038,
    density: 24,
    specificHeat: 840,
    standardThicknessMm: 100,
    costPerM3Inr: 3800,
    embodiedCarbonKg: 1.1,
    localAvailability: 'High (Himalayan)',
    description: 'Flexible fibrous mineral insulation providing effective thermal and acoustic insulation in roof and cavity walls.',
    features: ['Non-combustible', 'Acoustic absorption', 'Economic cost'],
  },
  {
    id: 'himalayan_stone',
    name: 'Himalayan Granite / Slate Stone',
    category: 'masonry',
    kValue: 2.2,
    density: 2600,
    specificHeat: 820,
    standardThicknessMm: 200,
    costPerM3Inr: 2500,
    embodiedCarbonKg: 0.08,
    localAvailability: 'High (Himalayan)',
    description: 'Abundant native stone providing exterior ballistic and wind-shear shielding with robust thermal inertia.',
    features: ['Extreme durability', 'Wind and frost resistant', 'Local high availability'],
  },
  {
    id: 'concrete',
    name: 'Reinforced Concrete (M25)',
    category: 'masonry',
    kValue: 1.75,
    density: 2400,
    specificHeat: 900,
    standardThicknessMm: 150,
    costPerM3Inr: 5800,
    embodiedCarbonKg: 0.35,
    localAvailability: 'High (Himalayan)',
    description: 'Heavy structural slab material requiring adequate thermal breaks to avoid thermal bridging in extreme cold.',
    features: ['Structural strength', 'High thermal capacitance', 'Requires external insulation'],
  },
  {
    id: 'wood_deodar',
    name: 'Deodar / Cedar Timber',
    category: 'timber',
    kValue: 0.13,
    density: 560,
    specificHeat: 1600,
    standardThicknessMm: 40,
    costPerM3Inr: 32000,
    embodiedCarbonKg: -0.4,
    localAvailability: 'Medium (Leh Stock)',
    description: 'Natural interior wood cladding that reduces interior radiative chill and controls humidity.',
    features: ['Warm tactile surface', 'Carbon negative', 'Aesthetic comfort'],
  },
  {
    id: 'eps',
    name: 'EPS (Expanded Polystyrene)',
    category: 'insulation',
    kValue: 0.035,
    density: 25,
    specificHeat: 1200,
    standardThicknessMm: 80,
    costPerM3Inr: 4500,
    embodiedCarbonKg: 2.5,
    localAvailability: 'High (Himalayan)',
    description: 'Economical rigid foam insulation board suitable for sub-slab floor and perimeter foundation insulation.',
    features: ['Cost effective', 'Water resistant', 'Easy field cutting'],
  },
  {
    id: 'composite_panel',
    name: 'FRP Vacuum Composite Panel',
    category: 'composite',
    kValue: 0.026,
    density: 85,
    specificHeat: 1300,
    standardThicknessMm: 120,
    costPerM3Inr: 18500,
    embodiedCarbonKg: 4.1,
    localAvailability: 'Special Order',
    description: 'Advanced fibre-reinforced polymer sandwich panel engineered for rapid expeditionary deployment.',
    features: ['Structural self-support', 'Modular interlocking joints', 'Air-tight envelope'],
  },
  {
    id: 'aerogel',
    name: 'Silica Aerogel Thermal Blanket',
    category: 'advanced',
    kValue: 0.015,
    density: 160,
    specificHeat: 1000,
    standardThicknessMm: 20,
    costPerM3Inr: 65000,
    embodiedCarbonKg: 5.8,
    localAvailability: 'Special Order',
    description: 'Nanoporous state-of-the-art superinsulator used for thermal bridge mitigation in extreme Siachen environments.',
    features: ['Lowest thermal conductivity', 'Thin profile (space saving)', 'Hydrophobic'],
  },
];

export class MaterialService {
  private materials: MaterialModel[] = [...MATERIALS];

  private wallAssembly: AssemblyModel = {
    id: 'default-wall',
    type: 'wall',
    name: 'Himalayan High-Altitude Multi-Layer Wall',
    layers: [
      { id: 'l1', materialId: 'himalayan_stone', name: 'Exterior Himalayan Stone', thicknessMm: 150, kValue: 2.2 },
      { id: 'l2', materialId: 'puf', name: 'PUF Core Insulation', thicknessMm: 120, kValue: 0.022 },
      { id: 'l3', materialId: 'aac', name: 'AAC Structural Block', thicknessMm: 100, kValue: 0.16 },
      { id: 'l4', materialId: 'wood_deodar', name: 'Interior Deodar Cladding', thicknessMm: 25, kValue: 0.13 },
    ],
  };

  private roofAssembly: AssemblyModel = {
    id: 'default-roof',
    type: 'roof',
    name: 'Extreme Cold Insulated Roof',
    layers: [
      { id: 'r1', materialId: 'composite_panel', name: 'Weather-Tough Composite Skin', thicknessMm: 20, kValue: 0.026 },
      { id: 'r2', materialId: 'puf', name: 'Dense PUF Insulation', thicknessMm: 160, kValue: 0.022 },
      { id: 'r3', materialId: 'glass_wool', name: 'Glass Wool Acoustic/Thermal Layer', thicknessMm: 80, kValue: 0.038 },
      { id: 'r4', materialId: 'wood_deodar', name: 'Interior Timber Finish', thicknessMm: 20, kValue: 0.13 },
    ],
  };

  private floorAssembly: AssemblyModel = {
    id: 'default-floor',
    type: 'floor',
    name: 'Sub-Slab Frost-Break Floor',
    layers: [
      { id: 'f1', materialId: 'eps', name: 'High-Density EPS Sub-Slab', thicknessMm: 120, kValue: 0.035 },
      { id: 'f2', materialId: 'concrete', name: 'Concrete Screed Slab', thicknessMm: 100, kValue: 1.75 },
      { id: 'f3', materialId: 'wood_deodar', name: 'Thermal Insulated Wood Flooring', thicknessMm: 30, kValue: 0.13 },
    ],
  };

  public getAllMaterials(): MaterialModel[] {
    return this.materials;
  }

  public getMaterialById(id: string): MaterialModel | undefined {
    return this.materials.find((m) => m.id === id);
  }

  public getAssembly(type: 'wall' | 'roof' | 'floor'): AssemblyModel {
    if (type === 'wall') return this.wallAssembly;
    if (type === 'roof') return this.roofAssembly;
    return this.floorAssembly;
  }

  public updateAssembly(assembly: AssemblyModel): void {
    if (assembly.type === 'wall') this.wallAssembly = assembly;
    else if (assembly.type === 'roof') this.roofAssembly = assembly;
    else this.floorAssembly = assembly;
  }

  public calculateAssemblyMetrics(assembly: AssemblyModel) {
    // Air film resistances (ISO 6946 / ASHRAE standard):
    // Rsi = 0.13 m²K/W for wall, 0.10 for roof upward heat flow, 0.17 for floor downward
    const rSi = assembly.type === 'wall' ? 0.13 : assembly.type === 'roof' ? 0.10 : 0.17;
    const rSe = 0.04; // Exterior air film under wind conditions

    let totalR = rSi + rSe;
    let totalThicknessMm = 0;
    let estimatedCostPerM2 = 0;

    assembly.layers.forEach((layer) => {
      const dMeters = layer.thicknessMm / 1000;
      const layerR = dMeters / (layer.kValue || 0.03);
      totalR += layerR;
      totalThicknessMm += layer.thicknessMm;

      const mat = this.getMaterialById(layer.materialId);
      if (mat) {
        estimatedCostPerM2 += (mat.costPerM3Inr * dMeters);
      }
    });

    const uValue = Math.round((1 / totalR) * 1000) / 1000; // W/m²·K
    const rValue = Math.round(totalR * 100) / 100; // m²·K/W

    return {
      totalThicknessMm,
      rValue,
      uValue,
      estimatedCostPerM2: Math.round(estimatedCostPerM2),
    };
  }
}

export const materialService = new MaterialService();
