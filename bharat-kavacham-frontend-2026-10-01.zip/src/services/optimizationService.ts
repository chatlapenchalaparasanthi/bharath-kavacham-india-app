/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OptimizationDesignPoint } from '../types';

export class OptimizationService {
  private sampleDesigns: OptimizationDesignPoint[] = [];

  constructor() {
    this.generateDesignSpace();
  }

  public getDesignSpace(): OptimizationDesignPoint[] {
    return this.sampleDesigns;
  }

  public getDesignById(id: string): OptimizationDesignPoint | undefined {
    return this.sampleDesigns.find((d) => d.id === id);
  }

  private generateDesignSpace(): void {
    const list: OptimizationDesignPoint[] = [
      {
        id: 'cfg-baseline',
        name: 'Standard Field Shelter (Uninsulated Tin/Stone)',
        wallInsulationMm: 25,
        roofInsulationMm: 30,
        glazingType: 'Single 4mm Glass',
        trombeWall: false,
        pcmStorage: false,
        costInr: 185000,
        dailyEnergyKwh: 178,
        comfortScorePct: 35,
        tag: 'baseline',
        heatLossPctWall: 52,
      },
      {
        id: 'cfg-cost',
        name: 'Budget Himalayan Adobe + EPS Hybrid',
        wallInsulationMm: 80,
        roofInsulationMm: 100,
        glazingType: 'Double Glazed Clear',
        trombeWall: true,
        pcmStorage: false,
        costInr: 295000,
        dailyEnergyKwh: 48,
        comfortScorePct: 78,
        tag: 'cost',
        heatLossPctWall: 45,
      },
      {
        id: 'cfg-balanced',
        name: 'BHARAT KAVACHAM Standard Tactical (Recommended)',
        wallInsulationMm: 120,
        roofInsulationMm: 160,
        glazingType: 'Argon Low-E Double Glazed',
        trombeWall: true,
        pcmStorage: true,
        costInr: 420000,
        dailyEnergyKwh: 21,
        comfortScorePct: 94,
        tag: 'balanced',
        heatLossPctWall: 40,
      },
      {
        id: 'cfg-energy',
        name: 'Ultra Passive Solar + Dual PCM Vault',
        wallInsulationMm: 180,
        roofInsulationMm: 220,
        glazingType: 'Triple Krypton Low-E',
        trombeWall: true,
        pcmStorage: true,
        costInr: 580000,
        dailyEnergyKwh: 12,
        comfortScorePct: 98,
        tag: 'energy',
        heatLossPctWall: 32,
      },
      {
        id: 'cfg-comfort',
        name: 'Siachen Super-Insulated Aerogel Shield',
        wallInsulationMm: 150,
        roofInsulationMm: 200,
        glazingType: 'Triple Argon Low-E + Aerogel Reveal',
        trombeWall: true,
        pcmStorage: true,
        costInr: 690000,
        dailyEnergyKwh: 14,
        comfortScorePct: 99,
        tag: 'comfort',
        heatLossPctWall: 30,
      },
    ];

    // Synthesize intermediate points from the 324 explored configurations
    for (let i = 1; i <= 35; i++) {
      const wallMm = 50 + (i % 6) * 25;
      const roofMm = 60 + ((i * 2) % 6) * 30;
      const cost = Math.round(220000 + wallMm * 1400 + roofMm * 900 + (i % 2 === 0 ? 95000 : 25000));
      const dailyKwh = Math.round(Math.max(10, 160 - (wallMm * 0.45 + roofMm * 0.35 + (i % 3 === 0 ? 30 : 5))));
      const comfort = Math.min(99, Math.round(40 + (180 - dailyKwh) * 0.38));

      let tag: OptimizationDesignPoint['tag'] = 'balanced';
      if (cost < 340000) tag = 'cost';
      else if (dailyKwh < 20) tag = 'energy';
      else if (comfort > 92) tag = 'comfort';

      list.push({
        id: `cfg-synth-${i}`,
        name: `Iterative Config #${100 + i} (${wallMm}mm Wall / ${roofMm}mm Roof)`,
        wallInsulationMm: wallMm,
        roofInsulationMm: roofMm,
        glazingType: i % 2 === 0 ? 'Double Low-E' : 'Double Clear',
        trombeWall: i % 2 === 0,
        pcmStorage: i % 3 === 0,
        costInr: cost,
        dailyEnergyKwh: dailyKwh,
        comfortScorePct: comfort,
        tag,
        heatLossPctWall: Math.round(35 + (i % 15)),
      });
    }

    this.sampleDesigns = list;
  }
}

export const optimizationService = new OptimizationService();
