/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SecurityStatus {
  detectionModule: 'SIMULATED' | 'OFFLINE';
  thermalCamera: 'SIMULATED' | 'OFFLINE';
  rfMonitoring: 'SIMULATED' | 'OFFLINE';
  systemPower: 'SIMULATED' | 'OFFLINE';
  perimeterDistanceMeters: number;
  lastEvent: string;
  isResearchNoticeAcknowledged: boolean;
}

export class SecurityPrototypeService {
  private status: SecurityStatus = {
    detectionModule: 'SIMULATED',
    thermalCamera: 'SIMULATED',
    rfMonitoring: 'SIMULATED',
    systemPower: 'SIMULATED',
    perimeterDistanceMeters: 800,
    lastEvent: 'Simulated perimeter boundary scan clear — No targets within 1200m radius',
    isResearchNoticeAcknowledged: true,
  };

  public getStatus(): SecurityStatus {
    return { ...this.status };
  }

  public triggerSimulatedEvent(distanceMeters = 800): SecurityStatus {
    this.status.perimeterDistanceMeters = distanceMeters;
    this.status.lastEvent = `Simulated aerial object registered at ${distanceMeters}m sector. Visual verification recommended.`;
    return this.getStatus();
  }

  public clearSimulatedEvent(): SecurityStatus {
    this.status.perimeterDistanceMeters = 0;
    this.status.lastEvent = 'Simulated perimeter boundary scan clear — No targets within 1200m radius';
    return this.getStatus();
  }
}

export const securityPrototypeService = new SecurityPrototypeService();
