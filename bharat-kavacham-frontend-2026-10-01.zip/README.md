# BHARAT KAVACHAM (भारत कवचम्)
## Area-Specific Thermal Shelter Intelligence Platform for High-Altitude Himalayan Environments

### Overview
BHARAT KAVACHAM is an engineering intelligence platform developed for the design, 1D transient thermal simulation, heat-flow decomposition, material optimization, and IoT monitoring of extreme sub-zero shelters (Siachen, Leh, Dras, Kargil, Nyoma).

### Key Features
1. **Area-Specific Climate Analysis**: Diurnal solar irradiance (GHI/DNI), sub-zero wind profiles, and altitude atmospheric pressures (NASA POWER API adapter).
2. **Parametric Shelter Workspace**: Length, width, internal height, sloped/flat/dome roofs, south azimuth passive solar orientation, and dynamic 2D plan blueprint.
3. **1D Transient Thermal Solver**: Finite difference model with Implicit Backward Euler numerical integration across layered composite assemblies.
4. **Heat Flow Decomposition**: Donut analysis of component transmission losses (Wall 40%, Roof 30%, Floor 15%, Door 8%, Infiltration 7%) with actionable engineering remedies.
5. **Multi-Objective Design Space Explorer**: 324 architectural permutations evaluated across the Pareto cost-energy frontier.
6. **Passive Solar Trombe Wall & PCM Thermal Bank**: Phase change material latent storage buffering diurnal solar enthalpy into nocturnal comfort.
7. **Offline-First Data Center**: IndexedDB local persistence for GPS-denied and communication-severed forward posts.
8. **Field Telemetry & Sensor Mesh**: 6-channel IoT telemetry (temperature, humidity, barometric pressure, heat flux, airlock status, damper motor).
9. **Cyber-Physical Digital Twin 3D**: Interactive isometric cutaway with surface temperature and heat flux probes.
10. **Predictive Health & Diagnostics**: Machine learning structural health scoring (87% nominal) and preventive maintenance alerts.
11. **Jawan Mitra Trilingual Voice Assistant**: English, Hindi (हिंदी), and Ladakhi (ལ་དྭགས་སྐད) voice commands for sub-zero glove operation.
12. **AR Spatial Footprint Preview**: Augmented reality terrain alignment HUD ensuring true South orientation and level grade.
13. **Safe Security Research Prototype**: Conceptual perimeter boundary surveillance (no kinetic or RF warfare instructions).
14. **High-Altitude Forward Post Radar Map**: Regional tactical geospatial map with thermal loss status (Red, Yellow, Green).
15. **Offline SOS / LoRa Mesh Prototype**: Sub-GHz local mesh packet broadcast for emergency signaling.
16. **QR Shelter Asset Passport**: Cryptographic identity (PK-2026-26051) with maintenance and thermal logs.
17. **Environmental & Fuel Calculator**: Transparent formulas calculating diesel displacement (88% reduction) and avoided CO2 emissions.
18. **16-Section Technical Report Generator**: Comprehensive engineering dossier with printable and PDF export capabilities.
19. **Model Validation Center**: Transparent mathematical proofs, conservation of energy, and CFL time-step stability checks.
20. **Defence Presentation Mode**: High-impact competition and leadership briefing mode with narrative opening story.

### Setup and Running Locally
```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Build for production
npm run build
```
The application will launch on http://localhost:3000
